import contextlib,copy,io,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from faxsetup import model,deploy,firewall,cli,wizard,host

def fixture():
    s=wizard.sample('22.04');s['mail']['fax_address']='fax@example.invalid'
    s['mail']['allowed_senders']=['sender@example.invalid'];s['mail']['receive_recipients']=['recipient@example.invalid']
    for k in ('imap','smtp'):s['mail'][k]['username']='fax@example.invalid'
    s['sip'].update(auth_username='test_account',user_id='test_id',phone_number='05000000000')
    secret={'imap_password':'PRIVATE_IMAP_MARKER','smtp_password':'PRIVATE_SMTP_MARKER','sip_password':'PRIVATE_SIP_MARKER'}
    return s,secret

class InputTests(unittest.TestCase):
    def setUp(self):self.s,self.secret=fixture()
    def validate(self):return model.inputs(self.s,self.secret)
    def test_valid(self):self.assertEqual(self.validate()[0]['platform']['version_id'],'22.04')
    def test_unknown_key(self):
        self.s['unknown']=True
        with self.assertRaises(model.Failure):self.validate()
    def test_unsupported_os(self):
        self.s['platform']['version_id']='25.10'
        with self.assertRaises(model.Failure):self.validate()
    def test_unsupported_arch(self):
        self.s['platform']['architecture']='armhf'
        with self.assertRaises(model.Failure):self.validate()
    def test_boolean_port(self):
        self.s['mail']['imap']['port']=True
        with self.assertRaises(model.Failure):self.validate()
    def test_sip_injection(self):
        self.s['sip']['user_id']='x\n[transport]'
        with self.assertRaises(model.Failure):self.validate()
    def test_sip_password_delimiters(self):
        for secret in ['test;comment','x\nline','{{SECRET_2}}','<password>','']:
            with self.subTest(secret=secret):
                self.secret['sip_password']=secret
                with self.assertRaises(model.Failure):self.validate()
    def test_secret_error_never_echoes_value(self):
        self.secret['sip_password']='PRIVATE_SECRET;bad'
        try:self.validate()
        except model.Failure as e:self.assertNotIn('PRIVATE_SECRET',str(e))
    def test_custom_provider(self):
        self.s['sip']['host']='sip.example.invalid'
        self.assertEqual(self.validate()[0]['sip']['host'],'sip.example.invalid')
    def test_duplicate_sender(self):
        self.s['mail']['allowed_senders']=['x@EXAMPLE.invalid','x@example.invalid']
        with self.assertRaises(model.Failure):self.validate()
    def test_sender_local_case_preserved(self):self.assertEqual(model.address('Ab@EXAMPLE.invalid'),'Ab@example.invalid')
    def test_empty_sender_and_recipient_allowed(self):
        self.s['mail']['allowed_senders']=[];self.s['mail']['receive_recipients']=[]
        self.assertEqual(self.validate()[3]['users'],[])
    def test_user_permission_mismatch(self):
        p=model.users_from_site(self.s);p['users'][0]['send']=False
        with self.assertRaises(model.Failure):model.inputs(self.s,self.secret,people=p)
    def test_user_disabled_mismatch(self):
        p=model.users_from_site(self.s);p['users'][0]['enabled']=False
        with self.assertRaises(model.Failure):model.inputs(self.s,self.secret,people=p)
    def test_user_ids_stable(self):self.assertEqual(model.users_from_site(self.s),model.users_from_site(self.s))
    def test_invalid_user_id(self):
        p=model.users_from_site(self.s);p['users'][0]['id']='../../bad'
        with self.assertRaises(model.Failure):model.users(p)
    def test_plaintext_tls_rejected(self):
        self.s['mail']['smtp']['security']='plain'
        with self.assertRaises(model.Failure):self.validate()
    def test_unknown_mail_auth(self):
        self.s['mail']['authentication']['mechanism']='disabled'
        with self.assertRaises(model.Failure):self.validate()
    def test_public_key_array(self):
        self.s['admin']['authorized_public_keys']='ssh-ed25519 AAAA'
        with self.assertRaises(model.Failure):self.validate()

class GenerationTests(unittest.TestCase):
    def setUp(self):self.s,self.secret=fixture();self.values=model.inputs(self.s,self.secret)
    def test_plan_no_secrets(self):
        text=json.dumps(deploy.plan(*self.values))
        for v in self.secret.values():self.assertNotIn(v,text)
    def test_generate_separate_secrets(self):
        files=model.generate(self.s,self.secret)
        mail=json.loads(files['/etc/faxmail-next/site-mail.json'])
        self.assertEqual(mail['mail']['imap']['password'],self.secret['imap_password'])
        self.assertEqual(mail['mail']['smtp']['password'],self.secret['smtp_password'])
        self.assertNotIn(self.secret['imap_password'].encode(),files['/etc/faxmail-next/site-fax.json'])
        self.assertNotIn(b'PRIVATE_',files['/etc/faxmail-next/validation.json'])
    def test_sip_mapping(self):
        self.s['sip']['phone_number']='0312345678'
        files=model.generate(self.s,self.secret);conf=files['/var/lib/fax-receive-live/etc/pjsip.conf'].decode()
        self.assertIn('username=test_account',conf);self.assertIn('sip:test_id@',conf);self.assertIn('FAX <0312345678>',conf)
        dial=files['/var/lib/fax-receive-live/etc/extensions.conf'].decode()
        self.assertEqual(dial.count('CALLERID(num)=0312345678'),2);self.assertIn('exten => 0312345678,',dial)
    def test_staged_excludes_gates(self):
        files=deploy.managed_payload(self.s,self.secret)
        for p in host.GATES:self.assertNotIn(str(p),files)
        self.assertNotIn('/etc/systemd/system/faxmail-firewall.service',files)
        self.assertNotIn('/etc/faxmail-next/dependency-lock.json',files)
    def test_no_business_state_in_payload(self):
        files=model.generate(self.s,self.secret)
        for path in files:self.assertNotIn('jobs.sqlite',path);self.assertNotIn('dedupe.key',path)
    def test_runtime_zero_sender_schema(self):
        schema=json.loads((model.BUNDLE/'payload/opt/faxmail-next/config.schema.json').read_text())
        self.assertEqual(schema['properties']['mail']['properties']['allowed_senders']['minItems'],0)
    def test_no_legacy_trial_payload(self):
        files=model.generate(self.s,self.secret)
        self.assertFalse(any('roundtrip' in k or '_metadata.py' in k for k in files))
    def test_chrony_not_replaced(self):
        for version in ('22','24','26'):
            profile=json.loads((model.BUNDLE/'platform'/('ubuntu-'+version+'.json')).read_text())
            self.assertNotIn('systemd-timesyncd',profile['packages'])
            self.assertFalse(profile['release_tested'])
    def test_pypdf_only_22_supplement(self):
        profiles=[json.loads((model.BUNDLE/'platform'/('ubuntu-'+v+'.json')).read_text()) for v in ('22','24','26')]
        self.assertEqual(profiles[0]['pip'],{'typing_extensions':'4.15.0','pypdf':'6.9.2'});self.assertEqual(profiles[1]['pip'],{});self.assertEqual(profiles[2]['pip'],{})
    def test_broker_checks_actual_firewall(self):
        self.assertIn(b"'/usr/local/bin/fax-admin','firewall-check'",model.generate(self.s,self.secret)['/opt/faxmail-next/faxmail/broker.py'])

class FirewallTests(unittest.TestCase):
    def setUp(self):self.fw={'firewall_schema':1,'ssh_port':2222,'allowed_source_cidrs':['192.0.2.2','2001:db8::1']}
    def test_normalize_single_addresses(self):
        self.assertEqual(model.firewall(self.fw)['allowed_source_cidrs'],['192.0.2.2/32','2001:db8::1/128'])
    def test_ports(self):
        for port in (0,65536,-1,True,'22'):
            with self.subTest(port=port):
                self.fw['ssh_port']=port
                with self.assertRaises(model.Failure):model.firewall(self.fw)
    def test_empty_ranges(self):
        self.fw['allowed_source_cidrs']=[]
        with self.assertRaises(model.Failure):model.firewall(self.fw)
    def test_host_bits_rejected(self):
        self.fw['allowed_source_cidrs']=['192.0.2.5/24']
        with self.assertRaises(model.Failure):model.firewall(self.fw)
    def test_public_explicit(self):
        self.fw['allowed_source_cidrs']=['0.0.0.0/0']
        with self.assertRaises(model.Failure):model.firewall(self.fw)
        self.assertEqual(model.firewall(self.fw,True)['ssh_port'],2222)
    def test_rules_only_own_table(self):
        text=firewall.rules(model.firewall(self.fw))
        self.assertNotIn('flush ruleset',text);self.assertNotIn('dport 22 ',text)
        self.assertIn('ip6 saddr 2001:db8::1/128 tcp dport 2222',text)
        self.assertIn('ip saddr 192.0.2.2/32 tcp dport 2222',text)
    def test_transition_keeps_old_port(self):
        text=firewall.rules(model.firewall(self.fw),{'ssh_port':22,'allowed_source_cidrs':['192.0.2.3/32']})
        self.assertIn('tcp dport 22 ',text);self.assertIn('tcp dport 2222 ',text)
    def test_nft_handles_not_semantic(self):
        self.assertEqual(firewall.normalized({'nftables':[{'metainfo':{'version':'1'}},{'chain':{'handle':1,'policy':'drop'}}]}),{'nftables':[{'chain':{'policy':'drop'}}]})
    def test_confirm_rejects_origin_session(self):
        data={'id':'token','expires':__import__('time').time()+60,'origin':{'session':'same'},'candidate':model.firewall(self.fw)}
        with patch.object(firewall,'TRIAL',Mock(exists=lambda:True)),patch.object(host,'read_json',return_value=data),patch.object(firewall,'ssh_session',return_value={'session':'same','port':2222,'source':'192.0.2.2'}),patch.object(firewall,'write_ssh') as write:
            with self.assertRaises(model.Failure):firewall.confirm('token')
            write.assert_not_called()
    def test_confirm_rejects_wrong_source(self):
        data={'id':'token','expires':__import__('time').time()+60,'origin':{'session':'old'},'candidate':model.firewall(self.fw)}
        with patch.object(firewall,'TRIAL',Mock(exists=lambda:True)),patch.object(host,'read_json',return_value=data),patch.object(firewall,'ssh_session',return_value={'session':'new','port':2222,'source':'198.51.100.1'}),patch.object(firewall,'write_ssh') as write:
            with self.assertRaises(model.Failure):firewall.confirm('token')
            write.assert_not_called()
    def test_confirm_rejects_expired(self):
        data={'id':'token','expires':0,'origin':{'session':'old'},'candidate':model.firewall(self.fw)}
        with patch.object(firewall,'TRIAL',Mock(exists=lambda:True)),patch.object(host,'read_json',return_value=data),patch.object(firewall,'ssh_session',return_value={'session':'new','port':2222,'source':'192.0.2.2'}):
            with self.assertRaises(model.Failure):firewall.confirm('token')

class SSHAddressFamilyTests(unittest.TestCase):
    def test_socket_config_keeps_explicit_ipv4_and_ipv6(self):
        text=firewall.socket_config({2222,22}).decode()
        self.assertIn('ListenStream=\n',text)
        self.assertIn('BindIPv6Only=ipv6-only\n',text)
        for port in (22,2222):
            self.assertIn(f'ListenStream=0.0.0.0:{port}\n',text)
            self.assertIn(f'ListenStream=[::]:{port}\n',text)
            self.assertNotIn(f'ListenStream={port}\n',text)
    def check_listeners(self,v4,v6,ports={22}):
        def run(args):return Mock(stdout=v4 if '-4' in args else v6)
        with patch.object(host,'run',side_effect=run):return firewall.dual_stack_listening(ports)
    def test_ipv6_only_regression(self):
        self.assertFalse(self.check_listeners('', 'LISTEN 0 4096 [::]:22 [::]:*'))
    def test_ipv4_only_rejected(self):
        self.assertFalse(self.check_listeners('LISTEN 0 4096 0.0.0.0:22 0.0.0.0:*',''))
    def test_loopback_does_not_count_as_remote_listener(self):
        self.assertFalse(self.check_listeners('LISTEN 0 4096 127.0.0.1:22 0.0.0.0:*','LISTEN 0 4096 [::]:22 [::]:*'))
    def test_dual_stack_passes(self):
        self.assertTrue(self.check_listeners('LISTEN 0 4096 0.0.0.0:22 0.0.0.0:*','LISTEN 0 4096 *:22 *:*'))
    def test_missing_transition_port_rejected(self):
        self.assertFalse(self.check_listeners('LISTEN 0 4096 0.0.0.0:22 0.0.0.0:*','LISTEN 0 4096 [::]:22 [::]:*',{22,2222}))

class CLITests(unittest.TestCase):
    def invoke(self,args):
        out=io.StringIO()
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):code=cli.entry(args)
        return code,out.getvalue()
    def test_noninteractive_no_install(self):
        with patch.object(sys.stdin,'isatty',return_value=False),patch.object(deploy,'install') as install:
            code,_=self.invoke(['install']);self.assertEqual(code,2);install.assert_not_called()
    def test_activate_requires_old_stop(self):
        with patch.object(deploy,'activation') as activate:
            code,_=self.invoke(['install','--activate']);self.assertEqual(code,2);activate.assert_not_called()
    def test_plan_cannot_send(self):
        with patch.object(deploy,'connection') as connect:
            code,_=self.invoke(['connection','--kind','smtp','--plan','--send-one','--recipient','x@example.invalid']);self.assertEqual(code,2);connect.assert_not_called()
    def test_install_plan_no_host_calls(self):
        s,secret=fixture()
        with patch.object(host,'read_json',side_effect=lambda p:secret if str(p)=='secret' else s),patch.object(deploy,'plan',return_value={'completion':'STAGED'}),patch.object(host,'locked') as lock,patch.object(deploy,'install') as install:
            code,text=self.invoke(['install','--config','site','--secrets-file','secret','--plan'])
            self.assertEqual(code,0);self.assertIn('STAGED',text);lock.assert_not_called();install.assert_not_called()
    def test_error_does_not_echo_raw_exception(self):
        with patch.object(deploy,'bundle_check',side_effect=ValueError('PRIVATE_SECRET')):
            code,text=self.invoke(['check-bundle']);self.assertEqual(code,5);self.assertNotIn('PRIVATE_SECRET',text)
    def test_firewall_plan_no_host_mutations(self):
        fw={'firewall_schema':1,'ssh_port':2222,'allowed_source_cidrs':['192.0.2.0/24']}
        with patch.object(host,'read_json',return_value=fw),patch.object(host,'locked') as lock,patch.object(host,'run') as run:
            code,text=self.invoke(['firewall','--config','fw','--plan']);self.assertEqual(code,0);lock.assert_not_called();run.assert_not_called()
    def test_bundle_syntax(self):
        import ast
        for p in model.BUNDLE.rglob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))

class MenuTests(unittest.TestCase):
    def setUp(self):
        from faxsetup import ui
        self.ui=ui;s,secret=fixture();self.values=list(model.inputs(s,secret))
    def test_invalid_field_only_reprompts_and_saves_once(self):
        seen=[]
        with patch.object(self.ui,'ask',side_effect=['not a number','70000','5061']),patch.object(self.ui,'save',side_effect=lambda v:seen.append(copy.deepcopy(v))),contextlib.redirect_stdout(io.StringIO()):
            self.ui.field(self.values,self.values[0]['sip'],'port','ポート',self.ui.port)
        self.assertEqual(self.values[0]['sip']['port'],5061);self.assertEqual(len(seen),1)
    def test_authserv_email_explained_at_input(self):
        with self.assertRaisesRegex(model.Failure,'メールアドレスではありません'):self.ui.domain('user@example.invalid')
    def test_domains_cannot_be_empty(self):
        with self.assertRaises(model.Failure):self.ui.domains('')
    def test_list_default_survives_enter(self):
        seen=[]
        with patch.object(self.ui,'ask',side_effect=lambda label,default,secret:seen.append(default) or default),patch.object(self.ui,'save'):
            self.ui.field(self.values,self.values[2],'allowed_source_cidrs','CIDR',self.ui.cidrs)
        self.assertIsInstance(seen[0],str);self.assertEqual(self.values[2]['allowed_source_cidrs'],['192.0.2.0/24'])
    def test_interrupted_second_field_keeps_first_save(self):
        saved=[]
        with patch.object(self.ui,'ask',side_effect=['other.example.invalid',model.Failure(130,'back')]),patch.object(self.ui,'save',side_effect=lambda v:saved.append(copy.deepcopy(v))):
            self.ui.field(self.values,self.values[0]['sip'],'host','server',self.ui.domain)
            with self.assertRaises(model.Failure):self.ui.field(self.values,self.values[0]['sip'],'port','port',self.ui.port)
        self.assertEqual(saved[0][0]['sip']['host'],'other.example.invalid')
    def test_secret_never_prints_in_prompt(self):
        out=io.StringIO()
        with patch('getpass.getpass',return_value='') as ask,contextlib.redirect_stdout(out):
            value=self.ui.ask('password','MY_PRIVATE_VALUE',True)
        self.assertEqual(value,'MY_PRIVATE_VALUE');self.assertNotIn('MY_PRIVATE_VALUE',ask.call_args[0][0]+out.getvalue())
    def test_draft_save_does_not_install(self):
        with patch.object(host,'locked',return_value=contextlib.nullcontext()),patch.object(host,'state',return_value={'status':'ACTIVE'}),patch.object(host,'write_json') as write,patch.object(deploy,'install') as install:
            self.ui.save(self.values)
        self.assertEqual(write.call_args[0][0],host.ADMIN/'candidate.json');self.assertEqual(write.call_args[0][1]['secrets'],self.values[1]);install.assert_not_called()
    def test_saved_candidate_resumed(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'candidate.json').write_text('{}')
            d=dict(zip(('site','secrets','firewall','users'),self.values))
            with patch.object(host,'ADMIN',p),patch.object(host,'read_secret',return_value=d):self.assertEqual(self.ui.load(),self.values)
    def test_legacy_draft_recovered_without_inventing_secrets(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'draft.json').write_text('{}')
            with patch.object(host,'ADMIN',p),patch.object(host,'platform',return_value={'version':'26.04','arch':'amd64'}),patch.object(host,'read_json',return_value={'site':self.values[0]}),contextlib.redirect_stdout(io.StringIO()):values=self.ui.load()
            self.assertEqual(values[0],self.values[0]);self.assertEqual(values[1],{})
    def test_gmail_preset_replaces_bad_authserv(self):
        self.values[0]['mail']['authentication']['trusted_authserv_ids']=['user@example.invalid']
        with patch.object(self.ui,'choose',return_value='1'),patch.object(self.ui,'save'):
            self.ui.auth_menu(self.values)
        auth=self.values[0]['mail']['authentication'];self.assertEqual(auth['trusted_authserv_ids'],['mx.google.com']);self.assertFalse(auth['trust_boundary_verified'])
    def test_users_menu_add_receive_explicit(self):
        self.values[3]['users']=[];self.ui.sync_people(self.values)
        with patch.object(self.ui,'choose',side_effect=['1','0']),patch.object(self.ui,'ask',return_value='person@example.invalid'),patch.object(self.ui,'yes',side_effect=[True,False,True]),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):self.ui.people(self.values)
        self.assertEqual(self.values[0]['mail']['allowed_senders'],[]);self.assertEqual(self.values[0]['mail']['receive_recipients'],['person@example.invalid'])
    def test_missing_settings_prevents_install(self):
        self.values[1].clear()
        with patch.object(deploy,'install') as install,contextlib.redirect_stdout(io.StringIO()):self.assertEqual(self.ui.apply(self.values),2)
        install.assert_not_called()
    def test_main_has_six_ordered_steps(self):
        out=io.StringIO()
        with patch.object(host,'platform',return_value={'version':'22.04','arch':'amd64'}),patch.object(host,'root_required'),patch.object(sys.stdin,'isatty',return_value=True),patch.object(host,'state',return_value={'status':'CONFIGURING'}),patch.object(self.ui,'load',return_value=self.values),patch('builtins.input',return_value='0'),contextlib.redirect_stdout(out):self.assertEqual(self.ui.menu(),0)
        for label in ['1. 管理ユーザー・管理端末を設定','2. SIP情報を設定','3. メール・利用者を設定','4. ファイアウォール設定を保存','5. 本体インストール・更新','6. 接続検証・FW適用・本番開始']:self.assertIn(label,out.getvalue())
    def test_install_entry_opens_main_menu(self):
        with patch.object(sys.stdin,'isatty',return_value=True),patch.object(wizard,'menu',return_value=0) as menu,patch.object(deploy,'install') as install:self.assertEqual(cli.main(['install']),0)
        menu.assert_called_once();install.assert_not_called()
    def test_uninstall_requires_typed_confirmation(self):
        with patch.object(self.ui,'choose',side_effect=['4','0']),patch.object(deploy,'uninstall_plan',return_value=[Path('/opt/faxmail-next/test.py')]),patch.object(self.ui,'ask',return_value='no'),patch.object(deploy,'uninstall') as remove,contextlib.redirect_stdout(io.StringIO()):self.ui.install_menu(self.values)
        remove.assert_not_called()

class RC2SafetyTests(unittest.TestCase):
    def test_restart_after_uninstall_does_not_import_deleted_control(self):
        def exists(p):return str(p).endswith('control.lock') or str(p).replace('\\','/').endswith('venv/bin/python')
        with patch.object(Path,'exists',exists),patch.object(host,'service_user') as invoke,patch.object(host,'run'),patch.object(host,'active',return_value=False):host.stop_processing()
        invoke.assert_not_called()
    def test_unchanged_field_keeps_verified_status(self):
        from faxsetup import ui
        s,secret=fixture();values=list(model.inputs(s,secret));a=values[0]['mail']['authentication'];a['trust_boundary_verified']=True
        with patch.object(ui,'ask',return_value=values[0]['mail']['imap']['host']),patch.object(ui,'save'):
            ui.field(values,values[0]['mail']['imap'],'host','host',ui.domain,after=lambda:ui.clear_verified(values[0]['mail']))
        self.assertTrue(a['trust_boundary_verified'])
    def test_custom_tcp_generation(self):
        s,secret=fixture();s['sip'].update(host='pbx.example.invalid',port=5070,transport='tcp',domain='realm.example.invalid',contact_user='incoming',phone_number='+81300000000')
        s=model.site_config(s);files=model.generate(s,secret);p=files['/var/lib/fax-receive-live/etc/pjsip.conf'].decode()
        for text in ['protocol=tcp','server_uri=sip:pbx.example.invalid:5070;transport=tcp','client_uri=sip:test_id@realm.example.invalid;transport=tcp','from_domain=realm.example.invalid','contact_user=incoming']:self.assertIn(text,p)
        self.assertIn('exten => incoming,',files['/var/lib/fax-receive-live/etc/extensions.conf'].decode())
    def test_sip_optional_fields_injection_rejected(self):
        for key,value in [('domain','host\npassword=x'),('contact_user','bad;route'),('transport','tls'),('port',True)]:
            s,secret=fixture();s['sip'][key]=value
            with self.subTest(key=key),self.assertRaises(model.Failure):model.inputs(s,secret)
    def test_firewall_service_started_outside_management_lock(self):
        locked=[False]
        @contextlib.contextmanager
        def lock():
            self.assertFalse(locked[0]);locked[0]=True
            try:yield
            finally:locked[0]=False
        def run(args):self.assertFalse(locked[0]);return Mock(returncode=0)
        def activate(flag):self.assertTrue(locked[0]);return 0
        with patch.object(host,'locked',side_effect=lock),patch.object(host,'state',return_value={'status':'STAGED'}),patch.object(host,'ensure_idle'),patch.object(firewall,'check',return_value=0),patch.object(host,'run',side_effect=run),patch.object(deploy,'activation',side_effect=activate):self.assertEqual(deploy.activate_managed(True),0)
    def test_uninstall_plan_preserves_business_and_ssh(self):
        with tempfile.TemporaryDirectory() as td:
            state=Path(td)/'state';state.mkdir();(state/'managed.json').write_text('{}');app=Path(td)/'app';app.mkdir()
            runtime=str(app/'faxmail/cli.py');business='/var/lib/faxmail-next/jobs.sqlite';ssh='/etc/ssh/sshd_config.d/00-fax-installer.conf';config='/etc/faxmail-next/site-mail.json';fw='/etc/systemd/system/faxmail-firewall.service'
            records={x:{} for x in [runtime,business,ssh,config,fw]}
            def read(p):return [{'path':x} for x in records] if Path(p).name=='payload-manifest.json' else records
            with patch.object(host,'STATE',state),patch.object(host,'APP',app),patch.object(host,'read_json',side_effect=read):plan=deploy.uninstall_plan()
            self.assertEqual(plan,[Path(runtime)])

class RC3FlowTests(unittest.TestCase):
    def setUp(self):
        from faxsetup import ui
        self.ui=ui;s,secret=fixture();self.values=list(model.inputs(s,secret))
    def test_personal_values_not_defaults_and_keep_is_explicit(self):
        out=io.StringIO();seen=[]
        def ask(label,default,secret):seen.append(default);return ':保持'
        with patch.object(self.ui,'ask',side_effect=ask),patch.object(self.ui,'save'),contextlib.redirect_stdout(out):
            self.ui.field(self.values,self.values[0]['sip'],'auth_username','SIP認証名',self.ui.ident)
        self.assertEqual(seen,['']);self.assertNotIn('test_account',out.getvalue());self.assertEqual(self.values[0]['sip']['auth_username'],'test_account')
    def test_enter_keeps_registered_personal_value(self):
        with patch.object(self.ui,'ask',return_value='') as ask,patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):
            self.ui.field(self.values,self.values[0]['sip'],'auth_username','SIP認証名',self.ui.ident)
        self.assertEqual(ask.call_count,1);self.assertEqual(self.values[0]['sip']['auth_username'],'test_account')
    def test_other_field_is_not_used_as_personal_default(self):
        self.values[0]['sip']['user_id']=''
        with patch.object(self.ui,'ask',side_effect=[':保持','explicit_id']) as ask,patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):
            self.ui.field(self.values,self.values[0]['sip'],'user_id','SIP ID',self.ui.ident,default='test_account')
        self.assertEqual(ask.call_args_list[0].args[1],'');self.assertEqual(self.values[0]['sip']['user_id'],'explicit_id')
    def test_edit_list_is_displayed_immediately_before_selection(self):
        out=io.StringIO()
        def ask(label,*args):
            if label=='対象の利用者番号':self.assertIn('登録済み利用者一覧',out.getvalue());self.assertIn('sender@example.invalid',out.getvalue());return '1'
            return ':保持'
        def choose(*args):
            if not hasattr(choose,'done'):choose.done=True;out.seek(0);out.truncate();return '2'
            return '0'
        with patch.object(self.ui,'choose',side_effect=choose),patch.object(self.ui,'ask',side_effect=ask),patch.object(self.ui,'yes',return_value=True),patch.object(self.ui,'save'),contextlib.redirect_stdout(out):self.ui.people(self.values)
    def test_preinstall_firewall_menu_never_applies(self):
        with patch.object(self.ui,'choose',side_effect=['1','0']),patch.object(self.ui,'fw_edit') as edit,patch.object(firewall,'trial') as trial,patch.object(host,'state') as state,contextlib.redirect_stdout(io.StringIO()):self.ui.fw_prepare(self.values)
        edit.assert_called_once();trial.assert_not_called();state.assert_not_called()
    def test_zero_exit_is_consistent(self):
        out=io.StringIO()
        with patch('builtins.input',return_value='0'),contextlib.redirect_stdout(out):self.assertEqual(self.ui.choose('test',[('1','one')]),'0')
        self.assertIn('0. 戻る / 終了',out.getvalue())
    def test_summary_explains_address_counts(self):
        out=io.StringIO()
        with patch.object(self.ui,'yes',return_value=False),contextlib.redirect_stdout(out):self.ui.apply(self.values)
        self.assertIn('メールでFAX送信を依頼できるアドレス数',out.getvalue());self.assertIn('FAXの枚数や送受信の実績ではありません',out.getvalue())
    def test_final_step_reflects_verification_without_menu_backtracking(self):
        from faxsetup import checks
        original=copy.deepcopy(self.values)
        def verify(v):v[0]['mail']['authentication'].update(trust_boundary_verified=True,placement_verified=True)
        with patch.object(host,'state',return_value={'status':'STAGED'}),patch.object(firewall,'TRIAL',Mock(exists=lambda:False)),patch.object(self.ui,'yes',return_value=True),patch.object(checks,'mail_connection') as connect,patch.object(checks,'verify_boundary',side_effect=verify),patch.object(self.ui,'save'),patch.object(self.ui,'applied',return_value=original),patch.object(self.ui,'apply',return_value=0) as apply,patch.object(firewall,'check',return_value=4),patch.object(firewall,'trial',return_value=6) as trial,patch.object(host,'locked',return_value=contextlib.nullcontext()),contextlib.redirect_stdout(io.StringIO()):self.assertEqual(self.ui.finish_setup(self.values),6)
        self.assertEqual(connect.call_count,2);apply.assert_called_once();trial.assert_called_once()
    def test_pending_firewall_trial_only_requests_new_session(self):
        with patch.object(host,'state',return_value={'status':'STAGED'}),patch.object(firewall,'TRIAL',Mock(exists=lambda:True)),patch.object(deploy,'activate_managed') as activate,contextlib.redirect_stdout(io.StringIO()):self.assertEqual(self.ui.finish_setup(self.values),6)
        activate.assert_not_called()

class FailureReportingTests(unittest.TestCase):
    def test_failure_record_preserves_reason_and_masks_secrets(self):
        from faxsetup import diagnostics as d
        s,secret=fixture();saved={}
        with contextlib.redirect_stdout(io.StringIO()):d.begin([s,secret])
        d.current_stage='A3ビルド'
        e=model.Failure(5,'gcc が終了コード 1 で失敗しました。');e.details='bad '+secret['sip_password']+' '+s['sip']['auth_username']+' user@example.invalid';e.command='gcc';e.returncode=1
        with patch.object(host,'mkdir',return_value=Path('/logs')),patch.object(host,'write_json',side_effect=lambda path,data:saved.update(report=data)),patch.object(host,'state',return_value={'status':'INSTALLING'}),patch.object(host,'set_state') as state,contextlib.redirect_stdout(io.StringIO()):d.record(e)
        report=saved['report'];self.assertEqual(report['stage'],'A3ビルド');self.assertEqual(report['command_exit_code'],1)
        encoded=json.dumps(report);self.assertNotIn(secret['sip_password'],encoded);self.assertNotIn(s['sip']['auth_username'],encoded);self.assertNotIn('user@example.invalid',encoded)
        self.assertEqual(state.call_args.args[0],'FAILED');self.assertEqual(state.call_args.kwargs['reason'],str(e))
    def test_generic_exception_values_never_logged(self):
        from faxsetup import diagnostics as d
        self.assertNotIn('PRIVATE_PAYLOAD',d.reason(ValueError('PRIVATE_PAYLOAD')))
    def test_record_write_failure_does_not_mask_original(self):
        from faxsetup import diagnostics as d
        error=model.Failure(5,'original')
        with patch.object(host,'mkdir',side_effect=OSError('secret')),contextlib.redirect_stdout(io.StringIO()) as out:d.record(error)
        self.assertIn('original',out.getvalue());self.assertNotIn('secret',out.getvalue())
    def test_failed_status_includes_stage_reason_log(self):
        from faxsetup import ui
        with patch.object(host,'state',return_value={'status':'FAILED','reason':'APT候補が不一致','failed_stage':'依存関係','error_log':'/safe/log.json'}),contextlib.redirect_stdout(io.StringIO()) as out:ui.show_status()
        for value in ['FAILED','APT候補が不一致','依存関係','/safe/log.json']:self.assertIn(value,out.getvalue())
    def test_legacy_failed_status_explains_missing_history(self):
        from faxsetup import ui
        with patch.object(host,'state',return_value={'status':'FAILED'}),contextlib.redirect_stdout(io.StringIO()) as out:ui.show_status()
        self.assertIn('旧版',out.getvalue());self.assertIn('理由',out.getvalue())
    def test_input_report_waits_and_separates_host_failure(self):
        from faxsetup import ui
        s,secret=fixture();values=list(model.inputs(s,secret))
        with patch.object(deploy,'preflight',return_value=[('APT',False,'候補が不一致')]),patch.object(ui,'ask',return_value='') as ask,patch.object(host,'state',return_value={'status':'CONFIGURING'}),contextlib.redirect_stdout(io.StringIO()) as out:self.assertEqual(ui.input_report(values),2)
        self.assertIn('入力設定: OK',out.getvalue());self.assertIn('NG: APT',out.getvalue());self.assertIn('対象外',out.getvalue());ask.assert_called_once()
    def test_install_wrapper_records_early_failure(self):
        from faxsetup import diagnostics as d
        s,secret=fixture();values=model.inputs(s,secret);error=model.Failure(3,'OS不一致')
        with patch.object(deploy,'_install',side_effect=error),patch.object(d,'record') as record,contextlib.redirect_stdout(io.StringIO()),self.assertRaises(model.Failure):deploy.install(*values)
        record.assert_called_once_with(error)
    def test_command_failure_has_exit_code_and_details(self):
        result=Mock(returncode=1,stderr='compile error',stdout='build output')
        with patch.object(subprocess,'run',return_value=result):
            with self.assertRaises(model.Failure) as caught:host.run(['gcc','-o','file'])
        self.assertEqual(caught.exception.returncode,1);self.assertEqual(caught.exception.command,'gcc');self.assertIn('compile error',caught.exception.details)
    def test_unregistered_personal_field_requires_input(self):
        from faxsetup import ui
        s,secret=fixture();s['sip']['auth_username']='';values=list(model.inputs(*fixture()))
        with patch.object(ui,'ask',side_effect=['','new_account']) as ask,patch.object(ui,'save'),contextlib.redirect_stdout(io.StringIO()):ui.field(values,s['sip'],'auth_username','ID',ui.ident)
        self.assertEqual(ask.call_count,2);self.assertEqual(s['sip']['auth_username'],'new_account')

class RC5RegressionTests(unittest.TestCase):
    def test_install_menu_check_first_and_install_second(self):
        from faxsetup import ui
        values=list(model.inputs(*fixture()))
        with patch.object(ui,'choose',side_effect=['1','2','0']) as choose,patch.object(ui,'input_report') as check,patch.object(ui,'apply',return_value=0) as install,contextlib.redirect_stdout(io.StringIO()):ui.install_menu(values)
        self.assertEqual(choose.call_args_list[0].args[1][:2],[('1','設定内容の不足を確認'),('2','手順1～4で保存した設定を使ってインストール')])
        check.assert_called_once_with(values);install.assert_called_once_with(values,repair=False)
    def test_all_isolated_stages_complete_and_record(self):
        from faxsetup import build,diagnostics
        with patch.object(host,'active',return_value=False),patch.object(host,'mkdir',side_effect=lambda p,*a:Path(p)),patch.object(host,'atomic'),patch.object(host,'run',side_effect=[Mock(stdout='PASS '*53),Mock(stdout='A3_LOOPBACK_PASS'),Mock(stdout='PASS')]),patch.object(host,'read_json',return_value={}),patch.object(host,'write_json') as write,patch.object(diagnostics,'stage') as stage:
            result=build.isolated_tests()
        self.assertEqual([result[k] for k in ('offline','a3','namespace')],['PASS']*3)
        self.assertEqual(stage.call_count,3);self.assertTrue(write.call_args_list[0].args[1]['tested'])
    def test_a3_conversion_failure_explains_child_stage(self):
        from faxsetup import build,diagnostics
        error=model.Failure(5,'systemd-run failed');error.details='A3_TEST_PHASE: PDF_TO_TIFF\nfaxmail.validation.Reject: RASTER_FAILED';error.command='systemd-run';error.returncode=1
        with patch.object(host,'active',return_value=False),patch.object(host,'mkdir',side_effect=lambda p,*a:Path(p)),patch.object(host,'atomic'),patch.object(host,'run',side_effect=[Mock(stdout='PASS '*53),error]),patch.object(host,'write_json') as write,patch.object(diagnostics,'stage'),self.assertRaises(model.Failure) as caught:build.isolated_tests()
        self.assertIn('試験PDFからFAX画像',str(caught.exception));self.assertIn('RASTER_FAILED',str(caught.exception));self.assertEqual(caught.exception.returncode,1)
        self.assertNotEqual(write.call_args.args[1]['a3'],'PASS')

class RC6DependencyTests(unittest.TestCase):
    def test_python_environment_checks_actual_imports_and_supplement_versions(self):
        from faxsetup import build
        metadata={'urls':[{'filename':'typing_extensions-4.15.0-py3-none-any.whl','digests':{'sha256':'a'*64}}]}
        response=Mock();response.__enter__=Mock(return_value=io.StringIO(json.dumps(metadata)));response.__exit__=Mock(return_value=False)
        profile={'pip':{'typing_extensions':'4.15.0'}}
        def execute(command,**kwargs):
            if 'import importlib.metadata' in str(command):return Mock(stdout='{"typing_extensions":"4.15.0"}')
            return Mock(stdout='')
        with patch.object(build.urllib.request,'urlopen',return_value=response),patch.object(host,'run',side_effect=execute) as run,patch.object(host,'atomic') as atomic,patch.object(host,'write_json') as write:
            build.python_environment(profile)
        commands=[c.args[0] for c in run.call_args_list]
        self.assertTrue(any('from pypdf import PdfReader' in str(c) for c in commands))
        self.assertTrue(any('m.requires(package)' in str(c) and c[-1]=='typing_extensions' for c in commands))
        self.assertIn('typing_extensions-requirements.txt',str(atomic.call_args.args[0]))
        self.assertEqual(write.call_args.args[1]['typing_extensions'],'4.15.0')
    def test_python_import_failure_stops_before_success_lock(self):
        from faxsetup import build
        error=model.Failure(5,'missing')
        with patch.object(host,'run',side_effect=[Mock(),error]),patch.object(host,'write_json') as write,self.assertRaises(model.Failure) as caught:build.python_environment({'pip':{}})
        self.assertIn('Python依存関係',str(caught.exception));write.assert_not_called()
    def test_offline_failure_names_missing_dependency(self):
        from faxsetup import build
        error=model.Failure(5,'systemd-run');error.details='OFFLINE_EXCEPTION: ModuleNotFoundError\nOFFLINE_MISSING_MODULE: typing_extensions\n'
        build.explain_offline_failure(error)
        self.assertIn('typing_extensions',str(error));self.assertIn('不足',str(error))
    def test_offline_failure_names_failed_case(self):
        from faxsetup import build
        error=model.Failure(5,'systemd-run');error.details='valid_plain: PASS\njapanese_pdf_tiff: FAIL\n'
        build.explain_offline_failure(error);self.assertIn('japanese_pdf_tiff',str(error));self.assertNotIn('valid_plain',str(error))
    def test_offline_error_does_not_print_exception_values(self):
        from faxsetup import offline
        error=ModuleNotFoundError('PRIVATE_VALUE',name='typing_extensions')
        with contextlib.redirect_stdout(io.StringIO()) as out:offline.report_error(error)
        self.assertIn('typing_extensions',out.getvalue());self.assertNotIn('PRIVATE_VALUE',out.getvalue())

class RC7ActivationTests(unittest.TestCase):
    def test_sip_option_matches_asterisk_generation(self):
        site,secrets=fixture()
        for os_version,expected in [('22.04',False),('24.04',True),('26.04',True)]:
            site['platform']['version_id']=os_version
            conf=model.generate(site,secrets)['/var/lib/fax-receive-live/etc/pjsip.conf'].decode()
            self.assertEqual('max_random_initial_delay=' in conf,expected)
            self.assertIn('[once-registration]',conf);self.assertIn('type=registration',conf)
    def test_readiness_names_only_unmet_conditions(self):
        engine={key:True for key in deploy.ENGINE_CHECKS};engine['registered']=False
        with self.assertRaises(model.Failure) as caught:deploy.require_engine_ready(engine)
        self.assertIn('SIP登録',str(caught.exception));self.assertNotIn('時刻同期',str(caught.exception))
        self.assertFalse(json.loads(caught.exception.details)['registered'])
    def test_unknown_and_truthy_values_are_not_ready(self):
        engine={key:True for key in deploy.ENGINE_CHECKS};engine['registered']='true';del engine['ntp']
        self.assertEqual(deploy.engine_pending(engine),['SIP登録','時刻同期'])
    def test_ready_engine_passes(self):deploy.require_engine_ready({key:True for key in deploy.ENGINE_CHECKS})
    def test_activation_failure_is_recorded(self):
        from faxsetup import diagnostics as d
        error=model.Failure(4,'SIP登録未完了')
        with patch.object(deploy,'_activate_managed',side_effect=error),patch.object(d,'record') as record,contextlib.redirect_stdout(io.StringIO()),self.assertRaises(model.Failure):deploy.activate_managed(True)
        record.assert_called_once_with(error)
    def test_staged_last_failure_shows_log(self):
        from faxsetup import ui
        state={'status':'STAGED','reason':'SIP登録未完了','last_failure':{'stage':'本番開始'},'failed_stage':'本番開始','error_log':'/safe/log.json'}
        with patch.object(host,'state',return_value=state),contextlib.redirect_stdout(io.StringIO()) as out:ui.show_status()
        for value in ['STAGED','SIP登録未完了','本番開始','/safe/log.json']:self.assertIn(value,out.getvalue())

class RC8SenderMenuTests(unittest.TestCase):
    def setUp(self):
        from faxsetup import ui
        self.ui=ui;self.values=list(model.inputs(*fixture()))
    def test_final_menu_has_five_and_opens_sender_management(self):
        with patch.object(self.ui,'choose',side_effect=['5','0']) as choose,patch.object(self.ui,'sender_menu') as menu:self.ui.final_menu(self.values)
        self.assertIn(('5','送受信メールアドレスの追加・削除・設定反映'),choose.call_args.args[1]);menu.assert_called_once_with(self.values)
    def test_add_saves_send_permission_without_applying(self):
        with patch.object(self.ui,'ask',return_value='new@example.invalid'),patch.object(self.ui,'save') as save,patch.object(self.ui,'finish_setup') as apply,contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values)
        self.assertIn('new@example.invalid',self.values[0]['mail']['allowed_senders']);self.assertNotIn('new@example.invalid',self.values[0]['mail']['receive_recipients'])
        save.assert_called_once();apply.assert_not_called();model.inputs(*self.values)
    def test_duplicate_sender_is_not_saved_twice(self):
        with patch.object(self.ui,'ask',return_value='sender@example.invalid'),patch.object(self.ui,'save') as save,contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values)
        save.assert_not_called()
    def test_existing_receiver_can_gain_send_permission(self):
        with patch.object(self.ui,'ask',return_value='recipient@example.invalid'),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values)
        self.assertIn('recipient@example.invalid',self.values[0]['mail']['allowed_senders']);self.assertIn('recipient@example.invalid',self.values[0]['mail']['receive_recipients'])
        self.assertEqual(len(self.values[3]['users']),2)
    def test_disabled_receiver_is_not_reactivated_when_adding_send(self):
        person=next(p for p in self.values[3]['users'] if p['receive']);person['enabled']=False;self.ui.sync_people(self.values)
        with patch.object(self.ui,'ask',return_value=person['email']),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values)
        self.assertIn(person['email'],self.values[0]['mail']['allowed_senders']);self.assertNotIn(person['email'],self.values[0]['mail']['receive_recipients'])
    def test_delete_last_sender_preserves_receive_permissions(self):
        person=next(p for p in self.values[3]['users'] if p['send']);person['receive']=True;self.ui.sync_people(self.values)
        with patch.object(self.ui,'ask',return_value='1'),patch.object(self.ui,'yes',return_value=True),patch.object(self.ui,'save') as save,contextlib.redirect_stdout(io.StringIO()):self.ui.sender_delete(self.values)
        self.assertEqual(self.values[0]['mail']['allowed_senders'],[]);self.assertIn(person['email'],self.values[0]['mail']['receive_recipients']);save.assert_called_once();model.inputs(*self.values)
    def test_cancel_delete_does_not_save(self):
        original=copy.deepcopy(self.values)
        with patch.object(self.ui,'ask',return_value='0'),patch.object(self.ui,'save') as save,contextlib.redirect_stdout(io.StringIO()):self.ui.sender_delete(self.values)
        self.assertEqual(self.values,original);save.assert_not_called()
    def test_bad_address_never_saved(self):
        with patch.object(self.ui,'ask',return_value='bad address'),patch.object(self.ui,'save') as save,self.assertRaises(model.Failure):self.ui.sender_add(self.values)
        save.assert_not_called()
    def test_save_failure_preserves_candidate_in_memory(self):
        original=copy.deepcopy(self.values)
        with patch.object(self.ui,'ask',return_value='new@example.invalid'),patch.object(self.ui,'save',side_effect=OSError()),self.assertRaises(OSError):self.ui.sender_add(self.values)
        self.assertEqual(self.values,original)
    def test_menu_apply_calls_existing_validated_workflow(self):
        with patch.object(self.ui,'applied',return_value=copy.deepcopy(self.values)),patch.object(self.ui,'choose',side_effect=['5','0']),patch.object(self.ui,'finish_setup',return_value=0) as apply,contextlib.redirect_stdout(io.StringIO()) as out:self.ui.sender_menu(self.values)
        apply.assert_called_once_with(self.values);self.assertIn('一時停止',out.getvalue());self.assertIn('他の項目',out.getvalue());self.assertIn('設定反映が完了',out.getvalue())
    def test_menu_does_not_claim_completion_on_cancel(self):
        with patch.object(self.ui,'applied',return_value=copy.deepcopy(self.values)),patch.object(self.ui,'choose',side_effect=['5','0']),patch.object(self.ui,'finish_setup',return_value=130),contextlib.redirect_stdout(io.StringIO()) as out:self.ui.sender_menu(self.values)
        self.assertIn('未完了',out.getvalue());self.assertNotIn('設定反映が完了',out.getvalue())
    def test_menu_shows_pending_addition_and_deletion(self):
        old=copy.deepcopy(self.values);person=next(p for p in self.values[3]['users'] if p['send']);person['email']='new@example.invalid';self.ui.sync_people(self.values)
        with patch.object(self.ui,'applied',return_value=old),patch.object(self.ui,'choose',return_value='0'),contextlib.redirect_stdout(io.StringIO()) as out:self.ui.sender_menu(self.values)
        self.assertIn('未反映の追加: new@example.invalid',out.getvalue());self.assertIn('未反映の削除: sender@example.invalid',out.getvalue())

class RC9ReceiveMenuTests(unittest.TestCase):
    def setUp(self):
        from faxsetup import ui
        self.ui=ui;self.values=list(model.inputs(*fixture()))
    def test_receive_add_does_not_grant_send(self):
        with patch.object(self.ui,'ask',return_value='receive-new@example.invalid'),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values,'receive')
        self.assertIn('receive-new@example.invalid',self.values[0]['mail']['receive_recipients']);self.assertNotIn('receive-new@example.invalid',self.values[0]['mail']['allowed_senders'])
        model.inputs(*self.values)
    def test_sender_can_gain_receive_without_duplicate_user(self):
        with patch.object(self.ui,'ask',return_value='sender@example.invalid'),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values,'receive')
        self.assertIn('sender@example.invalid',self.values[0]['mail']['receive_recipients']);self.assertIn('sender@example.invalid',self.values[0]['mail']['allowed_senders']);self.assertEqual(len(self.values[3]['users']),2)
    def test_disabled_send_is_not_reactivated(self):
        person=next(p for p in self.values[3]['users'] if p['send']);person['enabled']=False;self.ui.sync_people(self.values)
        with patch.object(self.ui,'ask',return_value=person['email']),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values,'receive')
        self.assertIn(person['email'],self.values[0]['mail']['receive_recipients']);self.assertNotIn(person['email'],self.values[0]['mail']['allowed_senders'])
    def test_duplicate_receiver_not_saved(self):
        with patch.object(self.ui,'ask',return_value='recipient@example.invalid'),patch.object(self.ui,'save') as save,contextlib.redirect_stdout(io.StringIO()):self.ui.sender_add(self.values,'receive')
        save.assert_not_called()
    def test_delete_last_receiver_retains_send_and_generates_empty_recipients(self):
        person=next(p for p in self.values[3]['users'] if p['receive']);person['send']=True;self.ui.sync_people(self.values)
        with patch.object(self.ui,'ask',return_value='1'),patch.object(self.ui,'yes',return_value=True),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):self.ui.sender_delete(self.values,'receive')
        self.assertEqual(self.values[0]['mail']['receive_recipients'],[]);self.assertIn(person['email'],self.values[0]['mail']['allowed_senders'])
        site,secrets,_,_=model.inputs(*self.values);files=model.generate(site,secrets)
        self.assertEqual(json.loads(files['/etc/faxmail-next/receive-mail-approved.json'])['recipients'],[])
    def test_generated_configs_include_both_roles(self):
        with patch.object(self.ui,'ask',return_value='both@example.invalid'),patch.object(self.ui,'save'),contextlib.redirect_stdout(io.StringIO()):
            self.ui.sender_add(self.values);self.ui.sender_add(self.values,'receive')
        site,secrets,_,_=model.inputs(*self.values);files=model.generate(site,secrets)
        self.assertIn('both@example.invalid',json.loads(files['/etc/faxmail-next/validation.json'])['mail']['allowed_senders'])
        self.assertIn('both@example.invalid',json.loads(files['/etc/faxmail-next/receive-mail-approved.json'])['recipients'])
    def test_receive_delete_cancel_keeps_configuration(self):
        old=copy.deepcopy(self.values)
        with patch.object(self.ui,'ask',return_value='1'),patch.object(self.ui,'yes',return_value=False),patch.object(self.ui,'save') as save,contextlib.redirect_stdout(io.StringIO()):self.ui.sender_delete(self.values,'receive')
        self.assertEqual(old,self.values);save.assert_not_called()
    def test_receive_save_error_does_not_mutate_memory(self):
        old=copy.deepcopy(self.values)
        with patch.object(self.ui,'ask',return_value='new@example.invalid'),patch.object(self.ui,'save',side_effect=OSError()),self.assertRaises(OSError):self.ui.sender_add(self.values,'receive')
        self.assertEqual(old,self.values)
    def test_menu_routes_receive_actions_and_apply(self):
        with patch.object(self.ui,'applied',return_value=copy.deepcopy(self.values)),patch.object(self.ui,'choose',side_effect=['3','4','5','0']),patch.object(self.ui,'sender_add') as add,patch.object(self.ui,'sender_delete') as delete,patch.object(self.ui,'finish_setup',return_value=0) as apply,contextlib.redirect_stdout(io.StringIO()):self.ui.sender_menu(self.values)
        add.assert_called_once_with(self.values,'receive');delete.assert_called_once_with(self.values,'receive');apply.assert_called_once_with(self.values)
    def test_menu_lists_receive_pending_changes(self):
        old=copy.deepcopy(self.values);person=next(p for p in self.values[3]['users'] if p['receive']);person['email']='new-receiver@example.invalid';self.ui.sync_people(self.values)
        with patch.object(self.ui,'applied',return_value=old),patch.object(self.ui,'choose',return_value='0'),contextlib.redirect_stdout(io.StringIO()) as out:self.ui.sender_menu(self.values)
        self.assertIn('受信PDF転送先',out.getvalue());self.assertIn('未反映の追加: new-receiver@example.invalid',out.getvalue());self.assertIn('未反映の削除: recipient@example.invalid',out.getvalue())

class RC10DispatchProbeTests(unittest.TestCase):
    def setUp(self):
        import importlib.util
        path=model.BUNDLE/'payload/opt/faxmail-next/scripts/fax-dispatch-preflight.py'
        spec=importlib.util.spec_from_file_location('dispatch_probe',path);self.probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.probe)
    @contextlib.contextmanager
    def folders(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'staging';target=Path(tmp)/'outgoing';source.mkdir();target.mkdir()
            yield source,target,{'fax':{'staging_spool':str(source),'outgoing_spool':str(target)}}
    @contextlib.contextmanager
    def posix_mode(self):
        original=Path.stat
        def stat(path,*a,**kw):
            result=original(path,*a,**kw)
            if path.name=='probe':
                fields=list(result);fields[0]=(result.st_mode&~0o777)|0o660;return os.stat_result(fields)
            return result
        with patch.object(self.probe.os,'fchmod',create=True),patch.object(Path,'stat',stat):yield
    def test_old_top_level_probe_loses_race_to_consumer(self):
        with self.folders() as (source,target,config):
            probe=source/'.fax-publish-probe-test';probe.write_bytes(b'not a call file');published=target/probe.name
            os.replace(probe,published)
            for path in target.iterdir():
                if path.is_file():path.unlink()
            self.assertFalse(published.exists())
    def test_nested_probe_survives_top_level_consumer_and_cleans_up(self):
        with self.folders() as (source,target,config),self.posix_mode():
            original=os.replace;destinations=[]
            def consume(a,b):
                destinations.append(Path(b));original(a,b)
                for path in target.iterdir():
                    if path.is_file():path.unlink()
            with patch.object(self.probe.os,'replace',side_effect=consume):self.probe.check(config)
            self.assertEqual(destinations[0].parent.parent,target)
            self.assertEqual(list(source.iterdir()),[]);self.assertEqual(list(target.iterdir()),[])
    def test_cross_mount_failure_is_not_ignored_and_cleans_up(self):
        import errno
        with self.folders() as (source,target,config),self.posix_mode(),patch.object(self.probe.os,'replace',side_effect=OSError(errno.EXDEV,'cross mount')):
            with self.assertRaises(OSError) as error:self.probe.check(config)
            self.assertEqual(error.exception.errno,errno.EXDEV);self.assertEqual(list(source.iterdir()),[]);self.assertEqual(list(target.iterdir()),[])
    def test_probe_diagnostics_omit_exception_values(self):
        import errno
        with contextlib.redirect_stdout(io.StringIO()) as out:self.probe.failure_details(PermissionError(errno.EACCES,'PRIVATE_MESSAGE','PRIVATE_PATH'))
        self.assertIn('PermissionError errno=',out.getvalue());self.assertNotIn('PRIVATE',out.getvalue())
    def test_service_failure_names_service_and_includes_journal(self):
        error=model.Failure(5,'systemctl failed');error.details='Job for faxmail-dispatch.service failed because the control process exited.'
        with patch.object(host,'run',side_effect=[error,Mock(stdout='dispatch_preflight_error: PermissionError errno=13')]),self.assertRaises(model.Failure) as caught:deploy.start_production_services(['faxmail-dispatch.service'])
        self.assertIn('faxmail-dispatch.service',str(caught.exception));self.assertIn('errno=13',caught.exception.details)
    def test_successful_systemctl_with_inactive_service_is_not_success(self):
        with patch.object(host,'run',return_value=Mock(stdout='')),patch.object(host,'active',return_value=False),self.assertRaises(model.Failure):deploy.start_production_services(['faxmail-dispatch.service'])
    def test_active_production_services_pass(self):
        with patch.object(host,'run'),patch.object(host,'active',return_value=True):deploy.start_production_services(['faxmail-dispatch.service'])

class RC14PackageFetchTests(unittest.TestCase):
    def test_update_fails_closed(self):
        from faxsetup import host
        with patch.object(host,'run',side_effect=model.Failure(5,'index error')) as run,patch.object(host,'package_plan') as plan:
            with self.assertRaises(model.Failure):host.install_packages({'packages':{'sample':'1'}})
        plan.assert_not_called();self.assertIn('APT::Update::Error-Mode=any',run.call_args.args[0])
    def test_404_refreshes_once_before_retry(self):
        from faxsetup import host
        e=model.Failure(5,'download error');e.details='404 Not Found'
        with patch.object(host,'run',side_effect=[e,None]) as run,patch.object(host,'refresh_package_indexes') as refresh,patch.object(host,'package_plan') as plan:
            host.download_packages({'sample':'1'})
        self.assertEqual(run.call_count,2);refresh.assert_called_once();plan.assert_called_once_with({'sample':'1'})
        self.assertIn('--download-only',run.call_args.args[0])
    def test_repeated_404_stops(self):
        from faxsetup import host
        e=model.Failure(5,'download error');e.details='404 Not Found'
        with patch.object(host,'run',side_effect=e) as run,patch.object(host,'refresh_package_indexes') as refresh,patch.object(host,'package_plan'):
            with self.assertRaises(model.Failure) as caught:host.download_packages({'sample':'1'})
        self.assertEqual(run.call_count,2);refresh.assert_called_once();self.assertIn('HTTP 404',str(caught.exception))
    def test_other_error_not_retried_as_missing_package(self):
        from faxsetup import host
        e=model.Failure(5,'download error');e.details='Get:404 ordinary package progress\nHash Sum mismatch'
        with patch.object(host,'run',side_effect=e),patch.object(host,'refresh_package_indexes') as refresh:
            with self.assertRaises(model.Failure):host.download_packages({'sample':'1'})
        refresh.assert_not_called()
    def test_download_failure_cannot_mutate_packages(self):
        from faxsetup import host
        with patch.object(host,'refresh_package_indexes'),patch.object(host,'package_plan'),patch.object(host,'active',return_value=False),patch.object(host,'download_packages',side_effect=model.Failure(5,'fail')),patch.object(host,'snapshot') as snapshot,patch.object(host,'run') as run:
            with self.assertRaises(model.Failure):host.install_packages({'packages':{'sample':'1'}})
        snapshot.assert_not_called();run.assert_not_called()
    def test_install_uses_only_downloaded_archives(self):
        from faxsetup import host
        import subprocess
        with patch.object(host,'refresh_package_indexes'),patch.object(host,'package_plan'),patch.object(host,'download_packages'),patch.object(host,'active',return_value=False),patch.object(host,'snapshot',return_value={}),patch.object(host,'atomic'),patch.object(host,'write_json'),patch.object(host,'restore_files') as restore,patch.object(host,'run',return_value=subprocess.CompletedProcess([],0,stdout='')) as run:
            host.install_packages({'packages':{'sample':'1'}})
        self.assertIn('--no-download',run.call_args_list[0].args[0]);restore.assert_called_once_with({})
    def test_critical_stderr_survives_tail_truncation(self):
        from faxsetup import host
        import subprocess
        result=subprocess.CompletedProcess([],100,stdout='Get: success\n'*4000,stderr='E: Failed to fetch archive: 404 Not Found')
        with patch.object(host.subprocess,'run',return_value=result):
            with self.assertRaises(model.Failure) as caught:host.run(['apt-get'])
        self.assertIn('E: Failed to fetch',caught.exception.details[-16000:])

class RC12SourceFetchTests(unittest.TestCase):
    def test_timeout_keeps_partial_binary_output(self):
        import subprocess
        from faxsetup import host
        cause=subprocess.TimeoutExpired(['apt-get'],600,output=b'partial index',stderr=b'connection timed out')
        with patch.object(host.subprocess,'run',side_effect=cause):
            with self.assertRaises(model.Failure) as ctx:host.run(['apt-get'],timeout=600)
        self.assertIn('partial index',ctx.exception.details)
        self.assertIn('connection timed out',ctx.exception.details)
        self.assertEqual(ctx.exception.command,'apt-get')
    def test_timeout_without_output_is_reportable(self):
        import subprocess
        from faxsetup import host
        with patch.object(host.subprocess,'run',side_effect=subprocess.TimeoutExpired(['apt-get'],600)):
            with self.assertRaises(model.Failure) as ctx:host.run(['apt-get'],timeout=600)
        self.assertEqual(ctx.exception.details,'\n')
    def test_source_fetch_is_bounded_and_fail_closed(self):
        from faxsetup import build
        options=build.source_options(Path('/tmp/sources'),Path('/tmp/lists'))
        for value in ['Acquire::https::Timeout=15','Acquire::http::Timeout=15','Acquire::Retries=2','APT::Update::Error-Mode=any']:
            self.assertIn(value,options)
        self.assertFalse(any('AllowUnauthenticated' in x or 'Verify-Peer' in x for x in options))
    def test_index_failure_prevents_source_download(self):
        from faxsetup import build,host,diagnostics
        error=model.Failure(5,'APT failure');error.details='network failure'
        with patch.object(host,'run',side_effect=error) as run,patch.object(diagnostics,'stage') as progress:
            with self.assertRaises(model.Failure) as ctx:build.fetch_asterisk_source([], 'test-version',Path('/tmp/stage'))
        self.assertEqual(run.call_count,1)
        self.assertIn('ソース索引',str(ctx.exception));self.assertEqual(ctx.exception.details,'network failure')
    def test_source_download_has_separate_stage(self):
        from faxsetup import build,host,diagnostics
        with patch.object(host,'run') as run,patch.object(diagnostics,'stage') as progress:
            build.fetch_asterisk_source([], 'test-version',Path('/tmp/stage'))
        self.assertEqual(run.call_count,2)
        self.assertIn('固定版ソース',progress.call_args.args[0])
        self.assertIn('asterisk=test-version',run.call_args.args[0])

class RC11ArchitectureTests(unittest.TestCase):
    def test_all_six_platform_combinations(self):
        for version in model.VERSIONS:
            for arch in ('amd64','arm64'):
                with self.subTest(version=version,arch=arch):
                    site,secrets=fixture();site['platform'].update(version_id=version,architecture=arch)
                    values=model.inputs(site,secrets);profile=model.platform_profile(version,arch);plan=deploy.plan(*values)
                    self.assertEqual(profile['arch'],arch);self.assertEqual(plan['platform']['architecture'],arch)
                    self.assertEqual(plan['packages'],profile['packages']);model.generate(site,secrets)
    def test_arm_uses_ports_and_separate_package_versions(self):
        arm=model.platform_profile('22.04','arm64');amd=model.platform_profile('22.04','amd64')
        self.assertEqual(arm['source_archive'],'https://ports.ubuntu.com/ubuntu-ports')
        self.assertEqual(arm['packages']['pkg-config'],'0.29.2-1ubuntu3')
        self.assertIsNot(arm,amd)
    def test_armhf_is_rejected(self):
        with self.assertRaises(model.Failure):model.platform_profile('22.04','armhf')
    def test_unknown_os_is_rejected(self):
        with self.assertRaises(model.Failure):model.platform_profile('25.10','arm64')
    def test_default_candidate_uses_detected_architecture(self):
        from faxsetup import ui
        with tempfile.TemporaryDirectory() as tmp,patch.object(host,'ADMIN',Path(tmp)),patch.object(host,'platform',return_value={'version':'24.04','arch':'arm64'}):values=ui.applied()
        self.assertEqual(values[0]['platform']['architecture'],'arm64')
    def test_unsupported_host_exits_before_retry_loop(self):
        from faxsetup import ui
        error=model.Failure(3,'unsupported architecture')
        with patch.object(host,'root_required'),patch.object(sys.stdin,'isatty',return_value=True),patch.object(host,'platform',side_effect=error) as platform,patch.object(ui,'load') as load,contextlib.redirect_stderr(io.StringIO()) as err:
            result=cli.entry(['install'])
        self.assertEqual(result,3);platform.assert_called_once();load.assert_not_called();self.assertEqual(err.getvalue().count('unsupported architecture'),1)
    def test_native_host_architecture_selects_profile(self):
        with patch.object(Path,'exists',return_value=True),patch.object(Path,'read_text',return_value='ID=ubuntu\nVERSION_ID="26.04"\n'),patch.object(host,'run',side_effect=[Mock(stdout='arm64\n')]),patch.object(host,'platform_profile',return_value={'version':'26.04','arch':'arm64'}) as profile:
            self.assertEqual(host.platform()['arch'],'arm64')
        profile.assert_called_once_with('26.04','arm64')
    def test_install_rejects_mismatched_cpu_before_mutation(self):
        site,secrets=fixture();site['platform']['architecture']='arm64';values=model.inputs(site,secrets)
        with patch.object(deploy,'bundle_check'),patch.object(host,'platform',return_value=model.platform_profile('22.04','amd64')),patch.object(host,'set_state') as change,self.assertRaises(model.Failure):deploy._install(*values,experimental=True)
        change.assert_not_called()

if __name__=='__main__':unittest.main(verbosity=2)
