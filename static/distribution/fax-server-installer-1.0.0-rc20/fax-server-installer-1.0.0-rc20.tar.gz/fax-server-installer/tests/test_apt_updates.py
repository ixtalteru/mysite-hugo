import unittest,json,sys
from pathlib import Path
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from faxsetup import apt_resolve as a,host,model
class AptUpdateTests(unittest.TestCase):
 def validate(self,**kw):
  d=dict(name='ghostscript',version='2',installed='1',origins=[dict(origin='Ubuntu',archive='noble-security',trusted=True)],codename='noble',source='ghostscript',compare=lambda x,y:(x>y)-(x<y));d.update(kw);a.validate_version(**d)
 def test_official_update_allowed(self):self.validate()
 def test_downgrade_blocked(self):
  with self.assertRaises(ValueError):self.validate(version='0')
 def test_ppa_blocked(self):
  with self.assertRaises(ValueError):self.validate(origins=[dict(origin='LP-PPA',archive='noble',trusted=True)])
 def test_other_os_blocked(self):
  with self.assertRaises(ValueError):self.validate(origins=[dict(origin='Ubuntu',archive='jammy-security',trusted=True)])
 def test_unsigned_blocked(self):
  with self.assertRaises(ValueError):self.validate(origins=[dict(origin='Ubuntu',archive='noble',trusted=False)])
 def test_installed_only_not_downloadable(self):
  with self.assertRaises(ValueError):self.validate(origins=[dict(archive='now')])
 def test_fixed_asterisk_update_blocked(self):
  with self.assertRaises(ValueError):self.validate(name='asterisk',source='asterisk',fixed_version='1')
 def test_fixed_asterisk_available_passes(self):self.validate(name='asterisk-dev',source='asterisk',fixed_version='2')
 def test_unknown_asterisk_binary_blocked(self):
  with self.assertRaises(ValueError):self.validate(name='new-binary',source='asterisk')
 def test_sounds_dynamic(self):
  for name in ['asterisk-core-sounds-en','asterisk-core-sounds-en-gsm','asterisk-core-sounds-en:arm64']:self.assertFalse(a.fixed(name))
 def test_core_family_stays_fixed(self):
  for name in ['asterisk','asterisk-config','asterisk-dev','asterisk-modules','asterisk-new-module']:self.assertTrue(a.fixed(name))
 def test_sound_update_allowed(self):self.validate(name='asterisk-core-sounds-en',source='asterisk-core-sounds',version='2')
 def test_core_source_cannot_bypass_lock_as_sound(self):
  with self.assertRaises(ValueError):self.validate(name='asterisk-core-sounds-en',source='asterisk')
 def test_spandsp_dynamic(self):self.assertFalse(a.fixed('libspandsp2t64'))
 def test_full_plan_replaces_snapshot(self):
  p={'ghostscript':'1'}
  with patch.object(host,'run',return_value=Mock(returncode=0,stderr='',stdout=json.dumps({'packages':{'ghostscript':'2','libgs10':'2'}}))):host.package_plan(p)
  self.assertEqual(p,{'ghostscript':'2','libgs10':'2'})
 def test_invalid_plan_leaves_input_unchanged(self):
  p={'ghostscript':'1'}
  with patch.object(host,'run',return_value=Mock(returncode=3,stderr='downgrade')),self.assertRaises(model.Failure):host.package_plan(p)
  self.assertEqual(p,{'ghostscript':'1'})
 def test_retry_uses_new_versions(self):
  p={'ghostscript':'1'};e=model.Failure(5,'missing');e.details='404 Not Found'
  def resolve(packages):packages.update(ghostscript='2',libgs10='2')
  with patch.object(host,'run',side_effect=[e,None]) as run,patch.object(host,'refresh_package_indexes'),patch.object(host,'package_plan',side_effect=resolve):host.download_packages(p)
  self.assertIn('ghostscript=2',run.call_args.args[0]);self.assertIn('libgs10=2',run.call_args.args[0])
if __name__=='__main__':unittest.main()
