# Ubuntu22 RC6導入失敗の修正・実機検証（[検証日時非公開]）

## 結果

Ubuntu22（検証サーバーUbuntu22）に保存済み設定を使い、RC6インストーラーから再導入してSTAGED（構築済み・未接続）まで完了した。外部接続・FW切替・本番開始は行っていない。Ubuntu24とUbuntu26のサーバーは変更していない。

## 失敗原因

利用者指定の `[検証ログパス非公開]` を実サーバーから読み取った。24項目のPASS後、詳細を表示しない `operation: FAIL` で止まっていた。

ネットワーク隔離、faxmailユーザー、同じPython仮想環境で合成データ試験を再現した結果、PDF変換モジュールのimport時に次の例外を確認した。

```text
pypdf/_utils.py: from typing_extensions import Self
ModuleNotFoundError: No module named 'typing_extensions'
```

Ubuntu22はPython 3.10。pypdf 6.9.2はPython 3.11未満で `typing_extensions>=4.0` を要求するが、RC5は `--no-deps` でpypdfだけを入れていた。配布メタデータにもこの条件が記載されている。[pypdf公式PyPIメタデータ](https://pypi.org/pypi/pypdf/6.9.2/json)

実機のAPT候補 `python3-typing-extensions` は3.10.0.2-1、未導入。APT版を追加するだけでは必要版を満たせない。

## 修正内容

1. Ubuntu22の専用venvに `typing_extensions==4.15.0` を固定版として追加。公式PyPIのwheelハッシュを検証して導入する。pypdf 6.9.2を維持し、システムPythonは置き換えない。[typing_extensions公式PyPIメタデータ](https://pypi.org/pypi/typing_extensions/4.15.0/json)
2. Python環境構築時に実際のimportと、補完wheelが宣言する必須依存・Python版条件を検査する。パッケージが存在するだけで成功にしない。
3. 補完パッケージごとにrequirements・取得元・ハッシュを保存する。dependency-lockにもtyping_extensionsの実版を記録する。
4. オフライン試験はインストーラー専用ランナーで実行。不合格項目名、不足モジュール、例外種別を表示し、値・コード本文を含めない発生位置をroot限定詳細ログへ保存する。
5. 失敗時には検証記録のofflineをFAILにする。試験の成功条件・隔離設定は維持する。

開発中の全環境pip checkでは、--system-site-packages経由で見えるFAXと無関係なPyGObjectのpycairo依存も検出した。このため、最終版はインストーラーが補完するwheelの依存を対象に検査する。PDF処理等の実importと、53項目の実処理検証は両方実行する。

## 検証結果

|項目|結果|
|---|---|
|ローカル回帰試験|100件PASS|
|Ubuntu22/24/26の計画生成|3OS PASS|
|配布payloadの整合性|73ファイルPASS|
|実機のPython依存導入・読み込み検査|PASS|
|実機のオフライン回帰試験|53件PASS|
|A4/A3/A4内部FAX送信|SUCCESS 3|
|A4/A3/A4内部FAX受信|SUCCESS 3|
|受信TIFF幅・PDF用紙サイズ検査|PASS|
|発信ディレクトリ隔離試験|PASS|
|管理ファイルhash・権限、導入状態、未接続状態の最終診断|すべてPASS|
|完了状態|STAGED / 1.0.0-rc6 / Ubuntu22.04|

内部FAXログ: `[検証ログパス非公開]`。
[検証時刻非公開]:26に `A3TEST rx SUCCESS 3`、[検証時刻非公開]:27に `A3TEST tx SUCCESS 3` を確認した。

導入済みPython依存: WeasyPrint54.1、Pillow9.0.1、pypdf6.9.2、dkimpy1.0.5、dnspython2.1.0、typing_extensions4.15.0。

## 操作の再開

Ubuntu22にはRC6の管理ツールが配置済み。今回の修正のための再インストールは不要。

```sh
sudo --preserve-env=SSH_CONNECTION fax-admin
```

本番切替は手順6で実施する。同じSIP/メール設定で稼働している別サーバーを停止してから本番を開始する。

## 検証範囲と残件

SIP/IMAP/SMTPの実接続、外線FAX、FW切替、アンインストール／再導入の全工程は今回未検証。RC6をUbuntu24/26へ実導入していない。全受入完了ではないためrelease_tested=falseを維持する。

本修正は依存の導入漏れが対象で、pypdf自体の版は更新していない。公式PyPIの6.9.2メタデータには既知の脆弱性情報も掲載されており、その解消に向けた版更新・互換性検証は残る。今回の内部試験成功は脆弱性解消を意味しない。
