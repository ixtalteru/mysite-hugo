# Ubuntu22 RC7 本番開始失敗の修正と実機検証（[検証日時非公開]）

## 結果

検証サーバーUbuntu22のUbuntu22をインストーラー経由でRC7へ更新し、手順6から本番開始に成功した。最終状態はACTIVE、SIP登録・時刻同期・FAXモジュール・FWはすべて正常。送受信サービスと受信PDFメール転送のタイマーもactive/enabledを確認した。

## 原因

失敗直後の `/var/lib/fax-engine-state/engine-state.json` は registered=false、idle/channels_known/modules/ntp/firewall=trueだった。時刻同期やFWではなく、SIP登録だけが未達だった。

実サーバーの `/var/lib/fax-receive-live/log/fax-notices` に、[検証時刻非公開]:37の次のエラーが残っていた。

```text
Could not find option suitable for category 'once-registration' named 'max_random_initial_delay' at line 23
Could not create an object of type 'registration' with id 'once-registration' from configuration file 'pjsip.conf'
```

Ubuntu22のAsterisk18.10は、この設定項目に対応していない。共通テンプレートが新しいAsterisk向け項目を出力していたため、SIP登録オブジェクト自体が作成されず、本番開始の準備判定を通過できなかった。

## 修正

- Ubuntu22用のpjsip.conf生成からmax_random_initial_delayを除外。Ubuntu24/26は従来の設定を維持。
- 本番準備の確認をSIP登録、通話待機、通話状態取得、FAXモジュール、時刻同期、FWに分け、未達項目だけを表示。
- 本番開始の失敗も工程・理由・各準備条件の真偽値をroot限定詳細ログに記録。STAGEDへ戻った後も画面に失敗工程とログの場所を表示。
- 失敗時のサービス停止・ゲート無効化で別の例外が発生しても元のエラーを保持。停止処理自体が失敗した場合はFAILEDとする。

SIPアカウント・秘密値・メール設定は保存値を引き継いだ。確定済みSSH/FWも引き継ぎ、SSH/FWの再試行は不要だった。他のサーバーは変更していない。

## 実機検証

利用者が旧サーバー停止と通話完了を確認した操作を引き継ぎ、対話端末でRC7のinstall.shを実行した。手順5で更新・内部試験を完了後、手順6 → 1から接続検証と本番開始を行った。

|確認項目|結果|
|---|---|
|ローカル回帰試験|106件PASS|
|3OSの計画生成・秘密情報混入検査・配布物整合性|PASS|
|Ubuntu22のオフライン回帰・A3混在内部FAX・発信隔離試験|PASS|
|IMAP接続（読み取り専用）|PASS|
|SMTP認証（検証メール送信なし）|PASS|
|本番SIP登録|true|
|通話待機・通話状態取得|true / true|
|FAXモジュール・時刻同期・FW|すべてtrue|
|fax-receive-live.service|active / enabled|
|faxmail-next.service|active / enabled|
|faxmail-dispatch.service|active / enabled|
|broker・cleanup・maintenance・receive-mailの各timer|active / enabled|
|送信処理ゲート・受信メール転送ゲート|両方配置済み|
|メール処理開始位置|baseline_done=true|
|最終インストーラー診断（本番サービス、FW/SSH、hash等）|全項目PASS|
|導入状態|ACTIVE / 1.0.0-rc7 / Ubuntu22.04|

準備表示は「SIP登録等を待機」→「SIP登録だけを待機」→「すべてOK」と進み、本番開始が完了した。更新後の実pjsip.confから非対応項目が除かれていることも値を表示せず確認した。

## 続けて操作する場合

Ubuntu22の管理ツールは更新済み。再インストール・再度の本番開始操作は不要。

```sh
sudo --preserve-env=SSH_CONNECTION fax-admin
```

本番サービスは既に稼働中。外線からの試験FAXとメール転送の実配送は今回未実施なので、実回線の送受信成功までは確認していない。Ubuntu24/26へのRC7実導入や全OSの全受入試験は未実施であり、release_tested=falseを維持する。既存依存版に関する残件は前回のUbuntu22実機検証.mdに記載した内容を継承する。
