# RC11 ARM対応と検証範囲

検証日: [検証日時非公開]

## 対応内容

Ubuntu 22.04・24.04・26.04それぞれでamd64とarm64を判定する。Raspberry Piには64ビットUbuntuを使用する。32ビットarmhfやRaspberry Pi OSは対象外。

CPUごとに依存関係プロファイルを分け、arm64はUbuntu Portsの署名付きリポジトリからAsteriskソースを取得する。A3対応モジュールは対象機のgccでビルドし、OSのモジュール配置場所をdpkgで取得する。Python補完wheelはアーキテクチャ非依存。

「amd64専用です」が繰り返された原因は、メニュー内でCPU判定の失敗を捕捉した後、入力を待たずに同じ判定へ戻る処理だった。起動前にOS・CPUを一度確認する構成へ変更し、非対応環境では終了コード3で終了する。

## 全3 OSのarm64依存関係

Ubuntu公式の https://ports.ubuntu.com/ubuntu-ports から、jammy / noble / resolute と各updates・securityの索引を取得。Ubuntuのアーカイブ鍵で署名を検証した。一時ディレクトリ内の独立APT設定・空のインストール済み状態を使い、固定版の導入を `apt-get -s --no-remove install` で予行検査した。

|OS|署名検証|依存解決|予行検査の新規パッケージ数|削除数|
|---|---|---|---|---|
|Ubuntu 22.04 arm64|PASS|PASS|498|0|
|Ubuntu 24.04 arm64|PASS|PASS|522|0|
|Ubuntu 26.04 arm64|PASS|PASS|529|0|

バージョン一覧は [arm64-apt-audit.json](arm64-apt-audit.json)。この検査は実際のUbuntu24・26カーネル上での動作試験ではない。対象実機の既存パッケージやAPT設定によっては、別途事前検査で停止することがある。

## 自動テスト

Windows側143件、Raspberry PiのUbuntu22/Python3.10側143件が成功。3 OS × 2 CPUの計6構成で設定検証・設定生成・導入計画生成が成功。未対応CPUのエラーが一度だけ表示され、終了コード3で停止することも検証した。

記録: [local-tests.txt](local-tests.txt)、[arm64-native-tests.txt](arm64-native-tests.txt)。

## 実機の導入試験

対象: Raspberry Pi 4 Model B、Ubuntu 22.04.5、arm64/aarch64、メモリー約3.7GiB。

インストーラーの対話メニュー1～5で管理・SIP・メール・利用者・FW候補を保存し、本体を導入した。入力49項目に応答し、終了コード0で完了した。状態は `STAGED`（構築済み・未接続）。

|検査|結果|
|---|---|
|導入前検査（OS/CPU・空き容量・メモリー・SSH鍵・APT）|PASS|
|パッケージ導入・専用Python環境|PASS|
|A3モジュールのネイティブビルド|PASS（ELF64 / AArch64）|
|systemd定義|PASS|
|ネットワーク隔離のオフライン回帰試験|53項目PASS|
|A4・A3混在3ページの内部FAX送受信|PASS|
|発信ディレクトリの隔離環境試験|PASS|
|管理ファイルのハッシュ・権限|PASS|
|標準Asterisk停止・未接続状態|PASS|

本番ゲートファイルなし、FAX本番サービス・タイマーはすべて停止を確認。FWは候補保存のみで、試行・適用は行っていない。SIP登録、IMAP・SMTP接続、外線FAX試験は実行していない。

実測では初回パッケージ導入に約16分、オフライン回帰試験に約5分を要した。ストレージや回線速度で所要時間は変わる。

詳細記録: [arm64-acceptance.txt](arm64-acceptance.txt)。

## 未検証の範囲

Ubuntu24・26のarm64実機でのA3ビルド、systemd隔離、内部FAX試験、外線送受信は未実施。各実機のインストーラー内検査で合格を確認する必要がある。全プラットフォームでRCの確認表示を維持する。

この版のamd64は既存機への再導入を行わず、構成生成と自動テストで回帰確認した。過去版の実機記録は別文書に記載している。
