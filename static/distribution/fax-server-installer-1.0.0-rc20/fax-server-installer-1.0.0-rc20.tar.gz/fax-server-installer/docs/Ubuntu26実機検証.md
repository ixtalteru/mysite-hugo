# Ubuntu26 RC5導入失敗の修正・実機検証（[検証日時非公開]）

## 原因

対象: Ubuntu26.04、検証サーバーUbuntu26。利用者指定の `[検証ログパス非公開]` を実サーバーから読み取った。

RC4はA3内部FAX試験の合成PDFを画像化する段階で `faxmail.validation.Reject: RASTER_FAILED` が発生していた。systemd-runの終了コード1は子試験の失敗結果であり、systemdそのものの障害を示すものではなかった。

Ghostscript 10.06.0（10.06.0~dfsg-3ubuntu1）を同じasteriskユーザーで実行すると、永続試験フォルダのPDFは `undefinedfilename / Last OS error: Permission denied` で失敗した。そのPDFは同じユーザーのPythonから読み取れた。同一PDFを `/tmp` の所有者限定フォルダへコピーするとGhostscriptは終了コード0でTIFFを作成した。

実サーバーの `/etc/apparmor.d/gs` は `/var/lib/fax-installer-tests` やFAXの本番作業フォルダへのアクセスを許可せず、所有者の一時ファイルへのアクセスを許可していた。以上から、Ghostscript用AppArmorプロファイルと従来の作業パスの不整合を原因と判断した。

最初の「入力設定: OK」の下に出ていたFAILEDは保存済みの以前の導入結果。入力・読み取り環境検査はソース構築やPDF変換・内部FAX通信を実施しないため、以前のFAILEDを成功に置き換えない。工程記録のない旧版の失敗原因をその表示だけから復元することはできない。

## 修正

- 手順5の先頭を「1. 設定内容の不足を確認」、次を「2. 保存した設定を使ってインストール」に変更。実際の選択動作も変更した。
- 確認画面で、保存された導入状態と今回の入力・環境検査の合否を区別して説明。
- Ghostscript用の入力PDF・出力TIFFは `/tmp/fax-raster-*` の所有者限定一時領域を使用。サービスのPrivateTmpを維持し、AppArmorの無効化・ルール追加は行わない。
- 完成TIFFを永続フォルダへコピー。1グループの変換も別ファイルシステム間で動作する。
- 内部試験で進捗関数stageと作業ディレクトリstageが衝突していた潜在不具合を解消。
- A3子試験の失敗箇所をPDF画像変換・Asterisk起動・FAX通信・受信PDF変換に分けて表示。Asterisk起動出力を試験用ログへ保存。

## 実機結果

更新版を別フォルダへ展開し、sudo bash install.shを対話端末で実行した。保存済み設定を使用し、「5 → 1」で事前検査、「5 → 2」で導入を実施した。

|確認|結果|
|---|---|
|新しいメニュー順序・事前検査・結果のEnter待ち|PASS|
|APT導入・Python環境・A3モジュール構築|PASS|
|ネットワーク隔離でのオフライン回帰53件|PASS|
|A4/A3/A4の内部FAX送信|SUCCESS 3|
|A4/A3/A4の内部FAX受信|SUCCESS 3|
|受信TIFF幅1728/2432/1728、受信PDFのA4/A3/A4|PASS|
|発信ディレクトリの隔離環境試験|PASS|
|A4単ページの変換・別ファイルシステムへの保存|PASS|
|A3単ページの変換・別ファイルシステムへの保存|PASS|
|最終のインストーラー診断・管理ファイルhash/権限|PASS|
|導入完了状態|STAGED（構築済み・未接続）|

内部FAXの成功ログ: `[検証ログパス非公開]`。[検証時刻非公開]:35に `A3TEST rx SUCCESS 3`、[検証時刻非公開]:36に `A3TEST tx SUCCESS 3` を確認した。

ローカル回帰95件、3OSの計画生成、73配布payloadのhash、Python構文、秘密情報混入検査、配布アーカイブ往復検証がPASS。

SIP/IMAP/SMTPの実接続、外線FAX送受信、FW切替、本番開始は今回の検証対象外。Ubuntu24の稼働サーバー検証サーバーUbuntu24は変更していない。Ubuntu22/24へのRC5実導入と全OSの全受入試験は未実施のためrelease_tested=falseを維持する。

## サーバーで再開する方法

Ubuntu26にはRC5管理ツールが配置済み。以下で開ける。

```sh
sudo --preserve-env=SSH_CONNECTION fax-admin
```

既にSTAGEDまで導入済みのため、今回の修正を適用するための再インストールは不要。本番移行時は手順6へ進む。同じSIP/メールアカウントを利用する稼働サーバーを停止してから本番開始する。
