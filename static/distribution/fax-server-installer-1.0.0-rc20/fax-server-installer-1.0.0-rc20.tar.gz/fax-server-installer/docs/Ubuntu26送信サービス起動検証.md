# Ubuntu26 RC10 送信サービス起動失敗の修正（[検証日時非公開]）

## 結果

Ubuntu26（検証サーバーUbuntu26）をインストーラー経由でRC10へ更新し、本番開始まで完了した。現在の状態はACTIVE。Asterisk稼働中の送信起動前検査20回がすべてPASSし、最終診断も全項目PASS。

## 原因を示す実ログ

指定された `[検証ログパス非公開]` は「本番サービスの開始」工程で、faxmail-dispatch.serviceのcontrol processが終了コード1になった記録だった。

サービスjournalでは17:53:34に `dispatch_preflight: FAIL` が記録されていた。同時刻の `/var/lib/fax-receive-live/log/fax-notices` に、Asteriskが `.fax-publish-probe-...` を読み、構文不正な発信指示として削除した記録があった。

```text
Syntax error at line 1 of .../outgoing/.fax-publish-probe-...
Invalid file contents in .../outgoing/.fax-publish-probe-..., deleting
```

起動前検査は送信準備から送信待ちフォルダ直下へ通常ファイルを移し、その存在と権限を確認していた。Asteriskが先に削除すると検査はFAILになる。[検証時刻非公開]:22にはPASS、[検証時刻非公開]:50と17:53:34にはFAILとなっており、実行順序によって結果が変わる競合だった。

実機に取得済みのAsterisk22.5.2ソース `pbx/pbx_spool.c` でも、通常ファイルを処理し、ディレクトリはS_ISREG判定で除外することを確認した。ファイル名のドットや.call以外の拡張子は監視からの除外条件にならない。

## 修正

- 両スプール内に所有者限定の一時サブディレクトリを作り、その内部で検査ファイルの移動を行う。Asteriskはディレクトリ内部を再帰処理しない。
- 同じ送信ユーザーとsystemd隔離条件で原子的な移動・ファイル権限を確認する。別マウント間のEXDEVを無視しない。検査後は一時ファイルとディレクトリを片付ける。
- 起動前検査が失敗した場合は例外種別とerrnoを表示する。秘密値・設定・パス等の例外値は出力しない。
- 本番サービス起動の失敗時はサービス名を画面へ表示し、そのサービスのjournalを既存の秘密情報マスク付き詳細ログへ含める。
- systemctl成功後にも、要求した本番サービス・タイマーが稼働中であることを確認してからACTIVEへ進む。

実際のFAX発信ファイルの生成・公開方法は従来どおり。変更したのは起動前検査のファイル配置方法と、インストーラーの起動結果検査・診断。

## 検証

|確認|結果|
|---|---|
|ローカル回帰|135件PASS|
|旧方式のファイルを監視側が先に削除する競合の再現|再現|
|修正方式で監視側が同時動作しても検査成功・後片付け|PASS|
|EXDEVの伝達・後片付け、失敗ログの値非表示|PASS|
|サービス名とjournal取得・非稼働サービスの検出|PASS|
|Ubuntu22/24/26の計画生成|PASS|
|Ubuntu26のオフライン回帰・A3混在内部FAX・隔離検査|PASS|
|IMAP接続・SMTP認証|PASS（検証メール送信なし）|
|SIP登録・本番開始|PASS、ACTIVE|
|本番Asterisk稼働中の同等隔離条件による起動前検査|20/20 PASS|
|繰り返し検査中にAsteriskが不正な検査ファイルを処理した件数|0|
|最終診断：本番サービス、管理ファイルhash・権限、FW/SSH等|全項目PASS|

実機繰り返し検査は、実行ユーザーfaxdispatch、NoNewPrivileges、ProtectSystem=strict、ProtectHome、PrivateTmp、PrivateNetwork、UMask0077とスプールの書き込み範囲指定を使用した。実FAXを発信するファイルは作成していない。

保存済みの送信許可2件・受信PDF転送先2件を引き継いだ。メールアドレスやSIPの個人情報は配布物に含めていない。他サーバーは変更していない。

## 再開方法と検証範囲

Ubuntu26の管理ツールはRC10へ更新済みで、本番サービスも稼働中。再インストールや本番開始のやり直しは不要。

```sh
sudo --preserve-env=SSH_CONNECTION fax-admin
```

外線FAX送受信と受信PDFのメール実配送は今回未検証。Ubuntu22/24でのRC10実機導入も未検証。全受入完了ではないためrelease_tested=falseを維持する。過去のOS別検証記録は、その時点のRC版・環境に対する記録である。
