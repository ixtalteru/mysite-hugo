"""Polling intake and notification worker, gated by root-owned acceptance."""
import email.utils,json,os,re,shutil,time
from datetime import timezone
from pathlib import Path
from .mailio import imap_connect,notification,send_notification
from .store import Store
from .validation import parse,Reject,require
from . import control

STATE=Path('/var/lib/faxmail-next')
SPOOL=Path('/var/spool/faxmail-next/jobs')
GATE=Path('/etc/faxmail-next/acceptance-approved.json')

def gate():
    require(GATE.is_file() and not GATE.is_symlink(),'ACCEPTANCE_REQUIRED')
    st=GATE.stat()
    require(st.st_uid==0 and not st.st_mode&0o022,'ACCEPTANCE_PERMISSIONS')
    data=json.loads(GATE.read_text())
    require(data.get('mode') in ['test','production'],'MODE_INVALID')
    require(data.get('persistent') is True or data.get('expires',0)>time.time(),'AUTHORIZATION_EXPIRED')
    require(data.get('mail_send') is True and data.get('fax_send') is True,'SEND_NOT_AUTHORIZED')
    return data

def response_integer(client,name):
    result=client.response(name)[1]
    require(result and result[0] and result[0].isdigit(),'IMAP_METADATA_MISSING')
    return int(result[0])

def fetch_bounded(client,uid):
    status,rows=client.uid('FETCH',str(uid),'(RFC822.SIZE INTERNALDATE)')
    require(status=='OK','IMAP_FETCH_FAILED')
    metadata=b' '.join(r for r in rows if isinstance(r,bytes))
    match=re.search(rb'RFC822.SIZE (\d+)',metadata)
    date=re.search(rb'INTERNALDATE "([^"]+)"',metadata)
    require(match and date,'IMAP_METADATA_MISSING')
    size=int(match.group(1));require(size<=25*1024*1024,'MAIL_SIZE')
    import datetime
    stamp=datetime.datetime.strptime(date.group(1).decode('ascii'),'%d-%b-%Y %H:%M:%S %z').timestamp()
    require(stamp>time.time()-168*3600,'MAIL_EXPIRED')
    body=bytearray()
    for offset in range(0,size,65536):
        requested=min(65536,size-offset)
        status,rows=client.uid('FETCH',str(uid),'(BODY.PEEK[]<'+str(offset)+'.'+str(requested)+'>)')
        require(status=='OK','IMAP_FETCH_FAILED')
        literals=[r[1] for r in rows if isinstance(r,tuple)]
        require(len(literals)==1 and len(literals[0])==requested,'IMAP_PARTIAL_FETCH')
        body.extend(literals[0]);require(len(body)<=25*1024*1024,'MAIL_SIZE')
    require(len(body)==size,'IMAP_PARTIAL_FETCH')
    return bytes(body)

def ingest_once(config,store,client,authorization):
    require(shutil.disk_usage(SPOOL).free>=2*1024**3,'DISK_LOW')
    folder=config['mail']['imap'].get('folder','INBOX')
    require(folder.upper()=='INBOX','MAILBOX_UNSUPPORTED')
    result=client.select('INBOX',readonly=True)
    require(result[0]=='OK','IMAP_SELECT_FAILED')
    validity=response_integer(client,'UIDVALIDITY');uidnext=response_integer(client,'UIDNEXT')
    account=store.digest(config['mail']['fax_address'].encode())
    highwater=store.baseline(account,validity,uidnext,initialize=authorization.get('initialize_mailbox') is True)
    status,rows=client.uid('SEARCH',None,'UID',str(highwater+1)+':*')
    require(status=='OK','IMAP_SEARCH_FAILED')
    for uid in sorted(int(x) for x in (rows[0] or b'').split()):
        if uid<=highwater:continue
        if store.recorded(account,validity,uid):continue
        raw=None
        try:
            raw=fetch_bounded(client,uid)
            document=parse(raw,config,authorization['mode'])
            job,new=store.ingest(account,validity,uid,raw,document)
            if new:
                directory=SPOOL/job;create_job_directory(directory)
                temp=directory/'input.tmp';temp.write_bytes(raw);temp.replace(directory/'input.eml')
                if config['mail']['authentication'].get('mechanism') in ['aligned_dkim','provider_dmarc_arc']:
                    keys=config['mail']['authentication'].get('_resolved_keys',{})
                    require(bool(keys),'DKIM_KEYS_MISSING')
                    (directory/'verified-dkim-keys.json').write_text(json.dumps(keys))
                (directory/'convert.request').touch()
            store.record(account,validity,uid,'ACCEPTED')
        except Reject as exc:
            if str(exc) in ['IMAP_FETCH_FAILED','IMAP_PARTIAL_FETCH','IMAP_METADATA_MISSING']:raise
            # Only an independently authenticated, allowlisted sender can
            # receive an input rejection notice. Raw rejected mail is not kept.
            try:
                require(raw is not None,'MAIL_NOT_FETCHED')
                from email import policy
                from email.parser import BytesParser
                from .validation import one_address,authentication,canonical,Document
                rejected=BytesParser(policy=policy.default).parsebytes(raw)
                sender=one_address(rejected,'From')
                require(sender in [canonical(s) for s in config['mail']['allowed_senders']],'SENDER_NOT_ALLOWED')
                authentication(rejected,config,sender,raw)
                doc=Document(sender,'',None,'',False,{},[])
                job,new=store.ingest(account,validity,uid,raw,doc,rejection=True)
                if new:
                    store.db.execute("UPDATE jobs SET state='REJECTED' WHERE id=?",(job,))
                    from .rejection import input_reason
                    reason=input_reason(exc)
                    store.db.execute('INSERT OR REPLACE INTO job_details(job,notes) VALUES(?,?)',(job,json.dumps([reason])))
                    store.db.execute('INSERT OR IGNORE INTO outbox(job,due) VALUES(?,?)',(job,time.time()))
            except Exception:pass
            store.record(account,validity,uid,'REJECTED')

def process_jobs(store,authorization):
    import uuid
    now=time.time()
    snapshot=Path('/var/lib/fax-engine-state/engine-state.json')
    engine=json.loads(snapshot.read_text()) if snapshot.exists() else {}
    for job,state,created in store.db.execute("SELECT id,state,created FROM jobs WHERE state IN ('VALIDATING','READY','DISPATCH_RESERVED','SENDING','UNKNOWN')").fetchall():
        if state in ['DISPATCH_RESERVED','UNKNOWN'] and job in engine.get('dispatch_failures',[]) and now-engine.get('updated',0)<180:
            record_dispatch_failure(store,job)
            (Path('/var/spool/faxmail-next/requests')/(job+'.json')).unlink(missing_ok=True)
            continue
        directory=SPOOL/job
        if state in ['VALIDATING','READY','DISPATCH_RESERVED'] and now-created>=86400 and job not in engine.get('published',{}):
            store.db.execute("UPDATE jobs SET state='EXPIRED' WHERE id=?",(job,))
            store.db.execute('INSERT OR IGNORE INTO outbox(job,due) VALUES(?,?)',(job,now))
            continue
        if state=='VALIDATING':
            result=directory/'conversion.json'
            if result.is_file() and not result.is_symlink():
                info=json.loads(result.read_text());store.ready(job,int(info['pages']))
                notes=[v for v in info.get('notes',[]) if v=='EXTERNAL_IMAGE_OMITTED']
                store.db.execute('INSERT INTO job_details(job,notes) VALUES(?,?) ON CONFLICT(job) DO UPDATE SET notes=excluded.notes',(job,json.dumps(notes)))
                os.chmod(directory/'document.tif',0o640)
                import grp
                os.chown(directory/'document.tif',-1,grp.getgrnam('faxmedia').gr_gid)
                state='READY'
            elif (directory/'conversion.error').exists():
                store.db.execute("UPDATE jobs SET state='REJECTED' WHERE id=?",(job,))
                store.db.execute('INSERT OR REPLACE INTO job_details(job,notes) VALUES(?,?)',(job,json.dumps(['CONVERSION_FAILED'])))
                store.db.execute('INSERT OR IGNORE INTO outbox(job,due) VALUES(?,?)',(job,now))
        if state=='READY' and authorization.get('fax_send') is True and not control.paused():
            require(authorization['mode'] in ['test','production'],'MODE_INVALID')
            if created<=now-86400:continue
            private=store.db.execute('SELECT number,expires FROM private WHERE job=? AND expires>?',(job,now)).fetchone()
            if private and store.reserve(job):
                temp=Path('/var/spool/faxmail-next/requests')/(job+'.tmp')
                temp.write_text(json.dumps({'job':job,'number':private[0],'expires':min(private[1],created+86400)}))
                os.chmod(temp,0o640)
                temp.replace(temp.with_suffix('.json'))
        event=Path('/var/spool/faxmail-next/events')/(job+'.json')
        if event.is_file() and not event.is_symlink() and event.stat().st_size<=4096:
            info=json.loads(event.read_text())
            if info.get('job')==job and isinstance(info.get('pages'),int):
                changed=store.result(job,info.get('status'),info['pages'])
                if changed and info.get('status')=='FAILURE' and info.get('reason')=='FAX_TRAINING_FAILED':
                    detail=store.db.execute('SELECT notes FROM job_details WHERE job=?',(job,)).fetchone()
                    notes=json.loads(detail[0]) if detail else []
                    if 'FAX_TRAINING_FAILED' not in notes:notes.append('FAX_TRAINING_FAILED')
                    store.db.execute('INSERT INTO job_details(job,notes) VALUES(?,?) ON CONFLICT(job) DO UPDATE SET notes=excluded.notes',(job,json.dumps(notes)))
                (Path('/var/spool/faxmail-next/requests')/(job+'.json')).unlink(missing_ok=True)
        elif state in ['DISPATCH_RESERVED','SENDING'] and job in engine.get('published',{}) and now-engine['published'][job]>1100 and time.time()-engine.get('updated',0)<180 and engine.get('idle') is True:
            store.db.execute("UPDATE jobs SET state='UNKNOWN' WHERE id=?",(job,))
            store.db.execute('INSERT OR IGNORE INTO outbox(job,due) VALUES(?,?)',(job,now))

def record_dispatch_failure(store,job):
    if store.result(job,'FAILURE',0):
        detail=store.db.execute('SELECT notes FROM job_details WHERE job=?',(job,)).fetchone()
        notes=json.loads(detail[0]) if detail else []
        if 'DISPATCH_FAILED' not in notes:notes.append('DISPATCH_FAILED')
        store.db.execute('INSERT INTO job_details(job,notes) VALUES(?,?) ON CONFLICT(job) DO UPDATE SET notes=excluded.notes',(job,json.dumps(notes)))

def create_job_directory(directory):
    import grp
    directory.mkdir(mode=0o750)
    os.chown(directory,-1,grp.getgrnam('faxmedia').gr_gid)
    # systemd UMask=0077 removes group traversal from mkdir's requested mode.
    directory.chmod(0o2750)

def notify_once(config,store,authorization):
    if control.smtp_blocked():return
    now=time.time()
    rows=store.db.execute('''SELECT j.id,j.state,j.pages,p.sender,p.message_id,o.attempts
FROM jobs j JOIN outbox o ON o.job=j.id JOIN private p ON p.job=j.id
WHERE j.notification IN ('PENDING','RETRY_WAIT') AND o.due<=? AND p.expires>?''',(now,now)).fetchall()
    for job,state,pages,recipient,msgid,attempts in rows:
        if not store.claim_notice(recipient):continue
        created=store.db.execute('SELECT created FROM jobs WHERE id=?',(job,)).fetchone()[0]
        detail=store.db.execute('SELECT notes FROM job_details WHERE job=?',(job,)).fetchone()
        number,expected=store.db.execute('SELECT p.number,j.expected FROM private p JOIN jobs j ON j.id=p.job WHERE j.id=?',(job,)).fetchone()
        message=notification(config,job,recipient,state,pages or 0,msgid,created,json.loads(detail[0]) if detail else [],number=number,expected=expected)
        claimed=store.db.execute("UPDATE jobs SET notification='SENDING' WHERE id=? AND notification IN ('PENDING','RETRY_WAIT')",(job,))
        if claimed.rowcount!=1:continue
        result=send_notification(config,message,recipient,authorization.get('mail_send') is True)
        store.db.execute('UPDATE jobs SET notification=? WHERE id=?',(result,job))
        delay=[60,300,900,3600][attempts] if attempts<4 else 21600
        store.db.execute('UPDATE outbox SET attempts=attempts+1,due=? WHERE job=?',(now+delay,job))

def receive_once(config,store,authorization):
    import uuid
    from email.message import EmailMessage
    now=time.time()
    for event in Path('/var/spool/faxmail-next/events').glob('*.json'):
        if event.is_symlink() or event.stat().st_size>4096:continue
        data=json.loads(event.read_text());job=data.get('job','')
        try:require(str(uuid.UUID(job))==job,'JOB_INVALID')
        except (ValueError,Reject):continue
        if data.get('direction')!='rx':continue
        directory=Path('/var/spool/faxmail-next/incoming')/job
        if directory.is_symlink():continue
        created=float((directory/'started').read_text())
        if now-created>=168*3600:continue
        result=directory/'conversion.json';failure=directory/'conversion.error'
        if not result.exists() and not failure.exists():continue
        pages=int(json.loads(result.read_text())['pages']) if result.exists() else 0
        state='COMPLETE' if data['status']=='SUCCESS' and pages==data['pages'] and pages>0 else 'INCOMPLETE'
        if pages==0:state='FAILED'
        store.db.execute('INSERT OR IGNORE INTO received VALUES(?,?,?,?)',(job,created,state,pages))
        for recipient in config['mail']['receive_recipients']:
            store.db.execute("INSERT OR IGNORE INTO received_mail(job,recipient,state,due) VALUES(?,?,'PENDING',?)",(job,recipient,now))
    if control.smtp_blocked():return
    rows=store.db.execute("""SELECT r.id,r.state,r.pages,m.recipient,m.attempts FROM received r JOIN received_mail m ON m.job=r.id
WHERE r.created>? AND m.due<=? AND m.state IN ('PENDING','RETRY_WAIT')""",(now-168*3600,now)).fetchall()
    for job,status,pages,recipient,attempts in rows:
        if not store.claim_notice(recipient):continue
        message=EmailMessage();message['From']=config['mail']['fax_address'];message['To']=recipient
        message['Subject']='[FAX受信 '+status+'] '+job
        message['Message-ID']='<'+job+'.'+store.digest(recipient.encode())[:16]+'@faxmail.invalid>'
        message['Auto-Submitted']='auto-generated'
        from datetime import datetime
        from zoneinfo import ZoneInfo
        created=store.db.execute('SELECT created FROM received WHERE id=?',(job,)).fetchone()[0]
        message['Date']=email.utils.format_datetime(datetime.now(ZoneInfo('Asia/Tokyo')))
        text='日時: '+datetime.fromtimestamp(created,ZoneInfo('Asia/Tokyo')).isoformat(timespec='seconds')+'\nJob: '+job+'\n受信結果: '+status+'\nページ数: '+str(pages)
        if status!='COMPLETE':text+='\n不完全受信です。全ページが届いたとは確認できません。'
        message.set_content(text)
        pdf=Path('/var/spool/faxmail-next/incoming')/job/'document.pdf'
        if pages and pdf.exists():
            if pdf.stat().st_size*1.4 < config['mail']['smtp'].get('max_message_bytes',20*1024**2):
                message.add_attachment(pdf.read_bytes(),maintype='application',subtype='pdf',filename='received.pdf')
            else:message.set_content(text+'\n添付サイズが上限を超えたため、PDFは添付していません。')
        claimed=store.db.execute("UPDATE received_mail SET state='SENDING' WHERE job=? AND recipient=? AND state IN ('PENDING','RETRY_WAIT')",(job,recipient))
        if claimed.rowcount!=1:continue
        result=send_notification(config,message,recipient,authorization.get('mail_send') is True)
        delay=[60,300,900,3600][attempts] if attempts<4 else 21600
        store.db.execute('UPDATE received_mail SET state=?,attempts=attempts+1,due=? WHERE job=? AND recipient=?',(result,now+delay,job,recipient))

def run(config):
    import fcntl
    singleton=(STATE/'worker.lock').open('a')
    fcntl.flock(singleton,fcntl.LOCK_EX|fcntl.LOCK_NB)
    require((STATE/'jobs.sqlite').is_file(),'DATABASE_MISSING')
    import subprocess
    require(subprocess.run(['/usr/local/bin/faxmail-next','cleanup','--redacted'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0,'STARTUP_CLEANUP_FAILED')
    store=Store(STATE/'jobs.sqlite',(STATE/'dedupe.key').read_bytes())
    # Reserved jobs are never blindly returned to READY after restart.
    from .operations import reconcile,verify_database_generation,checkpoint_generation
    verify_database_generation(store)
    reconcile(store,config)
    retry=30
    next_mail_cleanup=0
    while True:
        authorization=gate()
        client=None
        try:
            process_jobs(store,authorization)
            if authorization.get('receive_mail',True):receive_once(config,store,authorization)
            notify_once(config,store,authorization)
            checkpoint_generation(store)
        except Exception:control.health('worker','SMTP_UNAVAILABLE')
        if control.paused():time.sleep(5);continue
        try:
            client=imap_connect(config)
            ingest_once(config,store,client,authorization)
            if time.monotonic()>=next_mail_cleanup:
                next_mail_cleanup=time.monotonic()+60
                try:
                    from .mail_cleanup import move_completed
                    move_completed(config,store,client)
                    control.health('mail_cleanup','OK')
                except Exception:control.health('mail_cleanup','MAIL_CLEANUP_FAILED')
            control.health('imap','OK');checkpoint_generation(store)
            retry=30
            time.sleep(10)
        except Reject as exc:
            if str(exc) in ['UIDVALIDITY_CHANGED','MAILBOX_BASELINE_REQUIRED','AUTH_BOUNDARY_UNVERIFIED','AUTH_PLACEMENT_UNVERIFIED','IMAP_AUTH_FAILED','SMTP_AUTH_FAILED']:
                control.health('imap',str(exc));control.pause();raise
            control.health('imap','DISK_LOW' if str(exc)=='DISK_LOW' else 'IMAP_UNAVAILABLE')
            time.sleep(retry);retry=min(900,retry*2)
        except Exception:
            time.sleep(retry);retry=min(900,retry*2)
        finally:
            if client:
                try:client.logout()
                except Exception:pass
