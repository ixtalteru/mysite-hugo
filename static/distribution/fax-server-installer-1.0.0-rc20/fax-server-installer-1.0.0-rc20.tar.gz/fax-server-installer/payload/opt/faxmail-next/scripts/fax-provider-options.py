#!/usr/bin/python3
"""Enable MY050 cancellation digits only for a verified active SIP target."""
import re,subprocess,sys
BASE=['/usr/sbin/asterisk','-C','/var/lib/fax-receive-live/etc/asterisk.conf','-rx']
def cli(command):
 r=subprocess.run(BASE+[command],capture_output=True,text=True,timeout=5)
 if r.returncode or 'No such command' in r.stdout:raise ValueError()
 return r.stdout
def is_my050(endpoint,query=cli):
 if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',endpoint):return False
 try:
  data=query('pjsip show endpoint '+endpoint)
  match=re.search(r'^\s*aors\s*:\s*(\S+)\s*$',data,re.M)
  if not match:return False
  aors=match[1].split(',')
  if not 1<=len(aors)<=4:return False
  for aor in aors:
   if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',aor):return False
   data=query('pjsip show aor '+aor)
   contacts=re.findall(r'^\s*contact\s*:\s*(\S+)\s*$',data,re.M)
   if len(contacts)!=1:return False
   if not re.fullmatch(r'sips?:softphone\.spc\.brastel\.ne\.jp\.?(:[0-9]{1,5})?(;transport=(udp|tcp|tls))?',contacts[0],re.I):return False
  return True
 except Exception:return False
def main():
 while True:
  line=sys.stdin.readline()
  if not line or not line.strip():break
 option='D(w**w**)' if is_my050(sys.argv[1] if len(sys.argv)==2 else '') else ''
 print('SET VARIABLE FAX_PROVIDER_DIAL_OPTIONS "'+option+'"',flush=True)
 sys.stdin.readline()
if __name__=='__main__':main()
