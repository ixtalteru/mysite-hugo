"""Private AGI snapshots; never print diagnostic values or station identifiers."""
import json,os,re,sys,time,uuid
from pathlib import Path

FIELDS=('FAXSTATUS','FAXERROR','FAXSTATUSSTRING','FAXPAGES','FAXBITRATE',
        'FAXRESOLUTION','FAXMODE','DIALSTATUS','HANGUPCAUSE','CHANNEL(hangupsource)',
        'FAXOPT(modem)','FAXOPT(minrate)','FAXOPT(maxrate)',
        'CHANNEL(rtcp,txcount,audio)','CHANNEL(rtcp,rxcount,audio)',
        'CHANNEL(rtcp,rxploss,audio)','CHANNEL(rtcp,rxjitter,audio)',
        'CHANNEL(rtp,src,audio)','CHANNEL(rtp,dest,audio)','CHANNEL(pjsip,call-id)')

def read_value(name):
    print('GET FULL VARIABLE "${'+name+'}"',flush=True)
    line=sys.stdin.readline()
    match=re.fullmatch(r'200 result=1 \(([^\r\n]*)\)\r?\n?',line)
    # Missing values remain null, not a misleading success or zero.
    return match.group(1)[:2048] if match else None

def capture(directory,phase,job=None):
    try:
        values={name:read_value(name) for name in FIELDS}
        root=Path(directory)
        root.mkdir(mode=0o700,parents=True,exist_ok=True)
        if root.is_symlink():return False
        root.chmod(0o700)
        data={'schema':1,'timestamp_unix':time.time(),'phase':phase,'values':values}
        if job is not None:data['job']=str(uuid.UUID(job))
        name=str(uuid.uuid4());temporary=root/(name+'.tmp');destination=root/(name+'.json')
        fd=os.open(temporary,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            json.dump(data,stream,ensure_ascii=False);stream.flush();os.fsync(stream.fileno())
        # Expiry is anchored to intake, not to the later hangup timestamp.
        if job is not None:
            incoming=Path('/var/spool/faxmail-next/incoming')/str(uuid.UUID(job))/'started'
            outgoing=Path('/var/spool/faxmail-next/jobs')/str(uuid.UUID(job))/'input.eml'
            started=float(incoming.read_text()) if incoming.is_file() else (outgoing.stat().st_mtime if outgoing.is_file() else time.time())
            started=min(started,time.time());os.utime(temporary,(started,started))
        os.replace(temporary,destination)
        fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
        return True
    except Exception:
        # Existing delivery result handling must still run on storage failure.
        return False
