"""Root maintenance for explicitly inventoried legacy artifacts and backups."""
import json,os,shutil,sqlite3,time,uuid
from pathlib import Path

MANIFEST=Path('/etc/faxmail-next/retention-manifest.json')
LEGACY_ROOT=Path('/var/lib')
PRIVATE_ROOTS=[Path('/var/lib/faxmail-backups'),Path('/var/lib/faxmail-diagnostics'),Path('/var/lib/faxmail-installer/transactions'),Path('/var/lib/faxmail-installer/build'),Path('/var/lib/fax-installer-tests')]
SPOOL_ROOTS=[Path('/var/lib/fax-receive-live/spool/outgoing'),Path('/var/lib/fax-receive-live/spool/fax-staging'),Path('/var/lib/fax-receive-live/spool/outgoing_done')]
SPOOL_ROOTS.append(Path('/var/lib/fax-receive-live/spool/outgoing/.staging'))
def remove_tree(target,allowed_parent):
 target=Path(target);parent=Path(allowed_parent).resolve()
 if target.is_symlink() or target.resolve().parent!=parent:raise ValueError('RETENTION_PATH')
 if not target.exists():return
 # shutil.rmtree's fd-based Linux implementation does not follow replaced links.
 if not shutil.rmtree.avoids_symlink_attacks:raise RuntimeError('RETENTION_PLATFORM')
 shutil.rmtree(target)

def run(now=None,dry_run=False):
 now=time.time() if now is None else now;count=0
 manifest=json.loads(MANIFEST.read_text()) if MANIFEST.exists() else []
 protected={'fax-receive-live','faxmail-next','faxmail-control','fax-engine-state','faxdispatch'}
 for item in manifest:
  p=Path(item['path'])
  if p.parent!=LEGACY_ROOT or not p.name.startswith('fax-') or p.name in protected:raise ValueError('RETENTION_PATH')
  if now>=item['created']+168*3600 and p.exists():
   count+=1
   if not dry_run:remove_tree(p,LEGACY_ROOT)
 for root in PRIVATE_ROOTS:
  if not root.exists():continue
  for p in root.iterdir():
   if p.is_symlink():continue
   if p.is_dir():
    stamp=p/'created'
    if not stamp.is_file():continue
    created=float(stamp.read_text())
   else:created=p.stat().st_mtime
   if now<created+168*3600:continue
   count+=1
   if not dry_run:
    if p.is_dir():remove_tree(p,root)
    else:p.unlink()
 for root in SPOOL_ROOTS:
  for p in root.glob('*.call'):
   if p.is_symlink() or p.stat().st_mtime>now-168*3600:continue
   try:
    if str(uuid.UUID(p.stem))!=p.stem:continue
   except ValueError:continue
   count+=1
   if not dry_run:p.unlink()
 print('maintenance_expired: '+str(count))

if __name__=='__main__':
 import sys
 try:run(dry_run='--dry-run' in sys.argv)
 except Exception:print('maintenance: FAIL');raise SystemExit(1)
