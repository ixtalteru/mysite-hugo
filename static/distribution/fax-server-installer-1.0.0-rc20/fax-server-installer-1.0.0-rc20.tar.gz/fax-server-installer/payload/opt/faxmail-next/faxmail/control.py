"""Cross-service send admission and durable, redacted health state."""
import contextlib,json,os,shutil,time
from pathlib import Path
PAUSED=Path('/var/lib/faxmail-control/paused')
LOCK=Path('/var/lib/faxmail-control/control.lock')
STATE=Path('/var/lib/faxmail-next')
MIN_FREE=2*1024**3

@contextlib.contextmanager
def admission_lock():
    import fcntl
    with LOCK.open('r+') as stream:
        fcntl.flock(stream,fcntl.LOCK_EX)
        yield

def paused():return PAUSED.exists()
def disk_ok(path='/var/spool/faxmail-next'):return shutil.disk_usage(path).free>=MIN_FREE
def pause():
    with admission_lock():
        PAUSED.touch(mode=0o644)
        (STATE/'paused').touch()
def resume():
    with admission_lock():
        PAUSED.unlink(missing_ok=True)
        (STATE/'paused').unlink(missing_ok=True)

def health(component,code):
    allowed={'MAIL_CLEANUP_FAILED','OK','DISK_LOW','IMAP_AUTH_FAILED','SMTP_AUTH_FAILED','IMAP_UNAVAILABLE','SMTP_UNAVAILABLE','DATABASE_ROLLBACK','CONVERSION_FAILED','AUTH_BOUNDARY_UNVERIFIED','AUTH_PLACEMENT_UNVERIFIED','UIDVALIDITY_CHANGED','MAILBOX_BASELINE_REQUIRED'}
    if code not in allowed:code='CONVERSION_FAILED'
    p=STATE/('health-'+component+'.json');tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps({'code':code,'updated':time.time()}));tmp.chmod(0o600);os.replace(tmp,p)

def smtp_blocked():
    p=STATE/'smtp-auth-blocked.json'
    if not p.exists():return False
    try:return json.loads(p.read_text()).get('retry_after',0)>time.time()
    except Exception:return True

def block_smtp():
    p=STATE/'smtp-auth-blocked.json';tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps({'retry_after':time.time()+21600}));tmp.chmod(0o600);os.replace(tmp,p)
    health('smtp','SMTP_AUTH_FAILED')
