#!/usr/bin/python3
"""AGI protocol on stdout only; events contain UUID, fixed status and count."""
import json,os,re,sys,uuid
from pathlib import Path
def variable(name):
    print('GET VARIABLE '+name,flush=True)
    line=sys.stdin.readline()
    match=re.fullmatch(r'200 result=1 \(([^\r\n]*)\)\n?',line)
    return match.group(1) if match else ''
try:
    while True:
        line=sys.stdin.readline()
        if not line or not line.strip():break
    if len(sys.argv)>1 and sys.argv[1]=='init-rx':
        import time
        job=str(uuid.uuid4())
        directory=Path('/var/spool/faxmail-next/incoming')/job
        directory.mkdir(mode=0o2770)
        (directory/'started').write_text(str(time.time()))
        print('SET VARIABLE FAX_JOB '+job,flush=True);sys.stdin.readline()
        print('SET VARIABLE FAX_DIRECTION rx',flush=True);sys.stdin.readline()
        raise SystemExit(0)
    job=variable('FAX_JOB')
    if str(uuid.UUID(job))!=job:raise ValueError()
    from fax_diagnostics import capture
    phase={'diagnostic-only':'fax-return','diagnostic-start':'receive-start'}.get(sys.argv[1] if len(sys.argv)>1 else '', 'hangup')
    capture('/var/lib/faxmail-diagnostics',phase,job)
    if phase!='hangup':raise SystemExit(0)
    status=variable('FAXSTATUS');pages=variable('FAXPAGES')
    error=variable('FAXERROR')
    reason='FAX_TRAINING_FAILED' if error=='Failed to train with any of the compatible modems' else None
    direction=variable('FAX_DIRECTION')
    direction='rx' if direction=='rx' else 'tx'
    if status=='FAILED':status='FAILURE'
    if status not in ['SUCCESS','FAILURE']:status='UNKNOWN'
    count=int(pages) if pages.isdigit() else 0
    if not 0<=count<=20:raise ValueError()
    directory=Path('/var/spool/faxmail-next/events')
    temp=directory/(str(uuid.uuid4())+'.tmp')
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o640)
    with os.fdopen(fd,'w') as stream:
        json.dump({'job':job,'status':status,'pages':count,'direction':direction,'reason':reason},stream)
        stream.flush();os.fsync(stream.fileno())
    os.replace(temp,directory/(job+'.json'))
except Exception:
    pass
