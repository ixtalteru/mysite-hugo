"""Root-only launcher of UUID-addressed, unprivileged conversion services."""
import json,os,subprocess,uuid,time,re,pwd
from pathlib import Path

def channel_count(result):
    match=re.search(r'(?m)^\s*(\d+) active channels\s*$',result.stdout)
    return int(match.group(1)) if result.returncode==0 and match else None

def convert_service(unit,directory):
    result=subprocess.run(['systemctl','start',unit],capture_output=True)
    if result.returncode!=0:
        subprocess.run(['runuser','-u','faxmail','--','/usr/local/bin/faxmail-next','conversion-failed','--job-dir',str(directory)],capture_output=True)
def run():
    # Publish only internal UUIDs and booleans. Mail worker gets no SIP secrets.
    conf='/var/lib/fax-receive-live/etc/asterisk.conf'
    channels=subprocess.run(['asterisk','-C',conf,'-rx','core show channels concise'],capture_output=True,text=True,timeout=20)
    count=channel_count(subprocess.run(['asterisk','-C',conf,'-rx','core show channels count'],capture_output=True,text=True,timeout=20))
    registrations=subprocess.run(['asterisk','-C',conf,'-rx','pjsip show registrations'],capture_output=True,text=True,timeout=20)
    active=set(re.findall(r'/jobs/([0-9a-f-]{36})/document\.tif',channels.stdout))
    queued=[p.stem for p in Path('/var/lib/fax-receive-live/spool/outgoing').glob('*.call') if re.fullmatch(r'[0-9a-f-]{36}',p.stem)]
    published={p.name:p.stat().st_mtime for p in Path('/var/lib/faxdispatch').iterdir() if re.fullmatch(r'[0-9a-f-]{36}',p.name)}
    dispatch_failures=[]
    for job in published:
        receipt=Path('/var/lib/faxdispatch')/job
        if not receipt.is_symlink() and receipt.stat().st_size<=128 and receipt.read_text()=='FAILED_PREPUBLICATION':dispatch_failures.append(job)
    module_output=subprocess.run(['asterisk','-C',conf,'-rx','module show'],capture_output=True,text=True,timeout=20).stdout
    modules=all(any(line.startswith(name+'.so ') and 'Running' in line and 'Not Running' not in line for line in module_output.splitlines()) for name in ['res_pjsip','res_fax_ssrc','res_fax_spandsp','app_dial','pbx_spool'])
    ntp=subprocess.run(['timedatectl','show','-p','NTPSynchronized','--value'],capture_output=True,text=True,timeout=20).stdout.strip()=='yes'
    firewall=subprocess.run(['/usr/local/bin/fax-admin','firewall-check'],capture_output=True,text=True,timeout=20).returncode==0
    p=Path('/var/lib/fax-engine-state/engine-state.json')
    # Spool root is root-owned, so service users cannot substitute these paths.
    tmp=p.with_suffix('.tmp')
    tmp.unlink(missing_ok=True)
    with tmp.open('x') as f:json.dump({'updated':time.time(),'active':sorted(active),'queued':queued,'published':published,'dispatch_failures':dispatch_failures,'idle':count==0,'registered':bool(re.search(r'\bRegistered\b',registrations.stdout)),'channels_known':count is not None,'modules':modules,'ntp':ntp,'firewall':firewall},f)
    os.chown(tmp,0,pwd.getpwnam('faxmail').pw_gid);tmp.chmod(0o640);os.replace(tmp,p)
    root=Path('/var/spool/faxmail-next/jobs')
    for directory in root.iterdir():
        try:
            if str(uuid.UUID(directory.name))!=directory.name:continue
        except ValueError:continue
        if directory.is_symlink() or not directory.is_dir():continue
        request=directory/'convert.request'
        if not request.is_file() or request.is_symlink():continue
        if any(p.is_symlink() for p in directory.iterdir()):continue
        # Root does not write to service-controlled paths. The isolated,
        # unprivileged converter publishes its own result and removes marker.
        convert_service('faxmail-convert@'+directory.name+'.service',directory)
    root=Path('/var/spool/faxmail-next/incoming')
    for directory in root.iterdir():
        try:
            if str(uuid.UUID(directory.name))!=directory.name:continue
        except ValueError:continue
        if directory.is_symlink() or not directory.is_dir():continue
        if (directory/'conversion.json').exists() or (directory/'conversion.error').exists():continue
        event=Path('/var/spool/faxmail-next/events')/(directory.name+'.json')
        if not event.is_file() or event.is_symlink() or event.stat().st_size>4096:continue
        info=json.loads(event.read_text())
        if info.get('direction')!='rx' or info.get('job')!=directory.name:continue
        if any(p.is_symlink() for p in directory.iterdir()):continue
        convert_service('faxmail-receive@'+directory.name+'.service',directory)
