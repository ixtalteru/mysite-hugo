"""Fixed input rejection reasons, safe for storage and sender notifications."""
EXPLANATIONS={
 'AMBIGUOUS_BODY_PART':'本文として扱えない追加のテキスト部分があります。新規メールとして本文と添付をまとめて送信してください。',
 'NUMBER_SYNTAX':'件名のFAX番号の形式が正しくありません。半角数字10～11桁で指定してください。',
 'NUMBER_NOT_ALLOWED':'宛先番号の番号帯がサーバーの発信許可範囲に含まれていません。',
 'NUMBER_BLOCKED':'宛先番号はサーバーの発信禁止条件に該当します。',
 'TEST_DESTINATION':'試験モードで許可されていない宛先です。',
 'QUEUE_FULL':'送信待ち件数が上限を超えたため受け付けできません。',
 'SENDER_RATE':'送信者ごとの受付頻度上限を超えました。',
 'GLOBAL_RATE':'サーバー全体の受付頻度上限を超えました。',
 'EXTRA_RECIPIENT':'CCまたはBCCに追加の宛先があります。',
 'TO_NOT_ALLOWED':'ToにはFAX専用アドレス1件だけを指定してください。',
 'ATTACHMENT_UNSUPPORTED':'対応していない添付形式が含まれています。',
 'EMPTY_MESSAGE':'本文または対応する添付ファイルが必要です。',
 'MAIL_SIZE':'メールのサイズが受付上限を超えています。',
 'BODY_SIZE':'本文のサイズが受付上限を超えています。',
 'ATTACHMENT_COUNT':'添付ファイル数が受付上限を超えています。',
 'DECODED_SIZE':'添付ファイルの合計サイズが受付上限を超えています。',
 'INPUT_REJECTED':'メールが受付条件を満たしていないため、発信していません。',
}
def input_reason(error):
 code=str(error)
 return code if code in EXPLANATIONS else 'INPUT_REJECTED'
