import copy,io,tempfile,time
from email.message import EmailMessage
from pathlib import Path
from .validation import parse,Reject,Document
from .store import Store

def fixture():
    config={'mail':{'fax_address':'fax@example.invalid','allowed_senders':['sender@example.invalid'],
        'authentication':{'trust_boundary_verified':True,'placement_verified':True,'authentication_results_index':0,'trusted_authserv_ids':['mx.example.invalid']}},
        'fax':{'allowed_domestic_prefixes':['03'],'blocked_prefixes':['00']},'permissions':{'test_destination_numbers':['0300000000']}}
    message=EmailMessage();message['From']='sender@example.invalid';message['To']='fax@example.invalid'
    message['Subject']='0300000000';message['Message-ID']='<fixture@example.invalid>'
    message['Authentication-Results']='mx.example.invalid; dmarc=pass header.from=example.invalid'
    message.set_content('日本語FAX変換の合成試験です。\n二行目。')
    return config,message

def run():
    passed=0;failed=0
    def check(name,action):
        nonlocal passed,failed
        try:
            action();passed+=1;print(name+': PASS')
        except Exception:failed+=1;print(name+': FAIL')
    def expect_reject(message,config=None):
        if config is None:config=fixture()[0]
        try:parse(message.as_bytes(),config)
        except Reject:return
        raise AssertionError()
    config,message=fixture()
    check('valid_plain',lambda:parse(message.as_bytes(),config))
    for name,value in [('number_fullwidth','０３００００００００'),('number_hyphen','03-0000-0000'),('number_reply','Re: 0300000000'),('number_international','+81300000000'),('number_unallowed','0600000000')]:
        m=copy.deepcopy(message);m.replace_header('Subject',value)
        check(name,lambda m=m:expect_reject(m))
    for name,header,value in [('cc_rejected','Cc','other@example.invalid'),('bcc_rejected','Bcc','other@example.invalid'),('auto_rejected','Auto-Submitted','auto-generated'),('resent_rejected','Resent-From','sender@example.invalid')]:
        m=copy.deepcopy(message);m[header]=value;check(name,lambda m=m:expect_reject(m))
    m=copy.deepcopy(message);m.replace_header('To','fax@example.invalid,other@example.invalid');check('multiple_to',lambda:expect_reject(m))
    m=copy.deepcopy(message);m.replace_header('From','unknown@example.invalid');check('unknown_sender',lambda:expect_reject(m))
    m=copy.deepcopy(message);m.replace_header('Authentication-Results','fake.example.invalid; dmarc=pass header.from=example.invalid');check('forged_auth',lambda:expect_reject(m))
    m=copy.deepcopy(message);m.replace_header('Authentication-Results','mx.example.invalid; dmarc=fail header.from=example.invalid');check('failed_dmarc',lambda:expect_reject(m))
    bad=copy.deepcopy(config);bad['mail']['authentication']['trust_boundary_verified']=False
    check('unverified_boundary',lambda:expect_reject(message,bad))
    m=copy.deepcopy(message);m.add_attachment(b'not zip',maintype='application',subtype='zip');check('unsupported_attachment',lambda:expect_reject(m))
    def mobile_empty_tail():
        m=copy.deepcopy(message);m.make_mixed()
        tail=EmailMessage();tail.set_content('\r\n');m.attach(tail)
        assert parse(m.as_bytes(),config).body==parse(message.as_bytes(),config).body
    check('mobile_empty_text_tail',mobile_empty_tail)
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory);doc=parse(message.as_bytes(),config)
        store=Store(root/'jobs.sqlite',b'x'*32)
        job,new=store.ingest('test',1,1,message.as_bytes(),doc,now=1000)
        def duplicate():assert store.ingest('test',1,1,message.as_bytes(),doc,now=1001)==(job,False)
        check('deduplication',duplicate)
        def reserve_once():
            store.ready(job,1);assert store.reserve(job,now=1002);assert not store.reserve(job,now=1003)
        check('reserve_once',reserve_once)
        def recovery():
            store.recover();assert store.db.execute('SELECT state FROM jobs WHERE id=?',(job,)).fetchone()[0]=='UNKNOWN';assert not store.reserve(job,now=1004)
        check('crash_no_resend',recovery)
        def key_change():
            try:Store(root/'jobs.sqlite',b'y'*32)
            except Reject:return
            raise AssertionError()
        check('changed_key',key_change)
        def expires():
            assert not store.expire(now=1000+168*3600-1)
            assert store.expire(now=1000+168*3600)==[job]
            assert not store.db.execute('SELECT * FROM private').fetchall()
            assert store.ingest('test',1,1,message.as_bytes(),doc,now=1000+168*3600)==(job,False)
        check('retention_and_dedupe',expires)
        def baseline():
            assert store.baseline('box',1,20,True)==19
            assert store.baseline('box',1,30)==19
            store.record('box',1,20,'REJECTED')
            assert store.baseline('box',1,30)==20
            assert store.recorded('box',1,20)
            try:store.baseline('box',2,30)
            except Reject:return
            raise AssertionError()
        check('uidvalidity_and_baseline',baseline)
        def missing_baseline():
            try:store.baseline('new',1,100)
            except Reject:return
            raise AssertionError()
        check('missing_baseline_stops',missing_baseline)
        from .convert import convert,receive_pdf,sanitized_body
        from PIL import Image
        def plain_convert():assert convert(doc,root/'plain')[0]==1
        check('japanese_pdf_tiff',plain_convert)
        def receive_convert():assert receive_pdf(root/'plain/document.tif',root/'received.pdf')==1
        check('receive_pdf',receive_convert)
        def mixed_paper_pdf():
            from pypdf import PdfReader,PdfWriter
            from pypdf.generic import DecodedStreamObject,NameObject
            writer=PdfWriter()
            for width,height,rotation in [(595.276,841.89,0),(841.89,1190.551,0),(1190.551,841.89,90),(1190.551,841.89,0),(595.276,841.89,0)]:
                page=writer.add_blank_page(width,height)
                stream=DecodedStreamObject();stream.set_data(b'0 g 40 40 100 60 re f')
                page[NameObject('/Contents')]=writer._add_object(stream)
                if rotation:page.rotate(rotation)
            payload=io.BytesIO();writer.write(payload)
            m=copy.deepcopy(message);m.set_content(' \n')
            m.add_attachment(payload.getvalue(),maintype='application',subtype='pdf',filename='mixed.pdf')
            directory=root/'mixed-paper'
            assert convert(parse(m.as_bytes(),config),directory)[0]==5
            expected=[595.276,841.89,841.89,841.89,595.276]
            for p,width in zip(PdfReader(directory/'document.pdf').pages,expected):
                assert abs(float(p.mediabox.width)-width)<0.1
            with Image.open(directory/'document.tif') as image:
                assert image.n_frames==5
                for index,width in enumerate([1728,2432,2432,2432,1728]):
                    image.seek(index);assert image.width==width
                    assert image.convert('L').getextrema()==(0,255)
            assert receive_pdf(directory/'document.tif',directory/'received.pdf')==5
            for p,width in zip(PdfReader(directory/'received.pdf').pages,expected):
                assert abs(float(p.mediabox.width)-width)<0.1
        check('mixed_a4_a3_pdf_roundtrip',mixed_paper_pdf)
        def multiple():
            m=copy.deepcopy(message)
            for fmt,sub in [('PNG','png'),('JPEG','jpeg')]:
                image=Image.new('RGB',(200,100),'white');out=io.BytesIO();image.save(out,fmt)
                m.add_attachment(out.getvalue(),maintype='image',subtype=sub,filename='untrusted')
            assert convert(parse(m.as_bytes(),config),root/'multiple')[0]==3
        check('multiple_images_order',multiple)
        def iphone_split_body():
            m=copy.deepcopy(message);m.set_content('最初の本文')
            out=io.BytesIO();Image.new('RGB',(200,100),'white').save(out,'JPEG')
            m.add_attachment(out.getvalue(),maintype='image',subtype='jpeg',filename='image.jpg',disposition='inline')
            tail=EmailMessage();tail.set_content('画像後の本文');m.attach(tail)
            d=parse(m.as_bytes(),config)
            assert '最初の本文' in d.body and '画像後の本文' in d.body
            assert d.body.index('最初の本文')<d.body.index('画像後の本文')
            assert d.html and d.body.index('最初の本文')<d.body.index('<img')<d.body.index('画像後の本文')
            assert len(d.attachments)==1 and convert(d,root/'split-iphone')[0]==1
        check('iphone_split_body_preserved',iphone_split_body)

        def whitespace_bodies():
            for i,(body,is_html,expected) in enumerate([
                (' \r\n\t\n',False,1),
                ('\n\n本文があります。',False,2),
                ('<div><br></div><div>&nbsp;　</div>',True,1),
                ('<div><br></div><div>二行目の本文</div>',True,2),
            ]):
                m=copy.deepcopy(message);m.set_content(body,subtype='html' if is_html else 'plain')
                out=io.BytesIO();Image.new('RGB',(200,100),'white').save(out,'JPEG')
                m.add_attachment(out.getvalue(),maintype='image',subtype='jpeg',filename='test.jpeg')
                assert convert(parse(m.as_bytes(),config),root/('blank-body-'+str(i)))[0]==expected
            from .validation import Document
            blank=Document('sender@example.invalid','0300000000',None,'<div><br>&nbsp;</div>',True,{},[])
            try:convert(blank,root/'empty-only')
            except Reject as exc:assert str(exc)=='EMPTY_MESSAGE'
            else:raise AssertionError()
        check('blank_body_omitted_later_text_preserved',whitespace_bodies)

        def html_comments():
            d=Document('s@example.invalid','0300000000',None,'<!-- Full Text --><!--[if mso]><xml>office</xml><![endif]--><p>Visible</p>',True,{},[])
            text,_,_,_=sanitized_body(d)
            assert 'Full Text' not in text and 'office' not in text and 'Visible' in text
        check('html_comments_are_not_printed',html_comments)
        def html_layout():
            d=Document('s@example.invalid','0300000000',None,'<div style="display:none">PREHEADER</div><table width="650" border="0" align="center"><tr><td colspan="2" style="font-size:24px;padding:20px;text-align:center">Title</td></tr></table>',True,{},[])
            text,_,_,_=sanitized_body(d)
            assert 'PREHEADER' not in text and 'font-size:24px' in text and 'padding:20px' in text
            assert 'width:650px' in text and 'colspan="2"' in text and 'margin-left:auto' in text
        check('html_layout_and_hidden_preheader',html_layout)
        def html_css_resources():
            from .convert import safe_style
            text=safe_style('background:url(https://example.invalid);position:fixed;content:attr(secret);font-size:18px;color:#123;--x:5;behavior:url(file:///x)')
            assert text=='font-size:18px;color:#123'
            d=Document('s@example.invalid','0300000000',None,'<style>@import "https://example.invalid";@page{size:A3}.title{font-weight:bold;background-image:url(file:///x)}</style><p class="title" onclick="bad()">Visible</p>',True,{},[])
            text,blobs,_,_=sanitized_body(d)
            assert 'font-weight:bold' in text and '#fax-mail-body .title' in text
            assert not any(x in text for x in ('https:','file:','onclick','@page','@import')) and not blobs
        check('html_css_resource_and_page_rules_blocked',html_css_resources)
        def html_table_borders():
            d=Document('s@example.invalid','0300000000',None,'<table border="1" cellpadding="4"><tr><td>Data</td></tr></table>',True,{},[])
            text,_,_,_=sanitized_body(d)
            assert 'border:1px solid #888' in text and 'padding:4px' in text
        check('html_explicit_table_borders_preserved',html_table_borders)
        def html_external_alt():
            d=Document('s@example.invalid','0300000000',None,'<img src="https://example.invalid/logo" alt="Company logo"><img src="https://example.invalid/tracker" width="1" height="1">',True,{},[])
            text,blobs,_,notes=sanitized_body(d)
            assert '[Company logo]' in text and '外部画像は省略' not in text and not blobs
            assert 'https:' not in text and 'EXTERNAL_IMAGE_OMITTED' in notes
        check('html_external_alt_and_tracking_pixel',html_external_alt)

        def external():
            m=copy.deepcopy(message);m.set_content('<p>本文</p><img src="https://example.invalid/image"><script>bad()</script>',subtype='html')
            d=parse(m.as_bytes(),config);text,_,_,notes=sanitized_body(d)
            assert 'EXTERNAL_IMAGE_OMITTED' in notes and 'script' not in text
            assert convert(d,root/'external')[0]==1
        check('external_resource_blocked',external)
        def bad_pdf():
            m=copy.deepcopy(message);m.add_attachment(b'%PDF-broken',maintype='application',subtype='pdf')
            try:convert(parse(m.as_bytes(),config),root/'badpdf')
            except Reject:return
            raise AssertionError()
        check('broken_pdf_rejected',bad_pdf)
        def missing_cid():
            m=copy.deepcopy(message);m.set_content('<img src="cid:missing">',subtype='html')
            try:convert(parse(m.as_bytes(),config),root/'badcid')
            except Reject:return
            raise AssertionError()
        check('missing_cid_rejected',missing_cid)
        def valid_cid():
            m=copy.deepcopy(message);m.set_content('<p>前</p><img src="cid:image"><p>後</p>',subtype='html')
            image=Image.new('RGB',(100,100),'white');out=io.BytesIO();image.save(out,'PNG')
            m.add_related(out.getvalue(),maintype='image',subtype='png',cid='<image>')
            assert convert(parse(m.as_bytes(),config),root/'cid')[0]==1
        check('inline_cid_single_page',valid_cid)
        def pdf_attachment():
            m=copy.deepcopy(message);m.add_attachment((root/'plain/document.pdf').read_bytes(),maintype='application',subtype='pdf')
            assert convert(parse(m.as_bytes(),config),root/'pdfattachment')[0]==2
        check('body_pdf_order',pdf_attachment)
        def encrypted_pdf():
            from pypdf import PdfWriter
            writer=PdfWriter();writer.add_blank_page(595,842);writer.encrypt('dummy')
            out=io.BytesIO();writer.write(out)
            m=copy.deepcopy(message);m.add_attachment(out.getvalue(),maintype='application',subtype='pdf')
            try:convert(parse(m.as_bytes(),config),root/'encrypted')
            except Reject:return
            raise AssertionError()
        check('encrypted_pdf_rejected',encrypted_pdf)
        def call_file():
            from .dispatch import callfile
            import uuid
            job=str(uuid.uuid4());text=callfile(job,'0300000000',Path('/var/spool/faxmail-next/jobs')/job/'document.tif')
            assert 'MaxRetries: 0\n' in text and 'Context: fax-send\n' in text
            try:callfile(job,'0300000000\nApplication: System','/tmp/x')
            except Reject:return
            raise AssertionError()
        check('call_file_injection_rejected',call_file)
        def sender_case():
            m=copy.deepcopy(message);m.replace_header('From','Sender@example.invalid');expect_reject(m)
        check('sender_local_case_preserved',sender_case)
        def to_group():
            m=copy.deepcopy(message);m.replace_header('To','group: fax@example.invalid;');expect_reject(m)
        check('to_group_rejected',to_group)
        def animated_image():
            m=copy.deepcopy(message);out=io.BytesIO()
            Image.new('RGB',(20,20),'white').save(out,'PNG',save_all=True,append_images=[Image.new('RGB',(20,20),'black')])
            m.add_attachment(out.getvalue(),maintype='image',subtype='png')
            try:convert(parse(m.as_bytes(),config),root/'animated')
            except Reject:return
            raise AssertionError()
        check('animated_image_rejected',animated_image)
        def wrong_content():
            m=copy.deepcopy(message);m.add_attachment(b'not image',maintype='image',subtype='jpeg')
            try:convert(parse(m.as_bytes(),config),root/'wrongimage')
            except Reject:return
            raise AssertionError()
        check('false_image_type_rejected',wrong_content)
        def page_limit():
            from pypdf import PdfWriter
            writer=PdfWriter()
            for _ in range(21):writer.add_blank_page(595,842)
            out=io.BytesIO();writer.write(out)
            m=copy.deepcopy(message);m.add_attachment(out.getvalue(),maintype='application',subtype='pdf')
            try:convert(parse(m.as_bytes(),config),root/'manypages')
            except Reject:return
            raise AssertionError()
        check('pdf_page_limit',page_limit)
        def smtp_gate():
            from .mailio import send_notification
            try:send_notification(config,message,'recipient@example.invalid')
            except Reject:return
            raise AssertionError()
        check('smtp_send_gate',smtp_gate)
        def message_collision():
            collision=copy.deepcopy(message);collision.set_content('changed synthetic payload')
            try:store.ingest('test',1,2,collision.as_bytes(),parse(collision.as_bytes(),config))
            except Reject:return
            raise AssertionError()
        check('message_id_collision',message_collision)
        def result_idempotence():
            other=copy.deepcopy(message);other.replace_header('Message-ID','<new@example.invalid>')
            jid,_=store.ingest('test',1,3,other.as_bytes(),parse(other.as_bytes(),config))
            store.ready(jid,2);assert store.reserve(jid)
            assert store.result(jid,'SUCCESS',1)
            assert store.db.execute('SELECT state FROM jobs WHERE id=?',(jid,)).fetchone()[0]=='FAILED'
            assert not store.result(jid,'SUCCESS',2)
        check('page_match_and_result_idempotence',result_idempotence)
        def notice_rate():
            for _ in range(40):assert store.claim_notice('notice@example.invalid',now=1000)
            assert store.claim_notice('notice@example.invalid',now=1001)
            assert store.claim_notice('notice@example.invalid',now=4601)
        check('notification_no_recipient_hourly_limit',notice_rate)
        def notice_no_daily_limit():
            for i in range(40):assert store.claim_notice('daily'+str(i)+'@example.invalid',now=5000)
        check('notification_no_daily_limit',notice_no_daily_limit)
        def intake_no_rate_limit():
            from .validation import Document
            unlimited=Store(root/'unlimited.sqlite',b'z'*32)
            doc=Document('same@example.invalid','0300000000',None,'test',False,{},[])
            for i in range(35):
                _,new=unlimited.ingest('rate-test',1,i+1,('unique'+str(i)).encode(),doc,now=1000)
                assert new
            assert unlimited.db.execute('SELECT count(*) FROM jobs').fetchone()[0]==35
            unlimited.db.close()
        check('fax_intake_no_sender_or_daily_limit',intake_no_rate_limit)

        def ambiguous_text():
            m=copy.deepcopy(message);m.make_mixed()
            extra=EmailMessage();extra.set_content('extra body')
            m.attach(extra);expect_reject(m)
        check('ambiguous_body_not_dropped',ambiguous_text)
        def smtp_unknown():
            import smtplib
            from unittest.mock import patch
            from .mailio import send_notification
            class Fake:
                def sendmail(self,*args):raise smtplib.SMTPServerDisconnected('synthetic secret must stay private')
                def close(self):pass
            with patch('faxmail.mailio.smtp_connect',return_value=Fake()),patch('faxmail.control.health'),patch('faxmail.control.smtp_blocked',return_value=False):
                assert send_notification({'mail':{'fax_address':'fax@example.invalid'}},message,'recipient@example.invalid',True)=='DELIVERY_UNKNOWN'
        check('smtp_uncertain_delivery_no_retry',smtp_unknown)
        def spool_once():
            from .dispatch import stage
            import uuid
            folder=root/'spool-once';folder.mkdir()
            for name in ['staging','outgoing','receipts','jobs']:(folder/name).mkdir()
            jid=str(uuid.uuid4());jobdir=folder/'jobs'/jid;jobdir.mkdir()
            (jobdir/'document.tif').write_bytes((root/'plain/document.tif').read_bytes())
            request={'job':jid,'number':'0300000000','expires':time.time()+60}
            args=(request,config,folder/'staging',folder/'outgoing',folder/'receipts',folder/'jobs')
            assert stage(*args)
            assert not stage(*args)
            assert len(list((folder/'outgoing').glob('*.call')))==1
            assert 'MaxRetries: 0\n' in (folder/'outgoing'/(jid+'.call')).read_text()
        check('spool_atomic_single_publication',spool_once)
        def spool_crash():
            from .dispatch import stage
            from unittest.mock import patch
            import uuid
            folder=root/'spool-crash';folder.mkdir()
            for name in ['staging','outgoing','receipts','jobs']:(folder/name).mkdir()
            jid=str(uuid.uuid4());jobdir=folder/'jobs'/jid;jobdir.mkdir()
            (jobdir/'document.tif').write_bytes((root/'plain/document.tif').read_bytes())
            request={'job':jid,'number':'0300000000','expires':time.time()+60}
            args=(request,config,folder/'staging',folder/'outgoing',folder/'receipts',folder/'jobs')
            with patch('faxmail.dispatch.os.replace',side_effect=OSError('simulated publication failure')):
                try:stage(*args)
                except OSError:pass
                else:raise AssertionError()
            assert not stage(*args)
            assert len(list((folder/'outgoing').glob('*.call')))==0
            assert (folder/'receipts'/jid).exists()
        check('spool_crash_never_republished',spool_crash)
        def spool_expired():
            from .dispatch import stage
            import uuid
            folder=root/'spool-expired';folder.mkdir()
            for name in ['staging','outgoing','receipts','jobs']:(folder/name).mkdir()
            jid=str(uuid.uuid4());jobdir=folder/'jobs'/jid;jobdir.mkdir()
            (jobdir/'document.tif').write_bytes((root/'plain/document.tif').read_bytes())
            request={'job':jid,'number':'0300000000','expires':time.time()-1}
            try:stage(request,config,folder/'staging',folder/'outgoing',folder/'receipts',folder/'jobs')
            except Reject:pass
            else:raise AssertionError()
            assert not list((folder/'receipts').iterdir()) and not list((folder/'outgoing').iterdir())
        check('spool_expired_request_not_published',spool_expired)
    print('tests_passed: '+str(passed));print('tests_failed: '+str(failed))
    return 1 if failed else 0
