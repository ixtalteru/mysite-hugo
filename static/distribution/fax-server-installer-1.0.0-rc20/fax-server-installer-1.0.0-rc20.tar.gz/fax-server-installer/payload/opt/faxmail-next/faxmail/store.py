"""Durable deduplication and at-most-once dispatch reservation."""
import hashlib,hmac,json,os,sqlite3,time,uuid
from pathlib import Path
from .validation import Reject,require

class Store:
    def __init__(self,path,key):
        require(len(key)>=32,'DEDUPE_KEY_INVALID')
        self.key=key
        self.db=sqlite3.connect(path,isolation_level=None)
        self.db.executescript('''PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
PRAGMA synchronous=FULL; PRAGMA secure_delete=ON;
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,uidkey TEXT UNIQUE NOT NULL,
identity TEXT UNIQUE NOT NULL,content TEXT NOT NULL,created REAL NOT NULL,state TEXT NOT NULL,
expected INTEGER NOT NULL DEFAULT 0,pages INTEGER,notification TEXT NOT NULL DEFAULT 'PENDING');
CREATE TABLE IF NOT EXISTS private(job TEXT PRIMARY KEY REFERENCES jobs(id),sender_hash TEXT NOT NULL,
sender TEXT NOT NULL,number TEXT NOT NULL,message_id TEXT,expires REAL NOT NULL);
CREATE TABLE IF NOT EXISTS seen(uidkey TEXT PRIMARY KEY,created REAL NOT NULL,code TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mailbox(account TEXT PRIMARY KEY,validity TEXT NOT NULL,highwater INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS outbox(job TEXT PRIMARY KEY REFERENCES jobs(id),due REAL NOT NULL,attempts INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS received(id TEXT PRIMARY KEY,created REAL NOT NULL,state TEXT NOT NULL,pages INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS received_mail(job TEXT NOT NULL REFERENCES received(id),recipient TEXT NOT NULL,state TEXT NOT NULL,due REAL NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(job,recipient));
CREATE TABLE IF NOT EXISTS notice_budget(recipient_hash TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS job_details(job TEXT PRIMARY KEY,notes TEXT NOT NULL DEFAULT '[]',reserved REAL);
''')
        fingerprint=hmac.new(key,b'faxmail-key-check',hashlib.sha256).hexdigest()
        old=self.db.execute("SELECT v FROM meta WHERE k='key_check'").fetchone()
        require(not old or hmac.compare_digest(old[0],fingerprint),'DEDUPE_KEY_CHANGED')
        self.db.execute("INSERT OR IGNORE INTO meta VALUES('key_check',?)",(fingerprint,))
    def digest(self,value):return hmac.new(self.key,value,hashlib.sha256).hexdigest()
    def claim_notice(self,recipient,now=None):
        now=time.time() if now is None else now
        hashed=self.digest(recipient.encode())
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('INSERT INTO notice_budget VALUES(?,?)',(hashed,now))
            self.db.execute('DELETE FROM notice_budget WHERE created<=?',(now-168*3600,))
            self.db.execute('COMMIT');return True
        except Exception:
            if self.db.in_transaction:self.db.execute('ROLLBACK')
            raise
    def baseline(self,account,validity,uidnext,initialize=False):
        row=self.db.execute('SELECT validity,highwater FROM mailbox WHERE account=?',(account,)).fetchone()
        if row:
            require(row[0]==str(validity),'UIDVALIDITY_CHANGED')
            return row[1]
        require(initialize,'MAILBOX_BASELINE_REQUIRED')
        require(int(uidnext)>0,'MAILBOX_UIDNEXT_INVALID')
        self.db.execute('INSERT INTO mailbox VALUES(?,?,?)',(account,str(validity),int(uidnext)-1))
        return int(uidnext)-1
    def recorded(self,account,validity,uid):
        key=self.digest(f'{account}\0INBOX\0{validity}\0{uid}'.encode())
        return self.db.execute('SELECT 1 FROM seen WHERE uidkey=?',(key,)).fetchone() is not None
    def record(self,account,validity,uid,code):
        key=self.digest(f'{account}\0INBOX\0{validity}\0{uid}'.encode())
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('INSERT OR IGNORE INTO seen VALUES(?,?,?)',(key,time.time(),code))
            self.db.execute('UPDATE mailbox SET highwater=max(highwater,?) WHERE account=? AND validity=?',(uid,account,str(validity)))
            self.db.execute('COMMIT')
        except Exception:self.db.execute('ROLLBACK');raise
    def ingest(self,account,validity,uid,raw,doc,now=None,rejection=False):
        now=time.time() if now is None else now
        uidkey=self.digest(f'{account}\0INBOX\0{validity}\0{uid}'.encode())
        content=self.digest(raw)
        identity=self.digest((doc.sender+'\0'+doc.message_id).encode()) if doc.message_id else content
        job=str(uuid.uuid4())
        self.db.execute('BEGIN IMMEDIATE')
        try:
            old=self.db.execute('SELECT id,content FROM jobs WHERE uidkey=? OR identity=?',(uidkey,identity)).fetchone()
            if old:
                require(old[1]==content,'MESSAGE_ID_COLLISION')
                self.db.execute('COMMIT');return old[0],False
            if not rejection:require(self.db.execute("SELECT count(*) FROM jobs WHERE state IN ('VALIDATING','READY','DISPATCH_RESERVED')").fetchone()[0]<100,'QUEUE_FULL')
            sender_hash=self.digest(doc.sender.encode())
            self.db.execute('INSERT INTO jobs(id,uidkey,identity,content,created,state) VALUES(?,?,?,?,?,?)',(job,uidkey,identity,content,now,'REJECTED' if rejection else 'VALIDATING'))
            self.db.execute('INSERT INTO private VALUES(?,?,?,?,?,?)',(job,sender_hash,doc.sender,doc.number,doc.message_id,now+168*3600))
            self.db.execute('COMMIT');return job,True
        except Exception:
            if self.db.in_transaction:self.db.execute('ROLLBACK')
            raise
    def ready(self,job,pages):
        require(1<=pages<=20,'PAGE_LIMIT')
        self.db.execute("UPDATE jobs SET state='READY',expected=? WHERE id=? AND state='VALIDATING'",(pages,job))
    def reserve(self,job,now=None):
        now=time.time() if now is None else now
        cursor=self.db.execute("UPDATE jobs SET state='DISPATCH_RESERVED' WHERE id=? AND state='READY' AND created>?",(job,now-86400))
        if cursor.rowcount==1:self.db.execute('INSERT INTO job_details(job,reserved) VALUES(?,?) ON CONFLICT(job) DO UPDATE SET reserved=excluded.reserved',(job,now))
        return cursor.rowcount==1
    def recover(self):
        self.db.execute("UPDATE jobs SET state='UNKNOWN' WHERE state IN ('DISPATCH_RESERVED','SENDING')")
        self.db.execute("INSERT OR IGNORE INTO outbox(job,due) SELECT id,? FROM jobs WHERE state='UNKNOWN'",(time.time(),))
        self.db.execute("UPDATE jobs SET notification='DELIVERY_UNKNOWN' WHERE notification='SENDING'")
    def result(self,job,status,pages):
        row=self.db.execute('SELECT expected,state FROM jobs WHERE id=?',(job,)).fetchone()
        require(row is not None,'JOB_MISSING')
        if row[1] not in ['DISPATCH_RESERVED','SENDING','UNKNOWN']:return False
        state='SUCCEEDED' if status=='SUCCESS' and pages==row[0] else ('UNKNOWN' if status=='UNKNOWN' else 'FAILED')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('UPDATE jobs SET state=?,pages=? WHERE id=?',(state,pages,job))
            self.db.execute('INSERT INTO outbox(job,due) VALUES(?,?) ON CONFLICT(job) DO UPDATE SET due=min(due,excluded.due)',(job,time.time()))
            self.db.execute('COMMIT')
        except Exception:self.db.execute('ROLLBACK');raise
        return True
    def expire(self,now=None):
        now=time.time() if now is None else now
        ids=[r[0] for r in self.db.execute('SELECT job FROM private WHERE expires<=?',(now,))]
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute("UPDATE jobs SET notification='EXPIRED' WHERE id IN (SELECT job FROM private WHERE expires<=?)",(now,))
            self.db.execute('DELETE FROM private WHERE expires<=?',(now,))
            self.db.execute('DELETE FROM job_details WHERE job IN (SELECT id FROM jobs WHERE created<=?)',(now-168*3600,))
            self.db.execute("INSERT OR IGNORE INTO outbox(job,due) SELECT id,? FROM jobs WHERE state IN ('READY','VALIDATING') AND created<=?",(now,now-86400))
            self.db.execute("UPDATE jobs SET state='EXPIRED' WHERE state IN ('READY','VALIDATING') AND created<=?",(now-86400,))
            self.db.execute('COMMIT')
        except Exception:self.db.execute('ROLLBACK');raise
        self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        return ids
