"""Redacted state reporting and conservative crash/restore recovery."""
import json,os,re,shutil,subprocess,time,uuid
from pathlib import Path
from . import control
from .validation import require

def command(*args):return subprocess.run(args,capture_output=True,text=True,timeout=40)

def verify_database_generation(store):
    if (control.STATE/'restore-review-required').exists():
        control.pause();raise RuntimeError('DATABASE_REVIEW_REQUIRED')
    marker=control.STATE/'database-generation.json'
    row=store.db.execute("SELECT v FROM meta WHERE k='generation'").fetchone()
    current=int(row[0]) if row else 0
    if marker.exists() and current<int(json.loads(marker.read_text())['generation']):
        control.health('database','DATABASE_ROLLBACK');control.pause()
        raise RuntimeError('DATABASE_ROLLBACK')

def checkpoint_generation(store):
    store.db.execute("INSERT INTO meta(k,v) VALUES('generation','1') ON CONFLICT(k) DO UPDATE SET v=CAST(v AS INTEGER)+1")
    current=int(store.db.execute("SELECT v FROM meta WHERE k='generation'").fetchone()[0])
    p=control.STATE/'database-generation.json';tmp=p.with_suffix('.tmp')
    with tmp.open('w') as f:json.dump({'generation':current},f);f.flush();os.fsync(f.fileno())
    tmp.chmod(0o600);os.replace(tmp,p)

def reconcile(store,config):
    with control.admission_lock():
        _reconcile_locked(store,config)

def _reconcile_locked(store,config):
    snapshot=Path('/var/lib/fax-engine-state/engine-state.json')
    data=json.loads(snapshot.read_text()) if snapshot.is_file() else {}
    fresh=time.time()-data.get('updated',0)<180
    active=set(data.get('active',[])) if fresh else set()
    queued=set(data.get('queued',[])) if fresh else set()
    store.recover()
    for job, in store.db.execute("SELECT id FROM jobs WHERE state='UNKNOWN'").fetchall():
        # A surviving request is never a reason to dispatch an UNKNOWN job.
        (Path('/var/spool/faxmail-next/requests')/(job+'.json')).unlink(missing_ok=True)
        event=Path('/var/spool/faxmail-next/events')/(job+'.json')
        if event.is_file() and not event.is_symlink():
            info=json.loads(event.read_text())
            if info.get('job')==job:store.result(job,info.get('status'),int(info.get('pages',0)));continue
        if job in active or job in queued:
            store.db.execute("UPDATE jobs SET state=? WHERE id=?",('SENDING' if job in active else 'DISPATCH_RESERVED',job))
            store.db.execute('DELETE FROM outbox WHERE job=?',(job,))
        else:
            store.db.execute('UPDATE outbox SET due=max(due,?) WHERE job=?',(time.time()+1100,job))

def rebaseline(config,store):
    from .mailio import imap_connect
    from .worker import response_integer
    require(control.paused(),'PAUSE_REQUIRED')
    snapshot=json.loads(Path('/var/lib/fax-engine-state/engine-state.json').read_text())
    require(time.time()-snapshot.get('updated',0)<180 and snapshot.get('idle') is True and not snapshot.get('queued'),'ENGINE_NOT_IDLE')
    client=imap_connect(config)
    try:
        require(client.select('INBOX',readonly=True)[0]=='OK','IMAP_SELECT_FAILED')
        validity=response_integer(client,'UIDVALIDITY');nextuid=response_integer(client,'UIDNEXT')
    finally:client.logout()
    # Retain all identity/HMAC/UID seen records; fence old waiting jobs.
    store.recover()
    for job, in store.db.execute("SELECT id FROM jobs WHERE state='UNKNOWN'"):
        (Path('/var/spool/faxmail-next/requests')/(job+'.json')).unlink(missing_ok=True)
    store.db.execute("UPDATE jobs SET state='EXPIRED' WHERE state IN ('READY','VALIDATING')")
    store.db.execute('INSERT INTO mailbox(account,validity,highwater) VALUES(?,?,?) ON CONFLICT(account) DO UPDATE SET validity=excluded.validity,highwater=excluded.highwater',(store.digest(config['mail']['fax_address'].encode()),str(validity),nextuid-1))
    marker=control.STATE/'database-generation.json'
    old=int(json.loads(marker.read_text())['generation']) if marker.exists() else 0
    store.db.execute("INSERT INTO meta(k,v) VALUES('generation',?) ON CONFLICT(k) DO UPDATE SET v=max(CAST(v AS INTEGER),CAST(excluded.v AS INTEGER))",(str(old),))
    checkpoint_generation(store)
    (control.STATE/'restore-review-required').unlink(missing_ok=True)
    print('new_baseline_saved_still_paused: OK')

def conversion_failed(directory):
    p=Path(directory)
    require(str(uuid.UUID(p.name))==p.name,'JOB_INVALID')
    require(not p.is_symlink() and p.resolve().parent in [Path('/var/spool/faxmail-next/jobs'),Path('/var/spool/faxmail-next/incoming')],'WORKSPACE_INVALID')
    require(not any(v.is_symlink() for v in p.iterdir()),'WORKSPACE_INVALID')
    if not (p/'conversion.json').exists():(p/'conversion.error').write_text('CONVERSION_RESOURCE_FAILURE')
    (p/'convert.request').unlink(missing_ok=True)

def status(config,store):
    def flag(k,v):print(k+': '+('OK' if v else 'MISSING'))
    for name in ['fax-receive-live','faxmail-next','faxmail-dispatch','faxmail-receive-mail.timer','faxmail-cleanup.timer']:
        flag('service_'+name.replace('-','_').replace('.','_'),command('systemctl','is-active','--quiet',name).returncode==0)
    snapshot=Path('/var/lib/fax-engine-state/engine-state.json')
    data=json.loads(snapshot.read_text()) if snapshot.exists() else {}
    flag('sip_registered',time.time()-data.get('updated',0)<180 and data.get('registered') is True)
    flag('new_sends_enabled',not control.paused());flag('disk_space',control.disk_ok())
    for state in ['VALIDATING','READY','DISPATCH_RESERVED','SENDING','UNKNOWN','EXPIRED']:
        print('jobs_'+state.lower()+': '+str(store.db.execute('SELECT COUNT(*) FROM jobs WHERE state=?',(state,)).fetchone()[0]))
    for state in ['PENDING','RETRY_WAIT','DELIVERY_UNKNOWN','FAILED','SENT']:
        n=store.db.execute('SELECT COUNT(*) FROM received_mail WHERE state=?',(state,)).fetchone()[0]+store.db.execute('SELECT COUNT(*) FROM jobs WHERE notification=?',(state,)).fetchone()[0]
        print('notifications_'+state.lower()+': '+str(n))
    for component in ['imap','smtp','worker','database']:
        p=control.STATE/('health-'+component+'.json')
        if p.exists():flag(component+'_last_operation_ok',json.loads(p.read_text()).get('code')=='OK')
    flag('smtp_auth_not_blocked',not control.smtp_blocked())
    from .mailio import imap_connect,smtp_connect
    for name,connect in [('imap',imap_connect),('smtp',smtp_connect)]:
        client=None
        try:
            if name=='smtp' and control.smtp_blocked():raise RuntimeError('AUTH_BACKOFF')
            client=connect(config);flag(name+'_connection',True)
        except Exception:flag(name+'_connection',False)
        finally:
            if client:
                try:client.logout() if name=='imap' else client.close()
                except Exception:pass
