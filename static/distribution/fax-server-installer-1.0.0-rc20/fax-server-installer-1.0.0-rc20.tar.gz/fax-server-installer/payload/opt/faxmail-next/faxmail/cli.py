import argparse,json,os,shutil,sys,time
from pathlib import Path
from .validation import Reject

CONFIG=Path('/etc/faxmail-next/site-mail.json')
STATE=Path('/var/lib/faxmail-next')
def report(key,good):print(key+': '+('OK' if good else 'MISSING'))
def preflight():
    try:config=json.loads(CONFIG.read_text())
    except Exception:
        report('configuration',False);return 2
    auth=config['mail']['authentication']
    independent=auth.get('mechanism')=='aligned_dkim'
    if independent:
        import importlib.util
        independent=importlib.util.find_spec('dkim') is not None
    checks={
        'mail_trusted_authserv_ids':independent or bool(auth.get('trusted_authserv_ids')),
        'mail_trust_boundary':independent or auth.get('trust_boundary_verified') is True,
        'mail_auth_placement':independent or (auth.get('placement_verified') is True and isinstance(auth.get('authentication_results_index'),int)),
        'disk_space':shutil.disk_usage(STATE).free>=2*1024**3,
        'deduplication_key':(STATE/'dedupe.key').exists(),
        'transmission_gate':Path('/etc/faxmail-next/acceptance-approved.json').exists(),
    }
    from .configuration import validate
    try:checks['configuration_schema']=validate(config)
    except Exception:checks['configuration_schema']=False
    checks['configuration_permissions']=all(p.is_file() and not p.is_symlink() and p.stat().st_uid==0 and not p.stat().st_mode&0o027 for p in [CONFIG,Path('/etc/faxmail-next/validation.json')])
    key=STATE/'dedupe.key'
    checks['deduplication_key_permissions']=key.is_file() and not key.is_symlink() and key.stat().st_mode&0o777==0o600 and key.stat().st_size>=32
    import importlib.metadata
    dependency_file=Path('/etc/faxmail-next/dependency-lock.json')
    try:
        expected=json.loads(dependency_file.read_text())
        checks['dependency_versions']=bool(expected) and all(importlib.metadata.version(k)==v for k,v in expected.items())
    except Exception:checks['dependency_versions']=False
    checks['conversion_tools']=all(shutil.which(v) for v in ['gs','tiffinfo','tiffcp','asterisk','systemctl'])
    try:
        import hashlib,subprocess
        provenance=json.loads(Path('/opt/faxmail-next/asterisk-a3-source/provenance.json').read_text())
        version=subprocess.run(['dpkg-query','-W','-f=${Version}','asterisk'],capture_output=True,text=True,timeout=5)
        module=Path('/opt/faxmail-next/asterisk-modules/res_fax_spandsp.so')
        checks['fax_a3_engine']=version.returncode==0 and version.stdout.strip()==provenance['asterisk_version'] and hashlib.sha256(module.read_bytes()).hexdigest()==provenance['module_sha256']
    except Exception:checks['fax_a3_engine']=False
    from .control import LOCK
    checks['shared_control']=LOCK.is_file() and not LOCK.is_symlink()
    snapshot=Path('/var/lib/fax-engine-state/engine-state.json')
    try:
        engine=json.loads(snapshot.read_text());fresh=time.time()-engine.get('updated',0)<180
        for name in ['modules','ntp','firewall']:checks[name]=fresh and engine.get(name) is True
    except Exception:
        for name in ['modules','ntp','firewall']:checks[name]=False
    for key,value in checks.items():report(key,value)
    return 0 if all(checks.values()) else 2
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['preflight','status','pause','resume','verify','cleanup','worker','convert-job','convert-received','conversion-failed','restore-state','rebaseline','broker','dispatch'])
    parser.add_argument('--redacted',action='store_true');parser.add_argument('--offline',action='store_true');parser.add_argument('--dry-run',action='store_true')
    parser.add_argument('--job-dir');args=parser.parse_args()
    if args.command=='verify':
        if not args.offline:return 2
        from .selftest import run
        return run()
    if args.command=='preflight':return preflight()
    if args.command=='restore-state':
        from .backup import restore
        restore(args.job_dir);return 0
    if args.command=='rebaseline':
        from .operations import rebaseline
        from .store import Store
        rebaseline(json.loads(CONFIG.read_text()),Store(STATE/'jobs.sqlite',(STATE/'dedupe.key').read_bytes()));return 0
    if args.command=='status':
        from .operations import status
        from .store import Store
        status(json.loads(CONFIG.read_text()),Store(STATE/'jobs.sqlite',(STATE/'dedupe.key').read_bytes()))
        return preflight()
    if args.command=='pause':
        from .control import pause
        pause();print('paused: OK');return 0
    if args.command=='resume':
        from .worker import gate
        gate()
        if preflight():print('resume: BLOCKED');return 2
        from .control import resume
        from .operations import verify_database_generation
        from .store import Store
        verify_database_generation(Store(STATE/'jobs.sqlite',(STATE/'dedupe.key').read_bytes()))
        resume();print('resume: OK');return 0
    if args.command=='conversion-failed':
        from .operations import conversion_failed
        conversion_failed(args.job_dir);return 0
    if args.command=='worker':
        from .worker import gate,run
        gate()
        if preflight():return 2
        run(json.loads(CONFIG.read_text()));return 0
    if args.command=='broker':
        from .broker import run
        run();return 0
    if args.command=='dispatch':
        from .dispatch import run
        run(json.loads(Path('/etc/faxmail-next/site-fax.json').read_text()));return 0
    if args.command=='convert-received':
        from .convert import receive_pdf
        directory=Path(args.job_dir)
        try:
            pages=receive_pdf(directory/'document.tif',directory/'document.pdf')
            temp=directory/'conversion.tmp';temp.write_text(json.dumps({'pages':pages}))
            temp.replace(directory/'conversion.json');return 0
        except Exception:
            (directory/'conversion.error').write_text('RECEIVE_CONVERSION_FAILED');raise
    if args.command=='cleanup':
        from .store import Store
        key=(STATE/'dedupe.key').read_bytes()
        store=Store(STATE/'jobs.sqlite',key)
        ids=[r[0] for r in store.db.execute('SELECT job FROM private WHERE expires<=?',(time.time(),))]
        print('expired_jobs: '+str(len(ids)))
        if args.dry_run:return 0
        # Validate every path before deleting any file; follow no symlinks.
        import uuid
        spool=Path('/var/spool/faxmail-next/jobs').resolve()
        paths=[]
        for job in ids:
            if str(uuid.UUID(job))!=job:raise Reject('CLEANUP_PATH')
            target=spool/job
            if target.is_symlink() or target.resolve().parent!=spool:raise Reject('CLEANUP_PATH')
            if target.exists():
                if any(p.is_symlink() for p in target.rglob('*')):raise Reject('CLEANUP_PATH')
                paths.append(target)
        for target in paths:shutil.rmtree(target)
        for job in ids:
            for parent,suffix in [('/var/spool/faxmail-next/requests','.json'),('/var/spool/faxmail-next/events','.json')]:
                p=Path(parent)/(job+suffix)
                if p.is_symlink():raise Reject('CLEANUP_PATH')
                p.unlink(missing_ok=True)
        incoming=Path('/var/spool/faxmail-next/incoming').resolve()
        for directory in incoming.iterdir():
            if directory.is_symlink() or not directory.is_dir():continue
            try:
                if str(uuid.UUID(directory.name))!=directory.name:continue
                created=float((directory/'started').read_text())
            except (ValueError,OSError):continue
            if created>time.time()-168*3600:continue
            if any(p.is_symlink() for p in directory.rglob('*')):raise Reject('CLEANUP_PATH')
            shutil.rmtree(directory)
            (Path('/var/spool/faxmail-next/events')/(directory.name+'.json')).unlink(missing_ok=True)
        store.db.execute('DELETE FROM received_mail WHERE job IN (SELECT id FROM received WHERE created<=?)',(time.time()-168*3600,))
        store.db.execute("UPDATE received SET state='EXPIRED' WHERE created<=?",(time.time()-168*3600,))
        store.expire();print('cleanup: OK');return 0
    if args.command=='convert-job':
        from .validation import parse
        from .convert import convert
        directory=Path(args.job_dir)
        try:
            config=json.loads(Path('/etc/faxmail-next/validation.json').read_text())
            raw=(directory/'input.eml').read_bytes()
            if config['mail']['authentication'].get('mechanism') in ['aligned_dkim','provider_dmarc_arc']:
                keys=directory/'verified-dkim-keys.json'
                if keys.is_symlink() or keys.stat().st_size>65536:raise Reject('DKIM_KEYS_INVALID')
                config['mail']['authentication']['_cached_keys']=json.loads(keys.read_text())
            document=parse(raw,config)
            import tempfile
            with tempfile.TemporaryDirectory(prefix='fax-convert-') as scratch:
                pages,notes=convert(document,Path(scratch))
                outputs=[Path(scratch)/name for name in ['document.pdf','document.tif']]
                if len(raw)+sum(p.stat().st_size for p in outputs)>512*1024**2:raise Reject('WORKSPACE_SIZE')
                for source in outputs:shutil.copyfile(source,directory/source.name)
            temp=directory/'conversion.tmp'
            temp.write_text(json.dumps({'pages':pages,'notes':notes}));temp.replace(directory/'conversion.json')
            print('conversion: OK');return 0
        except Exception:
            (directory/'conversion.error').write_text('CONVERSION_FAILED')
            raise
        finally:(directory/'convert.request').unlink(missing_ok=True)
    return 2
def entry():
    try:return main()
    except Reject as exc:
        # Exception codes originate exclusively in application source.
        print('operation: BLOCKED');return 2
    except Exception:
        print('operation: FAIL');return 1
if __name__=='__main__':sys.exit(entry())
