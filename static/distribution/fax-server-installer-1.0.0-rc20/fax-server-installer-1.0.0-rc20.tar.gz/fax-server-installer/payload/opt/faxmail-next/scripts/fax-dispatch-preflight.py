#!/usr/bin/python3
"""Exercise atomic publication without racing Asterisk's call-file consumer."""
import json,os,sys,tempfile
from pathlib import Path


def check(config):
    # Asterisk inspects every regular file immediately below outgoing, even
    # dotfiles without .call suffixes. It ignores subdirectories and does not
    # recurse, so exercise the same cross-spool rename inside private probes.
    with tempfile.TemporaryDirectory(prefix='.fax-publish-probe-',dir=config['fax']['staging_spool']) as staging:
        with tempfile.TemporaryDirectory(prefix='.fax-publish-probe-',dir=config['fax']['outgoing_spool']) as outgoing:
            source=Path(staging)/'probe';target=Path(outgoing)/'probe'
            with source.open('xb') as stream:
                os.fchmod(stream.fileno(),0o660)
                stream.write(b'atomic publication check; not a call file\n')
                stream.flush();os.fsync(stream.fileno())
            os.replace(source,target)
            if not target.is_file() or target.stat().st_mode&0o777!=0o660:
                raise RuntimeError('PROBE_VERIFICATION_FAILED')


def failure_details(error):
    # Only fixed labels, exception classes and errno; no config, paths or values.
    import errno
    if isinstance(error,OSError) and error.errno==errno.EXDEV:print('dispatch_cross_mount: YES')
    print('dispatch_preflight_error: '+type(error).__name__+' errno='+str(getattr(error,'errno',None)))
    print('dispatch_preflight: FAIL')


if __name__=='__main__':
    try:
        check(json.loads(Path('/etc/faxmail-next/site-fax.json').read_text()))
        print('dispatch_preflight: PASS')
    except Exception as error:
        failure_details(error);sys.exit(1)
