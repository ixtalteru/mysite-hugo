"""Move only identified, completed FAX request messages; never expunge."""
import re,time
from .validation import require

def trash_folder(client):
    status,rows=client.list();require(status=='OK','TRASH_LIST_FAILED')
    found=[]
    for row in rows or []:
        if not isinstance(row,bytes):continue
        m=re.fullmatch(rb'\(([^)]*)\)\s+(?:"(?:[^"\\]|\\.)*"|NIL)\s+(.+)',row)
        if m and b'\\trash' in m[1].lower().split():
            name=m[2];require(not any(c in name for c in [b'\r',b'\n']),'TRASH_NAME_INVALID')
            if not name.startswith(b'"'):
                require(re.fullmatch(rb'[A-Za-z0-9_./-]+',name),'TRASH_NAME_INVALID')
                name=b'"'+name+b'"'
            found.append(name)
    require(len(found)==1,'TRASH_FOLDER_AMBIGUOUS')
    return found[0]

def move_completed(config,store,client):
    if config['mail'].get('trash_completed_requests') is not True:return 0
    status,caps=client.capability();require(status=='OK' and caps and b'MOVE' in caps[0].upper().split(),'IMAP_MOVE_REQUIRED')
    destination=trash_folder(client)
    require(client.select('INBOX',readonly=False)[0]=='OK','IMAP_SELECT_FAILED')
    from .worker import response_integer
    validity=response_integer(client,'UIDVALIDITY')
    account=store.digest(config['mail']['fax_address'].encode())
    row=store.db.execute('SELECT validity FROM mailbox WHERE account=?',(account,)).fetchone()
    require(row and str(row[0])==str(validity),'UIDVALIDITY_CHANGED')
    candidates={r[0] for r in store.db.execute("""SELECT uidkey FROM jobs WHERE state IN
        ('SUCCEEDED','FAILED','REJECTED','UNKNOWN','EXPIRED')
        AND notification IN ('SENT','FAILED','DELIVERY_UNKNOWN') AND created>?""",(time.time()-168*3600,))}
    if not candidates:return 0
    status,rows=client.uid('SEARCH',None,'ALL');require(status=='OK','TRASH_SEARCH_FAILED')
    moved=0
    for token in (rows[0] or b'').split():
        require(token.isdigit(),'TRASH_UID_INVALID')
        uid=int(token);key=store.digest(f'{account}\0INBOX\0{validity}\0{uid}'.encode())
        if key not in candidates:continue
        # UIDVALIDITY checked above; unchanged UIDs cannot refer to another message.
        status,_=client.uid('MOVE',str(uid),destination)
        require(status=='OK','TRASH_MOVE_FAILED')
        moved+=1
        if moved>=50:break
    return moved
