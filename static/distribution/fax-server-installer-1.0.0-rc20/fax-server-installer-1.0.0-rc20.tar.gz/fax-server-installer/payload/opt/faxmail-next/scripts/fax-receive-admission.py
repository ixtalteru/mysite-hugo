#!/usr/bin/python3
import json,pathlib,shutil,sys,time
for line in sys.stdin:
 if not line.strip():break
allowed=shutil.disk_usage('/var/spool/faxmail-next/incoming').free>=2*1024**3
path=pathlib.Path('/var/lib/fax-receive-live/data/receive-health.json')
path.write_text(json.dumps({'code':'OK' if allowed else 'DISK_LOW','updated':time.time()}))
print('SET VARIABLE FAX_RECEIVE_ALLOWED '+('1' if allowed else '0'),flush=True)
sys.stdin.readline()
