"""Versioned runtime configuration checks; never return configuration values."""
from .validation import canonical,require
SCHEMA_VERSION=1
def validate(config):
 require(config.get('schema_version',1)==SCHEMA_VERSION,'SCHEMA_VERSION')
 mail=config['mail'];fax=config['fax']
 canonical(mail['fax_address'])
 require(isinstance(mail['allowed_senders'],list),'SENDERS_MISSING')
 for value in mail['allowed_senders']+mail.get('receive_recipients',[]):canonical(value)
 require(fax.get('mode') in ['dry-run','test','production'],'MODE_INVALID')
 for name in ['imap','smtp']:
  c=mail[name];require(isinstance(c['host'],str) and bool(c['host']),'MAIL_HOST_MISSING')
  require(isinstance(c['port'],int) and 1<=c['port']<=65535,'MAIL_PORT_INVALID')
  require(c['auth_type']=='password' and c.get('username') and c.get('password'),'MAIL_CREDENTIALS_MISSING')
  require(c['security'] in ['ssl','tls','implicit_tls','SSL/TLS','starttls','STARTTLS'],'MAIL_TLS_REQUIRED')
 require(mail['imap'].get('folder','INBOX').upper()=='INBOX','MAILBOX_UNSUPPORTED')
 require(isinstance(fax.get('allowed_domestic_prefixes'),list) and bool(fax['allowed_domestic_prefixes']),'NUMBER_POLICY_MISSING')
 for value in fax['allowed_domestic_prefixes']+fax.get('blocked_prefixes',[]):
  require(isinstance(value,str) and value.isascii() and value.isdigit(),'NUMBER_POLICY_INVALID')
 return True
