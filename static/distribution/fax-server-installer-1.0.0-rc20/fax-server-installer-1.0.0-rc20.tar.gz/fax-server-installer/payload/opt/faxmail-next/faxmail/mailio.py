"""TLS mail transports; no sends without a separate, explicit runtime gate."""
import imaplib,smtplib,ssl,time
from email.message import EmailMessage
from .validation import require,Reject

def imap_connect(config):
    c=config['mail']['imap']
    require(c['security'] in ['ssl','tls','implicit_tls','SSL/TLS','starttls','STARTTLS'],'IMAP_TLS_REQUIRED')
    require(c['auth_type']=='password','MAIL_AUTH_UNSUPPORTED')
    context=ssl.create_default_context()
    if c['security'] in ['starttls','STARTTLS']:
        client=imaplib.IMAP4(c['host'],int(c['port']),timeout=30)
        try:client.starttls(ssl_context=context)
        except Exception:
            try:client.shutdown()
            except Exception:pass
            raise
    else:
        client=imaplib.IMAP4_SSL(c['host'],int(c['port']),ssl_context=context,timeout=30)
    try:client.login(c['username'],c['password'])
    except imaplib.IMAP4.abort:
        try:client.shutdown()
        except Exception:pass
        raise
    except imaplib.IMAP4.error:
        try:client.logout()
        except Exception:pass
        raise Reject('IMAP_AUTH_FAILED') from None
    return client

def smtp_connect(config):
    c=config['mail']['smtp'];context=ssl.create_default_context()
    require(c['auth_type']=='password','MAIL_AUTH_UNSUPPORTED')
    if c['security'] in ['ssl','tls','implicit_tls','SSL/TLS']:
        client=smtplib.SMTP_SSL(c['host'],int(c['port']),context=context,timeout=30)
    else:
        require(c['security'] in ['starttls','STARTTLS'],'SMTP_TLS_REQUIRED')
        client=smtplib.SMTP(c['host'],int(c['port']),timeout=30)
        client.ehlo();client.starttls(context=context);client.ehlo()
    try:client.login(c['username'],c['password'])
    except smtplib.SMTPAuthenticationError as exc:
        client.close()
        if 400<=exc.smtp_code<500:raise
        raise Reject('SMTP_AUTH_FAILED') from None
    except Exception:
        client.close();raise
    return client

def send_notification(config,message,recipient,permission=False):
    require(permission is True,'MAIL_SEND_NOT_AUTHORIZED')
    from . import control
    if control.smtp_blocked():return 'RETRY_WAIT'
    # Explicit envelope recipient; never use arbitrary To/Cc/Bcc from input.
    client=None;submitted=False
    try:
        client=smtp_connect(config)
        submitted=True
        client.sendmail(config['mail']['fax_address'],[recipient],message.as_bytes())
        control.health('smtp','OK')
        return 'SENT'
    except Reject as exc:
        if str(exc)=='SMTP_AUTH_FAILED':control.block_smtp();return 'RETRY_WAIT'
        raise
    except smtplib.SMTPResponseException as exc:
        return 'RETRY_WAIT' if 400<=exc.smtp_code<500 else 'FAILED'
    except smtplib.SMTPRecipientsRefused as exc:
        codes=[value[0] for value in exc.recipients.values()]
        return 'RETRY_WAIT' if codes and all(400<=code<500 for code in codes) else 'FAILED'
    except (OSError,smtplib.SMTPServerDisconnected):
        control.health('smtp','SMTP_UNAVAILABLE')
        return 'DELIVERY_UNKNOWN' if submitted else 'RETRY_WAIT'
    finally:
        if client:client.close()

def notification(config,job,recipient,status,pages,message_id=None,created=None,notes=None,number=None,expected=None):
    require(status in ['SUCCEEDED','FAILED','UNKNOWN','REJECTED','EXPIRED'],'STATUS_INVALID')
    message=EmailMessage()
    message['From']=config['mail']['fax_address'];message['To']=recipient
    labels={'SUCCEEDED':'送信成功','FAILED':'送信失敗','UNKNOWN':'送信結果不明','REJECTED':'受付拒否','EXPIRED':'送信期限切れ'}
    message['Subject']='[FAX '+status+'] '+labels[status]+' '+job
    message['Message-ID']='<'+job+'@faxmail.invalid>'
    message['Auto-Submitted']='auto-generated'
    if message_id:
        message['In-Reply-To']=message_id;message['References']=message_id
    from datetime import datetime
    from zoneinfo import ZoneInfo
    from email.utils import format_datetime
    stamp=datetime.fromtimestamp(created if created is not None else time.time(),ZoneInfo('Asia/Tokyo'))
    message['Date']=format_datetime(datetime.now(ZoneInfo('Asia/Tokyo')))
    body='日時: '+stamp.isoformat(timespec='seconds')+'\nJob: '+job+'\nResult: '+status+'\nPages: '+str(pages)
    body+='\n送信結果: '+labels[status]
    if number and __import__('re').fullmatch(r'0[0-9]{9,10}',number):body+='\n宛先FAX番号: '+number
    body+='\n送信済みページ数: '+str(pages)
    if expected is not None:body+='\n原稿ページ数: '+str(expected)
    if status=='SUCCEEDED':body+='\n相手先FAXとの通信で、原稿の全ページ送信完了を確認しました。'
    elif status=='FAILED':body+='\nFAXの全ページ送信を完了できませんでした。'
    elif status=='UNKNOWN':body+='\nFAXの送信完了を確認できませんでした。相手先に受信状況をご確認ください。'
    elif status=='EXPIRED':body+='\n処理期限内に送信を完了できませんでした。'
    explanations={'FAX_TRAINING_FAILED':'FAX信号の試験通信（トレーニング）に失敗し、ページ送信を完了できませんでした。','MPO_PRIMARY_IMAGE_USED':'複数画像を含むJPEGは先頭の主画像を使用しました。','EXTERNAL_IMAGE_OMITTED':'外部画像は省略しました。','QUEUE_FULL':'送信待ち件数が上限を超えたため受け付けできません。','SENDER_RATE':'送信者ごとの受付頻度上限を超えました。','GLOBAL_RATE':'サーバー全体の受付頻度上限を超えました。','CONVERSION_FAILED':'原稿変換に失敗しました。'}
    from .rejection import EXPLANATIONS
    explanations.update(EXPLANATIONS)
    explanations['DISPATCH_FAILED']='FAX発信前に、サーバー内で発信指示を渡す処理に失敗しました。外線への発信は行われていません。'
    for note in notes or []:
        if note in explanations:
            body+='\n'+explanations[note]
            if status=='REJECTED':body+='\n理由コード: '+note
    if status in ['FAILED','UNKNOWN']:
        body+='\n自動再送はしません。' if 'DISPATCH_FAILED' in (notes or []) else '\n一部が届いている可能性があります。自動再送はしません。'
    message.set_content(body)
    return message
