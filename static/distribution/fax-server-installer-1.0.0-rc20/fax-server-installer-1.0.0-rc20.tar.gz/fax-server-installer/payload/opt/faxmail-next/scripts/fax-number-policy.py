#!/usr/bin/python3
"""Final number policy check before Dial; AGI protocol only on stdout."""
import json,re,sys
from pathlib import Path
sys.path.insert(0,'/opt/faxmail-next')
from faxmail.validation import validate_number
from faxmail.control import paused,disk_ok
for line in sys.stdin:
 if not line.strip():break
print('GET VARIABLE EXTEN',flush=True)
line=sys.stdin.readline();match=re.fullmatch(r'200 result=1 \(([^\r\n]*)\)\n?',line)
allowed=False
try:
 number=match.group(1) if match else ''
 config=json.loads(Path('/etc/faxmail-next/number-policy.json').read_text())
 validate_number(number,config,'production');allowed=not paused() and disk_ok()
except Exception:pass
print('SET VARIABLE FAX_NUMBER_ALLOWED '+('1' if allowed else '0'),flush=True)
sys.stdin.readline()
