"""Bind the selected provider Authentication-Results to its verified ARC set."""
import base64,re
from email import policy
from email.parser import BytesParser
from .validation import require,Reject

def tags(value):
 result={}
 for part in str(value).split(';'):
  if not part.strip():continue
  key,sep,text=part.strip().partition('=')
  require(sep and key not in result,'ARC_SYNTAX');result[key.lower()]=text.strip()
 return result

def verify(raw,auth):
 import dkim
 require(isinstance(raw,bytes),'SIGNED_MESSAGE_REQUIRED')
 m=BytesParser(policy=policy.default).parsebytes(raw)
 seals=m.get_all('ARC-Seal',[]);ams=m.get_all('ARC-Message-Signature',[]);aars=m.get_all('ARC-Authentication-Results',[])
 require(0<len(seals)==len(ams)==len(aars)<=5,'ARC_CHAIN_LIMIT')
 seal=tags(seals[0]);signature=tags(ams[0]);index=str(len(seals))
 require(seal.get('i')==signature.get('i')==index,'ARC_ORDER')
 require(seal.get('d','').lower() in auth.get('trusted_arc_domains',[]) and signature.get('d','').lower()==seal['d'].lower(),'ARC_PROVIDER_UNTRUSTED')
 require('l' not in signature and signature.get('a') in ['rsa-sha256','ed25519-sha256'],'ARC_SIGNATURE_POLICY')
 # Gmail's ARC signature does not necessarily cover Content-Type. DMARC
 # does not require that header; MIME structure is validated separately.
 required={'from','to','subject'}|({'message-id'} if m.get('message-id') is not None else set())
 require(required<={k.strip().lower() for k in signature.get('h','').split(':')},'ARC_HEADERS_UNSIGNED')
 cache=auth.setdefault('_resolved_keys',{});saved=auth.get('_cached_keys');queries=0
 def dns(name,timeout=10):
  nonlocal queries
  queries+=1;require(queries<=30,'ARC_DNS_LIMIT');key=name.decode('ascii')
  if saved is not None:return base64.b64decode(saved[key],validate=True) if key in saved else None
  if key in cache:return base64.b64decode(cache[key],validate=True)
  value=dkim.get_txt(name,timeout=timeout)
  if value is not None:cache[key]=base64.b64encode(value).decode('ascii')
  return value
 try:result=dkim.arc_verify(raw,dnsfunc=dns)
 except Exception:raise Reject('ARC_AUTH_FAILED') from None
 require(result[0]==b'pass','ARC_AUTH_FAILED')
 provider=re.fullmatch(r'i='+index+r';\s*(.*)',str(aars[0]),re.S)
 selected=m.get_all('Authentication-Results',[])
 pos=auth.get('authentication_results_index')
 require(isinstance(pos,int) and 0<=pos<len(selected),'AUTH_PLACEMENT_UNVERIFIED')
 normalize=lambda s:re.sub(r'\s+',' ',s).strip()
 require(provider and normalize(provider.group(1))==normalize(str(selected[pos])),'AUTH_PROVIDER_MISMATCH')
