import shutil
"""Conversion must execute inside the systemd network/resource sandbox."""
import base64,html,io,re,subprocess,warnings,tempfile,time
from pathlib import Path
import html5lib
from PIL import Image,ImageOps
from pypdf import PdfReader,PdfWriter,Transformation
from weasyprint import HTML
from .validation import Reject,require

Image.MAX_IMAGE_PIXELS=25_000_000
warnings.simplefilter('error',Image.DecompressionBombWarning)
TAGS=set('p div span br strong b em i u s blockquote pre code ul ol li a table thead tbody tfoot tr td th h1 h2 h3 h4 hr img'.split())
CSS='''@page {size:A4 portrait;margin:10mm} body {font-family:"Noto Sans CJK JP";font-size:11pt;overflow-wrap:anywhere} img {max-width:100%;max-height:270mm} table {max-width:100%;border-collapse:collapse} td,th {padding:0} table {width:auto} * {box-sizing:border-box} pre {white-space:pre-wrap}'''

def image_data(kind,payload):
    try:
        with Image.open(io.BytesIO(payload)) as image:
            require(image.format in (['PNG'] if kind=='image/png' else ['JPEG','MPO']),'IMAGE_FORMAT')
            if image.format=='MPO':
                # JPEG MPF contains a primary photograph plus auxiliary images.
                require(1<=getattr(image,'n_frames',1)<=20,'IMAGE_SIZE')
                image.seek(0)
            else:
                require(getattr(image,'n_frames',1)==1,'IMAGE_ANIMATED')
            require(image.width*image.height<=25_000_000 and max(image.size)<=20000,'IMAGE_SIZE')
            image.load()
            image=ImageOps.exif_transpose(image)
            result=Image.new('RGB',image.size,'white')
            rgba=image.convert('RGBA')
            result.paste(rgba,mask=rgba.getchannel('A'))
            output=io.BytesIO();result.save(output,format='PNG')
            dpi=image.info.get('dpi',(200,200))
            if not isinstance(dpi,(tuple,list)) or len(dpi)!=2 or not all(isinstance(v,(int,float)) and 1<=v<=2400 for v in dpi):dpi=(200,200)
            return result,output.getvalue(),dpi
    except Reject:raise
    except Exception:raise Reject('IMAGE_INVALID') from None

def safe_style(value):
    """Preserve bounded print layout, never URLs, generated content or positioning."""
    import tinycss2
    from tinycss2.color3 import parse_color
    result=[]
    enums={'display':{'none','block','inline','inline-block','table','table-row','table-cell'},
           'visibility':{'visible','hidden','collapse'},'text-align':{'left','right','center','justify'},
           'vertical-align':{'top','middle','bottom','baseline'},'font-weight':{'normal','bold','bolder','lighter',*map(str,range(100,1000,100))},
           'font-style':{'normal','italic','oblique'},'text-decoration':{'none','underline','line-through'},
           'white-space':{'normal','pre-wrap','pre-line'},'border-collapse':{'collapse','separate'},
           'table-layout':{'auto','fixed'}}
    lengths={'width','height','max-width','max-height','font-size','line-height','letter-spacing',
             'margin','margin-top','margin-right','margin-bottom','margin-left',
             'padding','padding-top','padding-right','padding-bottom','padding-left','border-spacing','border-radius'}
    def length(token):
        if token=='auto':return True
        m=re.fullmatch(r'(\d+(?:\.\d+)?)(px|pt|mm|cm|em|rem|%)?',token)
        if not m:return False
        number=float(m[1]);unit=m[2]
        return number<={'px':720,'pt':540,'mm':190,'cm':19,'em':40,'rem':40,'%':100,None:3}[unit]
    for item in tinycss2.parse_declaration_list(value,skip_comments=True,skip_whitespace=True)[:100]:
        if item.type!='declaration':continue
        name=item.lower_name;text=tinycss2.serialize(item.value).strip().lower()
        # Reject escapes and all functions other than a color grammar parsed below.
        if len(text)>180 or any(c in text for c in ('\\','<','>','@')):continue
        ok=False
        if name in enums:ok=text in enums[name]
        elif name in lengths:ok=1<=len(text.split())<=4 and all(length(x) for x in text.split())
        elif name in ('color','background-color','background','border-color'):
            ok=parse_color(text) is not None
            if name=='background':name='background-color'
        elif name in ('border','border-top','border-right','border-bottom','border-left'):
            parts=text.split();ok=text in ('0','none') or (len(parts)==3 and length(parts[0]) and parts[1] in ('solid','dashed','dotted','double','none') and parse_color(parts[2]) is not None)
        if ok:result.append(name+':'+text+(' !important' if item.important else ''))
    return ';'.join(result)


def sanitized_body(doc):
    import tinycss2
    used=set();blobs={};notes=[]
    if not doc.html:return '<pre>'+html.escape(doc.body)+'</pre>',blobs,used,notes
    try:tree=html5lib.parse(doc.body,namespaceHTMLElements=False)
    except Exception:raise Reject('HTML_INVALID') from None
    rules=[]
    for node in tree.iter('style'):
        for rule in tinycss2.parse_stylesheet(node.text or '',skip_comments=True,skip_whitespace=True)[:200]:
            if rule.type!='qualified-rule':continue  # No imports, fonts, media or page rules.
            selector=tinycss2.serialize(rule.prelude).strip()
            if len(selector)>200 or not re.fullmatch(r'[a-zA-Z0-9_.*# ,>+~-]+',selector):continue
            style=safe_style(tinycss2.serialize(rule.content))
            if style:
                selectors=[]
                for part in selector.split(','):
                    part=part.strip()
                    if part in ('html','body'):selectors.append('#fax-mail-body')
                    elif part:selectors.append('#fax-mail-body '+part)
                if selectors:rules.append(','.join(selectors)+'{'+style+'}')
    def render(node,table_format=None):
        if not isinstance(node.tag,str):return ''  # Comments must never become visible text.
        tag=node.tag
        if tag in ['script','style','head','iframe','form','object','embed','link','meta','base','svg','math','template','title']:return ''
        style=safe_style(node.attrib.get('style',''))
        if 'hidden' in node.attrib or re.search(r'(?:^|;)display:none(?: !important)?(?:;|$)',style):return ''
        attributes=[];defaults=[]
        def dimension(value):
            return value if re.fullmatch(r'(?:100|[1-9]?\d)%',value) else (value+'px' if value.isdigit() and 0<=int(value)<=720 else '')
        for key in ('width','height'):
            value=dimension(node.attrib.get(key,''))
            if value:defaults.append(key+':'+value)
        align=node.attrib.get('align','').lower()
        if align in ('left','right','center','justify'):
            if tag=='table' and align=='center':defaults+=['margin-left:auto','margin-right:auto']
            else:defaults.append('text-align:'+align)
        valign=node.attrib.get('valign','').lower()
        if valign in ('top','middle','bottom','baseline'):defaults.append('vertical-align:'+valign)
        defaults.append(safe_style('background-color:'+node.attrib.get('bgcolor','')))
        if tag=='table':
            border=node.attrib.get('border','');padding=node.attrib.get('cellpadding','')
            table_format=(int(border) if border.isdigit() and int(border)<=10 else 0,
                          int(padding) if padding.isdigit() and int(padding)<=40 else 0)
            if table_format[0]:defaults.append('border:'+str(table_format[0])+'px solid #888')
        if tag in ('td','th') and table_format:
            defaults.append('padding:'+str(table_format[1])+'px')
            if table_format[0]:defaults.append('border:'+str(table_format[0])+'px solid #888')
        for key in ('colspan','rowspan'):
            value=node.attrib.get(key,'')
            if tag in ('td','th') and value.isdigit() and 1<=int(value)<=100:attributes.append(key+'="'+value+'"')
        for key in ('id','class'):
            value=node.attrib.get(key,'')
            if re.fullmatch(r'[a-zA-Z0-9_ -]{1,200}',value) and 'fax-mail-body' not in value:attributes.append(key+'="'+value+'"')
        if tag=='body':tag='div';attributes=['id="fax-mail-body"']
        styles=';'.join(x for x in [*defaults,style] if x)
        if styles:attributes.append('style="'+html.escape(styles,quote=True)+'"')
        if tag=='img':
            src=node.attrib.get('src','')
            if src.startswith('cid:'):
                cid=src[4:];require(cid in doc.images,'CID_MISSING')
                _,payload,_=image_data(*doc.images[cid])
                token='faxasset:'+str(len(blobs));blobs[token]=payload;used.add(cid)
                return '<img src="'+token+'" '+ ' '.join(attributes)+'>'
            notes.append('EXTERNAL_IMAGE_OMITTED')
            if node.attrib.get('width') in ('0','1') or node.attrib.get('height') in ('0','1'):return ''
            alt=node.attrib.get('alt','').strip()[:160]
            return '<span style="font-size:8pt;white-space:nowrap">'+html.escape('['+alt+']' if alt else '外部画像は省略')+'</span>'
        content=html.escape(node.text or '')
        for child in node:content+=render(child,table_format)+html.escape(child.tail or '')
        if tag=='html' or tag not in TAGS:return content
        if tag in ('br','hr'):return '<'+tag+' '+ ' '.join(attributes)+'>'
        return '<'+tag+' '+ ' '.join(attributes)+'>'+content+'</'+tag+'>'
    return ('<style>'+''.join(rules)+'</style>' if rules else '')+render(tree),blobs,used,notes


def render_html(text,blobs,paper='A4',fax_contrast=False):
    def fetch(url):
        if url not in blobs:raise Reject('RESOURCE_BLOCKED')
        return {'string':blobs[url],'mime_type':'image/png'}
    require(paper in ('A4','A3'),'PDF_GEOMETRY')
    css=CSS if paper=='A4' else CSS+' @page {size:A3 portrait} img {max-height:397mm}'
    if fax_contrast:
        css+=' #fax-mail-body, #fax-mail-body * {color:#000 !important;background-color:#fff !important;border-color:#000 !important} #fax-mail-body a {text-decoration:underline !important}'
    try:return HTML(string='<html><head><meta charset="utf-8"><style>'+css+'</style></head><body>'+text+'</body></html>',url_fetcher=fetch).write_pdf()
    except Reject:raise
    except Exception:raise Reject('HTML_RENDER_FAILED') from None

def read_pdf(payload):
    try:
        reader=PdfReader(io.BytesIO(payload),strict=True)
        require(not reader.is_encrypted,'PDF_ENCRYPTED')
        require(1<=len(reader.pages)<=20,'PAGE_LIMIT')
        for page in reader.pages:
            require(float(page.mediabox.width)>0 and float(page.mediabox.height)>0,'PDF_GEOMETRY')
        return reader
    except Reject:raise
    except Exception:raise Reject('PDF_INVALID') from None

def body_has_content(body):
    """Check rendered, sanitized content, not HTML markup or the first line."""
    tree=html5lib.parseFragment(body,namespaceHTMLElements=False)
    def visible_text(node):
        if not isinstance(node.tag,str) or node.tag in ('style','script'):return ''
        return (node.text or '')+''.join(visible_text(child)+(child.tail or '') for child in node)
    text=visible_text(tree)
    if text.strip():return True
    return any(node.tag in ['img','hr'] for node in tree.iter())


def pdf_paper(page):
    """Recognize ISO A3 within 2 mm, including landscape and PDF rotation.

    All other sizes retain the existing A4 fitting policy. This is called only
    for PDF attachments, never for the HTML body or image attachments.
    """
    unit=float(page.get('/UserUnit',1))
    width,height=sorted((float(page.cropbox.width)*unit,float(page.cropbox.height)*unit))
    return 'A3' if abs(width-841.89)<5.67 and abs(height-1190.551)<5.67 else 'A4'


def convert(doc,directory):
    directory=Path(directory)
    directory.mkdir(parents=True,exist_ok=True)
    body,blobs,used,notes=sanitized_body(doc)
    parts=[]
    if body_has_content(body):parts.append((render_html(body,blobs,fax_contrast=True),False))
    attachments=[item[:2] for item in doc.attachments if len(item)==2 or item[2] not in used]
    require(len(attachments)<=20,'ATTACHMENT_COUNT')
    for kind,payload in attachments:
        if kind=='application/pdf':read_pdf(payload);parts.append((payload,True))
        else:
            image,data,dpi=image_data(kind,payload)
            with Image.open(io.BytesIO(payload)) as source_image:
                if source_image.format=='MPO':notes.append('MPO_PRIMARY_IMAGE_USED')
            # Physical DPI placement, no enlargement beyond original dimensions.
            width=min(190,image.width/dpi[0]*25.4)
            height=image.height/dpi[1]*25.4
            if height>277:width*=277/height
            parts.append((render_html('<img style="width:'+str(width)+'mm" src="faxasset:image">',{'faxasset:image':data}),False))
    require(parts,'EMPTY_MESSAGE')
    writer=PdfWriter()
    papers=[]
    for payload,is_attachment_pdf in parts:
        reader=read_pdf(payload)
        require(len(writer.pages)+len(reader.pages)<=20,'PAGE_LIMIT')
        for page in reader.pages:
            paper=pdf_paper(page) if is_attachment_pdf else 'A4'
            papers.append(paper)
            page.transfer_rotation_to_content()
            # A fax scans the short edge; rotate landscape pages without shrinking.
            if is_attachment_pdf and page.cropbox.width>page.cropbox.height:
                page.rotate(90);page.transfer_rotation_to_content()
            width,height=float(page.cropbox.width),float(page.cropbox.height)
            target_width,target_height=(841.89,1190.551) if paper=='A3' else (595.276,841.89)
            scale=min(target_width/width,target_height/height)
            blank=writer.add_blank_page(width=target_width,height=target_height)
            transform=Transformation().translate(-float(page.cropbox.left),-float(page.cropbox.bottom)).scale(scale).translate((target_width-width*scale)/2,(target_height-height*scale)/2)
            blank.merge_transformed_page(page,transform)
    pdf=directory/'document.pdf';tiff=directory/'document.tif'
    with pdf.open('wb') as stream:writer.write(stream)
    try:
        # Group adjacent pages so the A4 path still needs only one gs process.
        # Ghostscript's automatic fax-width adjustment does not support A3.
        deadline=time.monotonic()+110
        # Ubuntu26 confines Ghostscript to owner-accessible temporary files.
        # PrivateTmp=yes isolates these files in production and installer tests.
        with tempfile.TemporaryDirectory(prefix='fax-raster-',dir='/tmp') as temporary:
            raster_pdf=Path(temporary)/'document.pdf'
            shutil.copyfile(pdf,raster_pdf)
            groups=[];start=0
            while start<len(papers):
                end=start+1
                while end<len(papers) and papers[end]==papers[start]:end+=1
                output=Path(temporary)/(str(start)+'.tif');groups.append(output)
                geometry='2432x3241' if papers[start]=='A3' else '1728x2292'
                command=['gs','-q','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=tiffg3','-r204x196','-g'+geometry,'-dFIXEDMEDIA','-dPDFFitPage','-dFirstPage='+str(start+1),'-dLastPage='+str(end),'-sOutputFile='+str(output),str(raster_pdf)]
                result=subprocess.run(command,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=max(0.1,deadline-time.monotonic()))
                require(result.returncode==0,'RASTER_FAILED');start=end
            if len(groups)==1:shutil.copyfile(groups[0],tiff)
            else:
                result=subprocess.run(['tiffcp']+[str(p) for p in groups]+[str(tiff)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=max(0.1,deadline-time.monotonic()))
                require(result.returncode==0,'RASTER_FAILED')
        with Image.open(tiff) as image:
            require(image.n_frames==len(writer.pages),'TIFF_PAGE_MISMATCH')
            for index in range(image.n_frames):
                image.seek(index)
                require(image.width==(2432 if papers[index]=='A3' else 1728) and image.mode=='1','TIFF_FORMAT')
                require(image.tag_v2.get(259)==3,'TIFF_COMPRESSION')
                require(abs(float(image.tag_v2[282])-204)<1 and abs(float(image.tag_v2[283])-196)<1,'TIFF_RESOLUTION')
        require(sum(p.stat().st_size for p in directory.iterdir() if p.is_file())<=512*1024**2,'WORKSPACE_SIZE')
        return len(writer.pages),sorted(set(notes))
    except Reject:raise
    except Exception:raise Reject('RASTER_FAILED') from None

def receive_pdf(source,destination):
    try:
        images=[]
        with Image.open(source) as source_image:
            require(1<=source_image.n_frames<=20,'PAGE_LIMIT')
            for i in range(source_image.n_frames):
                source_image.seek(i)
                require(source_image.mode=='1','TIFF_FORMAT')
                xdpi=float(source_image.tag_v2.get(282,204));ydpi=float(source_image.tag_v2.get(283,196))
                require(xdpi>0 and ydpi>0,'TIFF_RESOLUTION')
                images.append((source_image.convert('RGB'),xdpi,ydpi))
        # FAX fine resolution has unequal horizontal/vertical DPI.
        pages=[]
        for image,xdpi,ydpi in images:
            data=io.BytesIO();image.save(data,format='PNG')
            width,height=image.width/xdpi*25.4,image.height/ydpi*25.4
            # The sender's original MIME type is not transmitted over fax.
            # Identify the A3 scan width independently of standard/fine DPI.
            paper='A3' if 290<=width<=310 else 'A4'
            max_width,max_height=(277,397) if paper=='A3' else (190,277)
            scale=min(max_width/width,max_height/height,1)
            pages.append(render_html('<img style="width:'+str(width*scale)+'mm;height:'+str(height*scale)+'mm" src="faxasset:image">',{'faxasset:image':data.getvalue()},paper))
        writer=PdfWriter()
        for page in pages:writer.append(io.BytesIO(page))
        with Path(destination).open('wb') as stream:writer.write(stream)
        require(len(writer.pages)==len(images),'RECEIVE_PAGE_MISMATCH')
        return len(images)
    except Reject:raise
    except Exception:raise Reject('RECEIVE_CONVERSION_FAILED') from None
