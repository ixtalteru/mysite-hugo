"""Explicit database restore always fences dispatch and requires a new baseline."""
import json,os,shutil,sqlite3,subprocess,time,uuid
from pathlib import Path
from . import control
from .validation import require

def restore(directory):
 require(os.geteuid()==0,'ROOT_REQUIRED')
 source=Path(directory)
 require(source.parent==Path('/var/lib/faxmail-backups') and str(uuid.UUID(source.name))==source.name and not source.is_symlink(),'BACKUP_PATH')
 require(time.time()<float((source/'created').read_text())+168*3600,'BACKUP_EXPIRED')
 p=source/'jobs.sqlite';require(p.is_file() and not p.is_symlink(),'BACKUP_INVALID')
 require(subprocess.run(['systemctl','stop','faxmail-next','faxmail-dispatch','faxmail-receive-mail.timer','faxmail-receive-mail.service','faxmail-cleanup.timer','faxmail-cleanup.service'],capture_output=True).returncode==0,'STOP_FAILED')
 control.pause()
 import pwd
 user=pwd.getpwnam('faxmail');target=control.STATE/'jobs.sqlite'
 for suffix in ['-wal','-shm']:Path(str(target)+suffix).unlink(missing_ok=True)
 src=sqlite3.connect('file:'+str(p)+'?mode=ro',uri=True);dst=sqlite3.connect(target)
 try:src.backup(dst)
 finally:src.close();dst.close()
 os.chown(target,user.pw_uid,user.pw_gid);target.chmod(0o600)
 marker=control.STATE/'restore-review-required';marker.touch(mode=0o600);os.chown(marker,user.pw_uid,user.pw_gid)
 print('database_restored_paused: OK')
