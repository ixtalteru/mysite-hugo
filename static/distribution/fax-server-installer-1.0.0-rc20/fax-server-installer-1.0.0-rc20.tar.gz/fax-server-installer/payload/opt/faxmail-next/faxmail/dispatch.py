"""Call-file staging. Reservation is never retried after an ambiguous crash."""
import json,os,time,uuid,errno
from pathlib import Path
from .validation import require,validate_number

def sync_directory(path):
    descriptor=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(descriptor)
    finally:os.close(descriptor)

def callfile(job,number,tiff):
    require(str(uuid.UUID(job))==job,'JOB_INVALID')
    require(number.isascii() and number.isdigit() and number.startswith('0'),'NUMBER_INVALID')
    require(Path(tiff).is_absolute() and not any(c in str(tiff) for c in '\r\n,'),'PATH_INVALID')
    return ('Channel: Local/'+number+'@fax-dial/n\nMaxRetries: 0\nRetryTime: 60\nWaitTime: 60\n'
            'Context: fax-send\nExtension: s\nPriority: 1\nSetvar: __FAX_JOB='+job+'\nArchive: yes\n')

def stage(request,config,staging,outgoing,receipts,source_root='/var/spool/faxmail-next/jobs',mode='test'):
    job=request['job'];require(str(uuid.UUID(job))==job,'JOB_INVALID')
    require(mode in ['test','production'],'MODE_INVALID')
    number=validate_number(request['number'],config,mode)
    tiff=Path(source_root)/job/'document.tif'
    require(tiff.is_file() and not tiff.is_symlink() and not tiff.parent.is_symlink(),'TIFF_MISSING')
    require(request['expires']>time.time(),'JOB_EXPIRED')
    receipt=Path(receipts)/job
    try:
        fd=os.open(receipt,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError:return False
    with os.fdopen(fd,'w') as stream:
        stream.write('RESERVED');stream.flush();os.fsync(stream.fileno())
    # Persist the directory entry too: fsync(file) alone does not ensure a
    # newly created receipt survives a power loss before call publication.
    sync_directory(receipts)
    # A crash from here onward is UNKNOWN, never a reason to call again.
    require(Path(staging).stat().st_dev==Path(outgoing).stat().st_dev,'SPOOL_FILESYSTEM')
    temp=Path(staging)/(job+'.call')
    with temp.open('x',encoding='ascii') as stream:
        # The setgid staging directory supplies the Asterisk group. UMask=0077
        # otherwise prevents Asterisk from reading/updating the call file.
        os.fchmod(stream.fileno(),0o660)
        stream.write(callfile(job,number,tiff));stream.flush();os.fsync(stream.fileno())
    sync_directory(staging)
    try:os.replace(temp,Path(outgoing)/(job+'.call'))
    except OSError as error:
        # These local rename errors establish that publication did not occur.
        # Preserve the reservation: a failed job must never auto-redial.
        if error.errno in [errno.EXDEV,errno.EACCES,errno.EPERM,errno.EROFS] and temp.exists() and not (Path(outgoing)/(job+'.call')).exists():
            with receipt.open('w') as stream:
                stream.write('FAILED_PREPUBLICATION');stream.flush();os.fsync(stream.fileno())
        raise
    sync_directory(outgoing)
    return True

def check_dispatch_policy(config,authorization,reservation_count):
    mode=authorization.get('mode')
    require(mode in ['test','production'],'MODE_INVALID')
    if mode=='test':
        limit=authorization.get('max_calls',0)
        require(0<limit<=config['permissions']['max_test_outbound_calls'],'TEST_LIMIT_INVALID')
        require(reservation_count<limit,'TEST_LIMIT_REACHED')
    return mode

def run(config):
    import fcntl,subprocess
    from .worker import gate
    from . import control
    receipts=Path('/var/lib/faxdispatch')
    lock=(receipts/'lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    while True:
        if control.paused() or not control.disk_ok():time.sleep(5);continue
        authorization=gate()
        mode=authorization['mode']
        require(mode in ['test','production'],'MODE_INVALID')
        args=['asterisk']
        if config['fax'].get('asterisk_config'):args+=['-C',config['fax']['asterisk_config']]
        active=subprocess.run(args+['-rx','core show channels count'],capture_output=True,text=True)
        if active.returncode==0 and '0 active channels' in active.stdout:
            outgoing=config['fax'].get('outgoing_spool','/var/spool/asterisk/outgoing')
            staging=config['fax'].get('staging_spool','/var/spool/asterisk/fax-staging')
            queued=list(Path(outgoing).glob('*.call'))
            if not queued:
                for path in sorted(Path('/var/spool/faxmail-next/requests').glob('*.json')):
                    if path.is_symlink() or path.stat().st_size>4096:continue
                    request=json.loads(path.read_text())
                    require(path.stem==request['job'],'JOB_INVALID')
                    if request.get('expires',0)<=time.time():continue
                    count=len(list(receipts.glob('????????-????-????-????-????????????'))) if mode=='test' else 0
                    check_dispatch_policy(config,authorization,count)
                    with control.admission_lock():
                        if control.paused() or not control.disk_ok():break
                        if stage(request,config,staging,outgoing,receipts,mode=mode):break
        time.sleep(5)
