"""Fail-closed MIME validation. Errors carry fixed codes only."""
import re
from email import policy
from email.parser import BytesParser
from email.utils import getaddresses
from dataclasses import dataclass

class Reject(Exception):
    pass

def require(value, code):
    if not value:
        raise Reject(code)

def canonical(address):
    require(isinstance(address, str) and address.count('@') == 1, 'ADDRESS_INVALID')
    local, domain = address.rsplit('@', 1)
    require(local and domain and not any(c.isspace() for c in address), 'ADDRESS_INVALID')
    return local + '@' + domain.lower()

def one_address(message, name):
    values = message.get_all(name, [])
    require(len(values) == 1, 'HEADER_COUNT')
    header = message[name]
    require(not getattr(header, 'defects', ()), 'ADDRESS_INVALID')
    require(not any(g.display_name is not None for g in getattr(header, 'groups', ())), 'ADDRESS_GROUP')
    addresses = getaddresses([str(values[0])])
    require(len(addresses) == 1, 'ADDRESS_COUNT')
    return canonical(addresses[0][1])

def validate_number(number, config, mode='dry-run'):
    require(isinstance(number, str) and re.fullmatch(r'0[0-9]{9,10}', number), 'NUMBER_SYNTAX')
    fax = config['fax']
    blocked = ['00', '010', *fax.get('blocked_prefixes', [])]
    allowed = fax.get('allowed_domestic_prefixes', [])
    require(allowed and any(number.startswith(p) for p in allowed), 'NUMBER_NOT_ALLOWED')
    require(not any(number.startswith(p) for p in blocked), 'NUMBER_BLOCKED')
    if mode == 'test':
        require(number in config['permissions'].get('test_destination_numbers', []), 'TEST_DESTINATION')
    return number

def authentication(message, config, sender, raw=None):
    auth = config['mail']['authentication']
    if auth.get('mechanism')=='aligned_dkim':
        from .signed_mail import verify_signed_mail
        auth['_resolved_keys']={}
        verify_signed_mail(raw,sender,key_cache=auth['_resolved_keys'],cached_keys=auth.get('_cached_keys'))
        return
    if auth.get('mechanism')=='provider_dmarc_arc':
        from .provider_auth import verify
        auth['_resolved_keys']={}
        verify(raw,auth)
    require(auth.get('trust_boundary_verified') is True, 'AUTH_BOUNDARY_UNVERIFIED')
    ids = auth.get('trusted_authserv_ids', [])
    require(ids, 'AUTH_TRUST_EMPTY')
    # Deployment must additionally confirm this exact placement using a real
    # provider-delivered message. It is not inferred from the header itself.
    require(auth.get('placement_verified') is True, 'AUTH_PLACEMENT_UNVERIFIED')
    index = auth.get('authentication_results_index')
    require(isinstance(index, int) and index >= 0, 'AUTH_PLACEMENT_UNVERIFIED')
    headers = message.get_all('Authentication-Results', [])
    require(index < len(headers), 'AUTH_MISSING')
    text = strip_auth_comments(str(headers[index]))
    parts = text.split(';')
    require(parts[0].strip() in ids, 'AUTH_SERVER_UNTRUSTED')
    # Only the DMARC method's own property is accepted; comments/duplicate
    # methods/ambiguous syntax fail closed instead of broad regex matching.
    methods = [p.strip() for p in parts[1:] if re.match(r'^dmarc\s*=', p.strip(), re.I)]
    require(len(methods) == 1, 'AUTH_DMARC_MISSING')
    result = re.fullmatch(r'dmarc\s*=\s*pass\s+header\.from=([A-Za-z0-9.-]+)', methods[0], re.I)
    require(result and result.group(1).lower() == sender.rsplit('@', 1)[1], 'AUTH_DMARC_FAIL')

def strip_auth_comments(text):
    # RFC 8601 CFWS: parentheses may nest and quoted-pairs escape delimiters.
    output=[];depth=0;escaped=False;quoted=False
    for char in text:
        if escaped:
            if not depth:output.append(char)
            escaped=False;continue
        if char=='\\':
            require(depth or quoted,'AUTH_SYNTAX');escaped=True
            if not depth:output.append(char)
        elif char=='"' and not depth:
            quoted=not quoted;output.append(char)
        elif char=='(' and not quoted:
            if not depth:output.append(' ')
            depth+=1;require(depth<=20,'AUTH_SYNTAX')
        elif char==')' and not quoted:
            require(depth>0,'AUTH_SYNTAX');depth-=1
        elif not depth:output.append(char)
    require(not depth and not escaped and not quoted,'AUTH_SYNTAX')
    return ''.join(output)

@dataclass
class Document:
    sender: str
    number: str
    message_id: str | None
    body: str
    html: bool
    images: dict
    attachments: list

def parse(raw, config, mode='dry-run'):
    require(len(raw) <= 25*1024*1024, 'MAIL_SIZE')
    message = BytesParser(policy=policy.default).parsebytes(raw)
    require(not message.defects, 'MIME_INVALID')
    sender = one_address(message, 'From')
    require(sender in [canonical(s) for s in config['mail']['allowed_senders']], 'SENDER_NOT_ALLOWED')
    require(one_address(message, 'To') == canonical(config['mail']['fax_address']), 'TO_NOT_ALLOWED')
    for name in ['Cc', 'Bcc']:
        require(not any(str(v).strip() for v in message.get_all(name, [])), 'EXTRA_RECIPIENT')
    require(not any(k.lower().startswith('resent-') for k in message.keys()), 'RESENT_REJECTED')
    require(not message.get_all('Sender'), 'SENDER_HEADER_REJECTED')
    for name in ['Subject', 'Message-ID', 'Auto-Submitted', 'Content-Type', 'Content-Transfer-Encoding', 'MIME-Version']:
        require(len(message.get_all(name, [])) <= 1, 'HEADER_DUPLICATE')
    require(str(message.get('Auto-Submitted', 'no')).lower() == 'no', 'AUTOMATIC_MESSAGE')
    require(message.get_content_type() not in ['multipart/report','message/delivery-status'], 'AUTOMATIC_MESSAGE')
    authentication(message, config, sender, raw)
    number = validate_number(str(message.get('Subject', '')).strip(' \t\r\n'), config, mode)
    msgid = str(message.get('Message-ID', '')).strip() or None
    require(msgid is None or re.fullmatch(r'<[^<>\s\r\n]+@[^<>\s\r\n]+>', msgid), 'MESSAGE_ID_INVALID')
    parts = []
    def visit(part, depth=0):
        require(depth <= 20 and len(parts) < 100, 'MIME_LIMIT')
        require(not part.defects, 'MIME_INVALID')
        require(len(part.get_all('Content-ID', [])) <= 1, 'CID_DUPLICATE')
        parts.append(part)
        require(part.get_content_maintype() != 'message', 'ATTACHMENT_UNSUPPORTED')
        if part.is_multipart():
            require(part.get_content_subtype() in ['mixed','alternative','related'], 'MIME_MULTIPART_UNSUPPORTED')
            for child in part.iter_parts(): visit(child, depth+1)
    visit(message)
    bodypart = message.get_body(preferencelist=('html','plain'))
    body = ''
    if bodypart:
        require(len(bodypart.get_payload(decode=True) or b'') <= 1024*1024, 'BODY_SIZE')
        try: body = bodypart.get_content()
        except Exception: raise Reject('BODY_ENCODING') from None
    related = {}
    body_ancestors=[]
    if bodypart:
        # Find the nearest enclosing related container; never resolve CID
        # across unrelated MIME branches.
        def ancestors(part, target, path=()):
            if part is target: return path
            if part.is_multipart():
                for child in part.iter_parts():
                    found = ancestors(child, target, path+(part,))
                    if found is not None: return found
        body_ancestors=list(ancestors(message,bodypart) or ())
        enclosing = [p for p in body_ancestors if p.get_content_type()=='multipart/related']
        if enclosing:
            for part in enclosing[-1].walk():
                cid = str(part.get('Content-ID','')).strip('<> ')
                if cid:
                    require(cid not in related, 'CID_DUPLICATE')
                    related[cid] = part
    # Preserve the displayed sequence of flat mobile mixed text/inline images.
    mixed_body_parts=[];mixed_images={};mixed_html=False
    if message.get_content_type()=='multipart/mixed':
        children=list(message.iter_parts())
        if (all(not p.is_multipart() for p in children)
            and any(p.get_content_type() in ['image/jpeg','image/png'] and p.get_content_disposition()=='inline' for p in children)
            and bodypart is not None and bodypart.get_content_type()=='text/plain'):
            import html
            mixed_body_parts=[p for p in children if p.get_content_type()=='text/plain' and p.get_content_disposition()!='attachment']
            require(sum(len(p.get_payload(decode=True) or b'') for p in mixed_body_parts)<=1024*1024,'BODY_SIZE')
            fragments=[]
            for i,p in enumerate(children):
                if p in mixed_body_parts:
                    try:text=p.get_content()
                    except Exception:raise Reject('BODY_ENCODING') from None
                    fragments.append('<pre>'+html.escape(text)+'</pre>')
                elif p.get_content_type() in ['image/jpeg','image/png'] and p.get_content_disposition()=='inline':
                    cid='mobile-part-'+str(i)
                    mixed_images[id(p)]=cid
                    fragments.append('<div><img src="cid:'+cid+'"></div>')
            body=''.join(fragments);mixed_html=True
    attachments=[]; total=0; images={}
    for part in parts:
        if part.is_multipart(): continue
        kind=part.get_content_type()
        payload=part.get_payload(decode=True) or b''
        require(not part.defects, 'MIME_INVALID')
        total += len(payload)
        require(total <= 20*1024*1024+1024*1024, 'DECODED_SIZE')
        if part is bodypart or part in mixed_body_parts: continue
        if id(part) in mixed_images:
            cid=mixed_images[id(part)];images[cid]=(kind,payload)
            attachments.append((kind,payload,cid));continue
        cid=str(part.get('Content-ID','')).strip('<> ')
        if cid and related.get(cid) is part:
            require(kind in ['image/jpeg','image/png'], 'CID_TYPE')
            images[cid]=(kind,payload)
            attachments.append((kind,payload,cid))
            continue
        # Some mobile clients append a CRLF-only MIME part after an image.
        if kind=='text/plain' and part.get_content_disposition()!='attachment':
            try:empty_plain=not payload.decode(part.get_content_charset() or 'ascii',errors='strict').strip()
            except (UnicodeError,LookupError):empty_plain=False
            if empty_plain:continue
        # An alternative text part is omitted only if it is not an attachment.
        if kind in ['text/plain','text/html'] and part.get_content_disposition()!='attachment':
            require(any(parent.get_content_type()=='multipart/alternative' and part in list(parent.walk()) for parent in body_ancestors),'AMBIGUOUS_BODY_PART')
            continue
        require(kind in ['application/pdf','image/jpeg','image/png'], 'ATTACHMENT_UNSUPPORTED')
        attachments.append((kind,payload))
    require(len(attachments)<=20, 'ATTACHMENT_COUNT')
    require(body.strip() or attachments, 'EMPTY_MESSAGE')
    return Document(sender,number,msgid,body,bool(mixed_html or (bodypart and bodypart.get_content_type()=='text/html')),images,attachments)
