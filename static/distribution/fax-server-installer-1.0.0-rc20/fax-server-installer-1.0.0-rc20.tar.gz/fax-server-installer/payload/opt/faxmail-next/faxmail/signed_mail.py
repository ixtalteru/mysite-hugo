"""Verify original bytes with aligned DKIM; never trust a claimed verdict."""
import re,base64
from email import policy
from email.parser import BytesParser
from .validation import require,Reject

def verify_signed_mail(raw,sender,dnsfunc=None,key_cache=None,cached_keys=None):
    import dkim
    require(isinstance(raw,bytes),'SIGNED_MESSAGE_REQUIRED')
    message=BytesParser(policy=policy.default).parsebytes(raw)
    signatures=message.get_all('DKIM-Signature',[])
    require(0<len(signatures)<=8,'DKIM_SIGNATURE_COUNT')
    domain=sender.rsplit('@',1)[1].lower()
    required={'from','to','subject'}
    if message.get('Message-ID') is not None:required.add('message-id')
    required.update(k for k in ['content-type','content-transfer-encoding','mime-version'] if message.get(k) is not None)
    for idx,signature in enumerate(signatures):
        tags={};valid=True
        for item in str(signature).split(';'):
            if not item.strip():continue
            key,sep,value=item.strip().partition('=')
            if not sep or key in tags:valid=False;break
            tags[key]=value.strip()
        if not valid or tags.get('d','').lower()!=domain or 'l' in tags:continue
        if tags.get('a') not in ['rsa-sha256','ed25519-sha256']:continue
        covered={v.strip().lower() for v in tags.get('h','').split(':')}
        if not required<=covered:continue
        try:
            def lookup(name,timeout=10):
                key=name.decode('ascii')
                if cached_keys is not None:
                    encoded=cached_keys.get(key)
                    return base64.b64decode(encoded,validate=True) if encoded else None
                result=(dnsfunc or dkim.get_txt)(name,timeout=timeout)
                if key_cache is not None and result is not None:key_cache[key]=base64.b64encode(result).decode('ascii')
                return result
            kwargs={'dnsfunc':lookup}
            if dkim.DKIM(raw,timeout=10).verify(idx=idx,**kwargs):return
        except Exception:continue
    raise Reject('DKIM_AUTH_FAILED')
