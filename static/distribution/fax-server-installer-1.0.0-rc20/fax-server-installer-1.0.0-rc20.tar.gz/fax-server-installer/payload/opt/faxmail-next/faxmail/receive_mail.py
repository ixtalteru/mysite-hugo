"""Receive-only mail forwarding; never ingest mail or dispatch a FAX."""
import json,os
from pathlib import Path
from .store import Store
from .validation import require
from .worker import receive_once

GATE=Path('/etc/faxmail-next/receive-mail-approved.json')
CONFIG=Path('/etc/faxmail-next/site-mail.json')
STATE=Path('/var/lib/faxmail-next')

def run():
    require(GATE.is_file() and not GATE.is_symlink(),'RECEIVE_MAIL_AUTHORIZATION_REQUIRED')
    st=GATE.stat()
    require(st.st_uid==0 and not st.st_mode&0o022,'AUTHORIZATION_PERMISSIONS')
    authorization=json.loads(GATE.read_text())
    require(authorization.get('receive_mail_send') is True and authorization.get('fax_send') is False,'RECEIVE_ONLY_REQUIRED')
    config=json.loads(CONFIG.read_text())
    recipients=config['mail']['receive_recipients']
    require(isinstance(recipients,list) and len(recipients)>0,'RECIPIENTS_MISSING')
    require(recipients==authorization.get('recipients'),'RECIPIENTS_CHANGED')
    require((STATE/'jobs.sqlite').is_file(),'DATABASE_MISSING')
    store=Store(STATE/'jobs.sqlite',(STATE/'dedupe.key').read_bytes())
    # This module is a single systemd oneshot; an old SENDING row is a crash.
    store.db.execute("UPDATE received_mail SET state='DELIVERY_UNKNOWN' WHERE state='SENDING'")
    try:receive_once(config,store,{'mail_send':True,'fax_send':False})
    finally:store.db.close()

if __name__=='__main__':run()
