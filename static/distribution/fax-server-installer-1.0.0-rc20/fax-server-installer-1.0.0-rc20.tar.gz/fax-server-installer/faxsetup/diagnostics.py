"""Stage-aware failure reports with credential redaction and root-only storage."""
import json,re,time,traceback,uuid
from pathlib import Path
from .model import Failure
from . import host as h

current_stage='導入開始前の検査'
private_values=set()

def collect(value,key=''):
    if isinstance(value,dict):
        for k,v in value.items():collect(v,k)
    elif isinstance(value,list):
        for v in value:collect(v,key)
    elif isinstance(value,str) and value and (key in ('auth_username','user_id','phone_number','fax_address','username','email','user','allowed_senders','receive_recipients') or 'password' in key):
        private_values.add(value)
        private_values.add(json.dumps(value,ensure_ascii=True)[1:-1])

def begin(values):
    private_values.clear();collect(values)
    stage('導入開始前の検査')

def redact(value):
    value=str(value)
    for secret in sorted(private_values,key=len,reverse=True):value=value.replace(secret,'<非表示>')
    value=re.sub(r'[A-Za-z0-9.!#$%&\x27*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+','<メールアドレス非表示>',value)
    return ''.join(c if c in '\n\t' or ord(c)>=32 else '?' for c in value)

def stage(name):
    global current_stage
    current_stage=name
    print('実行工程: '+name,flush=True)

def reason(error):
    if isinstance(error,Failure):return redact(str(error))
    if isinstance(error,(KeyboardInterrupt,EOFError)):return '利用者が処理を中断しました。'
    if isinstance(error,OSError):return type(error).__name__+'（OSエラー番号 '+str(error.errno)+'）。ファイル権限・空き容量・パスを確認してください。'
    return type(error).__name__+' が発生しました。詳細ログの発生箇所を確認してください。'

def record(error):
    if getattr(error,'fax_recorded',False):return
    error.fax_recorded=True
    report={'time':time.strftime('%Y-%m-%d %H:%M:%S %z'),'stage':current_stage,'reason':reason(error),'error_type':type(error).__name__,'exit_code':getattr(error,'code',5)}
    if getattr(error,'command',None):report['command']=error.command
    if getattr(error,'returncode',None) is not None:report['command_exit_code']=error.returncode
    if getattr(error,'details',None):report['details']=redact(error.details)[-16000:]
    report['locations']=[{'file':Path(f.filename).name,'line':f.lineno,'function':f.name} for f in traceback.extract_tb(error.__traceback__)]
    if getattr(error,'cleanup_errors',None):report['cleanup_errors']=error.cleanup_errors
    log=None
    try:
        folder=h.mkdir(h.STATE/'errors');log=folder/(time.strftime('%Y%m%d-%H%M%S')+'-'+str(uuid.uuid4())+'.json')
        h.write_json(log,report)
        old=h.state();status='FAILED' if old['status'] in ('INSTALLING','FAILED','CONFIGURING') else old['status']
        h.set_state(status,reason=report['reason'],failed_stage=report['stage'],error_log=str(log),last_failure=report)
    except Exception:
        print('失敗記録を保存できませんでした。下の理由を控えてください。',flush=True)
    print('失敗した工程: '+report['stage']+'\n失敗理由: '+report['reason'],flush=True)
    if log:print('詳細ログ（root限定）: '+str(log),flush=True)
