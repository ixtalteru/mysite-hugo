#!/usr/bin/env python3
import argparse,json,os,sys
from pathlib import Path
if __package__ in (None,''):
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from faxsetup import host as h,deploy,firewall,wizard
from faxsetup.model import Failure,require,inputs,BUNDLE

def parser():
    p=argparse.ArgumentParser(description='FAXサーバー導入・管理（日本語 / STAGED既定）')
    p.add_argument('command',nargs='?',default='menu',choices=['menu','install','sip','mail','users','diagnose','backup','restore','repair','activate','connection','firewall','firewall-confirm','firewall-rollback','firewall-boot','firewall-check','check-bundle'])
    p.add_argument('--config');p.add_argument('--secrets-file');p.add_argument('--users-config');p.add_argument('--firewall-config')
    p.add_argument('--plan',action='store_true',help='ファイル・OSを変更せず導入計画を表示')
    p.add_argument('--verify',action='store_true',help='外部接続なしの配置診断')
    p.add_argument('--activate',action='store_true');p.add_argument('--source-quiesced',action='store_true')
    p.add_argument('--accept-unvalidated-platform',action='store_true',help='実機受入前のOSプロファイルを検証環境で使用')
    p.add_argument('--allow-public-ssh',action='store_true');p.add_argument('--trial');p.add_argument('--directory')
    p.add_argument('--kind',choices=['imap','smtp']);p.add_argument('--recipient');p.add_argument('--send-one',action='store_true')
    return p

def main(argv=None):
    args=parser().parse_args(argv)
    require(not args.plan or args.command in ('install','firewall'),'--planはinstall/firewall専用です。')
    require(not args.activate or args.command=='install','--activateはinstall専用です。')
    require(not args.send_one or args.command=='connection','--send-oneはconnection専用です。')
    require(not args.source_quiesced or args.command in ('install','activate'),'--source-quiescedは本番切替専用です。')
    if args.command=='check-bundle':deploy.bundle_check();print('配布物hash: PASS');return 0
    if args.activate:require(args.source_quiesced,'--activateには--source-quiescedが必要です。')
    if args.verify or args.command=='diagnose':h.root_required();return deploy.diagnose()
    if args.command=='install' and args.config:
        require(args.secrets_file,'--secrets-fileが必要です。')
        secrets=h.read_json(args.secrets_file) if args.plan else h.read_secret(args.secrets_file)
        fw=h.read_json(args.firewall_config) if args.firewall_config else None
        if fw is None and not args.plan and (h.ADMIN/'firewall.json').exists():fw=h.read_json(h.ADMIN/'firewall.json')
        people=h.read_json(args.users_config) if args.users_config else None
        values=inputs(h.read_json(args.config),secrets,fw,people,public=args.allow_public_ssh)
        print(json.dumps(deploy.plan(*values),ensure_ascii=False,indent=2))
        if args.plan:return 0
        with h.locked():
            result=deploy.install(*values,experimental=args.accept_unvalidated_platform)
        if args.activate:
            print('初回rebaselineで既存受信箱までの依頼を処理対象外にします。')
            return deploy.activate_managed(args.source_quiesced)
        return result
    if args.command in ('install','sip','mail','users'):
        require(not args.plan,'--planには--configと--secrets-fileが必要です。')
        require(sys.stdin.isatty(),'引数なしの実行には対話端末が必要です。--helpを参照してください。')
        return wizard.menu() if args.command=='install' else wizard.configure(args.command)
    if args.command=='menu':h.root_required();return wizard.menu()
    if args.command=='firewall' and args.plan:
        from faxsetup.model import firewall as validate
        fw=h.read_json(args.config) if args.config else h.read_json(h.ADMIN/'firewall.json')
        print(firewall.rules(validate(fw,args.allow_public_ssh)));return 0
    h.root_required()
    if args.command=='firewall-check':return firewall.check()
    if args.command=='activate':return deploy.activate_managed(args.source_quiesced)
    if args.command=='connection':
        require(args.kind,'--kind imap|smtpが必要です。')
        require(not args.send_one or args.recipient,'実送信には--recipientが必要です。')
        return deploy.connection(args.kind,args.recipient,args.send_one)
    with h.locked():
        if args.command=='backup':return deploy.backup()
        if args.command=='restore':require(args.directory,'--directoryが必要です。');return deploy.restore(args.directory)
        if args.command=='repair':
            require(args.accept_unvalidated_platform,'RC版の修復には--accept-unvalidated-platformが必要です。')
            values=wizard.load();return deploy.install(*inputs(*values,public=True),experimental=True,repair=True)
        if args.command=='firewall':
            fw=h.read_json(args.config) if args.config else h.read_json(h.ADMIN/'firewall.json')
            print(json.dumps(fw,ensure_ascii=False,indent=2))
            return firewall.trial(fw,args.allow_public_ssh)
        if args.command=='firewall-confirm':require(args.trial,'--trialが必要です。');return firewall.confirm(args.trial)
        if args.command=='firewall-rollback':return firewall.rollback(args.trial)
        if args.command=='firewall-boot':return firewall.boot()
    return 2

def entry(argv=None):
    try:return main(argv)
    except Failure as error:print(str(error),file=sys.stderr);return error.code
    except (KeyboardInterrupt,EOFError):print('取消しました。本番切替へは進みません。',file=sys.stderr);return 130
    except Exception:print('処理に失敗しました。秘密保護のため例外の値は表示しません。状態と手順を確認してください。',file=sys.stderr);return 5

if __name__=='__main__':sys.exit(entry())
