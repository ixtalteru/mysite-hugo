"""Default schema and compatible entry points for the RC2 menu."""
def sample(version,architecture="amd64"):
    return {'installer_schema':1,'platform':{'id':'ubuntu','version_id':version,'architecture':architecture},'timezone':'Asia/Tokyo','admin':{'user':'ubuntu','ssh_cidr':'192.0.2.0/24'},'sip':{'auth_username':'','user_id':'','phone_number':'','host':'softphone.spc.brastel.ne.jp','port':5060},'mail':{'fax_address':'','allowed_senders':[],'receive_recipients':[],'imap':{'host':'imap.gmail.com','port':993,'security':'implicit_tls','auth_type':'password','username':'','folder':'INBOX'},'smtp':{'host':'smtp.gmail.com','port':587,'security':'starttls','auth_type':'password','username':'','max_message_bytes':26214400},'authentication':{'mechanism':'provider_dmarc_arc','trust_boundary_verified':False,'placement_verified':False,'trusted_authserv_ids':['mx.google.com'],'authentication_results_index':0,'trusted_arc_domains':['google.com']},'trash_completed_requests':True}}

def load():
    from .ui import load as resume
    return resume()

def configure(section="install"):
    from .ui import configure as edit
    return edit(section)

def menu():
    from .ui import menu as main_menu
    return main_menu()
