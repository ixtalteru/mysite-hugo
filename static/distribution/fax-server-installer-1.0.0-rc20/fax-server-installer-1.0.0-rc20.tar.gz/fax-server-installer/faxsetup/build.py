import json
import os
import re
import shutil
import time
import urllib.request
from pathlib import Path
from .model import Failure,require,digest
from . import host as h

def python_environment(profile):
    h.run(['python3','-m','venv','--system-site-packages',h.APP/'venv'])
    python=h.APP/'venv/bin/python'
    # Only Ubuntu22 needs PyPI supplements (including Python 3.10 typing support). Pin version, official HTTPS source,
    # wheel digest and disable dependency resolution; never upgrade system Python.
    for package,version in profile['pip'].items():
        url=f'https://pypi.org/pypi/{package}/{version}/json'
        try:
            with urllib.request.urlopen(url,timeout=30) as response:data=json.load(response)
        except Exception:raise Failure(3,'固定版Python補完パッケージの公式配布情報を取得できません。') from None
        wheels=[x for x in data['urls'] if x['filename'].endswith('py3-none-any.whl') and not x.get('yanked')]
        require(len(wheels)==1,'Python補完パッケージの固定版wheelが一意に解決できません。',3)
        sha=wheels[0]['digests']['sha256'];require(re.fullmatch('[0-9a-f]{64}',sha),'wheelハッシュが不正です。',3)
        lock=h.STATE/(package+'-requirements.txt');h.atomic(lock,f'{package}=={version} --hash=sha256:{sha}\n'.encode())
        h.run([python,'-m','pip','--isolated','install','--index-url','https://pypi.org/simple','--only-binary=:all:','--no-deps','--require-hashes','-r',lock],timeout=300)
        h.write_json(h.STATE/(package+'-source.json'),{'package':package,'version':version,'sha256':sha,'metadata_url':url})
    # Check imports as well as metadata: a distribution can be installed while
    # a Python-version-specific runtime dependency is missing.
    try:
        h.run([python,'-B','-c','import html5lib; from PIL import Image,ImageOps; from pypdf import PdfReader,PdfWriter,Transformation; from weasyprint import HTML; import dkim,dns'])
        if profile['pip']:
            # Check the explicitly installed wheels, not unrelated OS packages
            # exposed by --system-site-packages (e.g. optional GI bindings).
            dependency_check="""import importlib.metadata as m,sys
from pip._vendor.packaging.requirements import Requirement
for package in sys.argv[1:]:
    for text in m.requires(package) or []:
        req=Requirement(text)
        if req.marker and not req.marker.evaluate({'extra':''}):continue
        version=m.version(req.name)
        if version not in req.specifier:raise RuntimeError('Dependency version mismatch: '+req.name)
"""
            h.run([python,'-B','-c',dependency_check,*profile['pip']])
    except Failure as error:
        error.args=('Python依存関係の読み込み・整合性検査に失敗しました。詳細ログで不足モジュールを確認してください。',)
        raise
    code="import importlib.metadata as m,json;print(json.dumps({k:m.version(k) for k in ['WeasyPrint','Pillow','pypdf','dkimpy','dnspython']}))"
    code=code.replace("['WeasyPrint','Pillow','pypdf','dkimpy','dnspython']",repr(list(dict.fromkeys(['WeasyPrint','Pillow','pypdf','dkimpy','dnspython',*profile['pip']]))))
    versions=json.loads(h.run([python,'-B','-c',code]).stdout)
    h.write_json('/etc/faxmail-next/dependency-lock.json',versions,mode=0o644)
    return versions

def source_options(sources,lists):
    # Bound each stalled connection; retain APT signature/TLS checks. A partial
    # index update must fail rather than silently using an incomplete index.
    return ['-o','Dir::Etc::sourcelist='+str(sources),'-o','Dir::Etc::sourceparts=-',
            '-o','Dir::State::lists='+str(lists),'-o','APT::Get::List-Cleanup=0',
            '-o','APT::Sandbox::User=root','-o','Acquire::http::Timeout=15',
            '-o','Acquire::https::Timeout=15','-o','Acquire::Retries=2',
            '-o','APT::Update::Error-Mode=any','-o','Acquire::Languages=none']


def fetch_asterisk_source(options,version,stage):
    from .diagnostics import stage as progress
    for label,args,cwd in [
        ('A3: Ubuntu署名付きソース索引の取得',['apt-get',*options,'update'],None),
        ('A3: Asterisk固定版ソースの取得',['apt-get',*options,'source','--download-only','--only-source','asterisk='+version],stage)]:
        progress(label)
        try:h.run(args,cwd=cwd,timeout=600)
        except Failure as error:
            error.args=(label+'に失敗しました。'+str(error)+' 取得先の通信・DNS・プロキシと詳細ログを確認して再実行してください。',)
            raise


def a3_module(profile):
    version=profile['packages']['asterisk']
    for package in ('asterisk','asterisk-dev','asterisk-modules'):
        require(h.run(['dpkg-query','-W','-f=${Version}',package]).stdout==version,'Asterisk本体・dev・modulesの版が一致しません。',3)
    stage=h.mkdir(h.STATE/'build'/str(__import__('uuid').uuid4()))
    h.atomic(stage/'created',str(time.time()).encode())
    lists=h.mkdir(stage/'lists');h.mkdir(lists/'partial')
    codename={'22.04':'jammy','24.04':'noble','26.04':'resolute'}[profile['version']]
    sources=stage/'sources.list'
    source_archive=profile.get('source_archive','https://archive.ubuntu.com/ubuntu')
    require(source_archive in ('https://archive.ubuntu.com/ubuntu','https://ports.ubuntu.com/ubuntu-ports'),'未承認のソース取得先です。',3)
    h.atomic(sources,(''.join(f'deb-src [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] {source_archive} {suite} universe\n' for suite in (codename,codename+'-updates',codename+'-security'))).encode())
    options=source_options(sources,lists)
    fetch_asterisk_source(options,version,stage)
    from .diagnostics import stage as progress
    progress('A3: ソース検証・パッチ・ネイティブビルド')
    descriptors=list(stage.glob('*.dsc'));require(len(descriptors)==1,'Asteriskソース記述子が一意でありません。',3)
    source=stage/'source';h.run(['dpkg-source','-x',descriptors[0],source],timeout=300)
    actual=h.run(['dpkg-parsechangelog','-l'+str(source/'debian/changelog'),'-S','Version']).stdout.strip()
    require(actual==version,'Asteriskソース版が一致しません。',3)
    src=source/'res/res_fax_spandsp.c';text=src.read_text();before=digest(src.read_bytes())
    anchor='t30_set_supported_modems(p->t30_state, spandsp_modems(s->details));'
    require(text.count(anchor)==1,'A3パッチの対象位置が一致しません。',3)
    addition='\n\t/* Preserve default lengths; additionally negotiate B4/A3 scan widths. */\n\tt30_set_supported_image_sizes(p->t30_state, p->t30_state->supported_image_sizes | T30_SUPPORT_255MM_WIDTH | T30_SUPPORT_303MM_WIDTH);'
    # A different upstream implementation must be reviewed, not patched twice.
    require('T30_SUPPORT_303MM_WIDTH' not in text,'上流A3実装を検出。OSプロファイルの確認が必要です。',3)
    if profile['version']=='24.04':require(before=='116c736f74a6d239c8827d142cb7151a919e6eb645881d69ef05167bb45e33f1','24.04ソースhashが採取版と一致しません。',3)
    require(text.count('.enhances = "res_fax"')==1,'FAXエンジンの依存宣言が不適合です。',3)
    patched=text.replace(anchor,anchor+addition).replace('.enhances = "res_fax"','.enhances = "res_fax_ssrc"');src.write_text(patched)
    output=stage/'res_fax_spandsp.so'
    h.run(['gcc','-shared','-fPIC','-O2','-DAST_MODULE="res_fax_spandsp"','-DAST_MODULE_SELF_SYM=__internal_res_fax_spandsp_self','-I/usr/include','-I/usr/include/libxml2','-o',output,src,'-lspandsp','-lm'],timeout=300)
    require('not found' not in h.run(['ldd',output]).stdout,'A3共有ライブラリが解決できません。',3)
    module_dir=h.APP/'asterisk-modules';h.mkdir(module_dir,0o755)
    original=[Path(p) for p in h.run(['dpkg','-L','asterisk-modules']).stdout.splitlines() if p.endswith('/res_fax_spandsp.so')]
    require(len(original)==1,'標準モジュール位置を特定できません。',3)
    for p in original[0].parent.glob('*.so'):
        if p.name=='res_fax_spandsp.so':continue
        target=module_dir/p.name
        require(not target.exists() or (target.is_symlink() and target.resolve()==p.resolve()),'モジュールリンクの衝突を検出しました。',3)
        if not target.exists():target.symlink_to(p)
    from .ssrc import compile_module
    ssrc_module,ssrc_source,ssrc_provenance=compile_module(source,stage)
    h.atomic(module_dir/'res_fax_spandsp.so',output.read_bytes(),0o644)
    # Keep the patched FAX core separate from the OS-provided module.
    h.atomic(module_dir/'res_fax_ssrc.so',ssrc_module.read_bytes(),0o644)
    h.mkdir(h.APP/'asterisk-a3-source',0o755)
    h.atomic(h.APP/'asterisk-a3-source/res_fax_spandsp.c',src.read_bytes(),0o644)
    provenance={'architecture':profile['arch'],'source_archive':source_archive,'asterisk_version':version,'source_sha256':before,'patched_sha256':digest(src.read_bytes()),'module_sha256':digest(output.read_bytes()),'dsc_sha256':digest(descriptors[0].read_bytes()),'source_authentication':'Ubuntu archive InRelease verified by APT; source checksums verified by dpkg-source','tested':False}
    h.atomic(h.APP/'asterisk-a3-source/res_fax.c',ssrc_source.read_bytes(),0o644)
    provenance['ssrc_fix']=ssrc_provenance
    h.write_json(h.APP/'asterisk-a3-source/provenance.json',provenance,mode=0o644)

def explain_offline_failure(error):
    detail=getattr(error,'details','')
    failed=re.findall(r'^([a-zA-Z0-9_]+): FAIL$',detail,re.M)
    missing=re.findall(r'^OFFLINE_MISSING_MODULE: ([a-zA-Z0-9_.]+)$',detail,re.M)
    exception=re.findall(r'^OFFLINE_EXCEPTION: ([a-zA-Z0-9_]+)$',detail,re.M)
    message='オフライン回帰試験が失敗しました。'
    if failed:message+=' 不合格項目: '+', '.join(failed[:10])+'。'
    if missing:message+=' 不足するPythonモジュール: '+missing[-1]+'。'
    elif exception:message+=' 例外: '+exception[-1]+'。'
    error.args=(message+' 詳細ログを確認してください。',)


def isolated_tests():
    from .diagnostics import stage as progress
    report={'offline':'SKIP','a3':'SKIP','namespace':'SKIP','external':'SKIP','updated':time.time()}
    h.require(not h.active('fax-receive-live.service'),'隔離検査前に本番Asteriskを停止してください。')
    try:
        progress('オフライン回帰試験（ネットワーク隔離）')
        unit='fax-installer-selftest-'+str(os.getpid())
        try:
            result=h.run(['systemd-run','--quiet','--wait','--pipe','--collect','--unit='+unit,'-p','User=faxmail','-p','Group=faxmail','-p','PrivateNetwork=yes','-p','PrivateTmp=yes','-p','ProtectSystem=strict','-p','ProtectHome=yes','-p','WorkingDirectory=/opt/faxmail-next','-p','RuntimeMaxSec=600',h.APP/'venv/bin/python','-B',h.INSTALLED/'faxsetup/offline.py'],timeout=660)
        except Failure as error:
            report['offline']='FAIL'
            explain_offline_failure(error)
            raise
        require('FAIL' not in result.stdout and result.stdout.count('PASS')>=53,'既存オフライン回帰試験が不合格です。',4)
        report['offline']='PASS';report['offline_output']=result.stdout
        progress('A3混在ページの内部FAX送受信試験')
        root=h.mkdir('/var/lib/fax-installer-tests',0o755)
        stage=h.mkdir(root/str(__import__('uuid').uuid4()),0o700,'asterisk','asterisk')
        h.atomic(stage/'created',str(time.time()).encode(),0o600,'asterisk','asterisk')
        unit='fax-installer-a3-'+str(os.getpid())
        try:
            result=h.run(['systemd-run','--quiet','--wait','--pipe','--collect','--unit='+unit,'-p','User=asterisk','-p','Group=asterisk','-p','PrivateNetwork=yes','-p','PrivateTmp=yes','-p','ProtectSystem=strict','-p','ProtectHome=yes','-p','ReadWritePaths='+str(stage),'-p','RuntimeMaxSec=300',h.APP/'venv/bin/python','-B',h.INSTALLED/'faxsetup/loopback.py',stage],timeout=330)
        except Failure as error:
            detail=getattr(error,'details','')
            phases={'PDF_TO_TIFF':'試験PDFからFAX画像への変換','ASTERISK_START':'隔離Asteriskの起動・モジュール読込','FAX_EXCHANGE':'A4・A3混在3ページの内部送受信','TIFF_TO_PDF':'受信画像からPDFへの変換'}
            found=re.findall(r'A3_TEST_PHASE: ([A-Z_]+)',detail)
            if found and found[-1] in phases:
                message=phases[found[-1]]+'で失敗しました。'
                if 'RASTER_FAILED' in detail:message+='PDF画像変換エラー（RASTER_FAILED）。Ghostscriptの実行権限・一時領域・詳細ログを確認してください。'
                error.args=(message+' 試験ログ: '+str(stage/'log'),)
            raise
        require('A3_LOOPBACK_PASS' in result.stdout,'A3隔離通信試験が不合格です。',4);report['a3']='PASS'
        progress('発信ディレクトリの隔離環境試験')
        unit='fax-installer-rename-'+str(os.getpid())
        h.run(['systemd-run','--quiet','--wait','--pipe','--collect','--unit='+unit,'-p','User=faxdispatch','-p','Group=faxdispatch','-p','ProtectSystem=strict','-p','PrivateTmp=yes','-p','PrivateNetwork=yes','-p','ReadWritePaths=/var/lib/fax-receive-live/spool/outgoing','/usr/bin/python3','-B',h.APP/'scripts/fax-dispatch-preflight.py'],timeout=60)
        report['namespace']='PASS'
        provenance=h.read_json(h.APP/'asterisk-a3-source/provenance.json');provenance['tested']=True
        h.write_json(h.APP/'asterisk-a3-source/provenance.json',provenance,mode=0o644)
    finally:h.write_json(h.STATE/'verification.json',report)
    return report
