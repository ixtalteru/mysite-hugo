import base64,json,os,re,shutil,stat,time,uuid
from pathlib import Path
from . import host as h
from . import build,firewall
from .model import BUNDLE,Failure,require,inputs,generate,dump,digest,site_config,secrets_config,platform_profile

def bundle_check():
    h.source_integrity()
    for item in h.read_json(BUNDLE/'payload-manifest.json'):
        require(digest((BUNDLE/item['payload']).read_bytes())==item['sha256'],'payloadの完全性検査に失敗しました。',4)

def plan(site,secrets,fw,people):
    profile=platform_profile(site['platform']['version_id'],site['platform']['architecture'])
    return {'version':'1.0.0-rc20','platform':site['platform'],'release_tested':profile['release_tested'],'completion':'STAGED','network_on_install':'Ubuntu署名付きAPT、Asteriskソース取得'+('、PyPIの固定pypdf wheel' if profile['pip'] else ''),'chrony':'既存構成を維持','package_policy':'Asterisk関連は固定、その他は公式APT候補を実機で解決','packages':profile['packages'],'pip':profile['pip'],'sender_count':len(site['mail']['allowed_senders']),'receive_count':len(site['mail']['receive_recipients']),'firewall':'設定候補を保存。適用は別コマンド。','ssh_port':fw['ssh_port'],'minimum_free_gib':profile['min_free_gib'],'secrets':'入力済み（非表示）','server_accounts':'SIP・IMAP・SMTP接続は本番切替まで開始しません。'}

def managed_payload(site,secrets):
    result=generate(site,secrets)
    # Firewall belongs to its own transaction. Production gates are not payload.
    for p in [str(g) for g in h.GATES]+['/etc/systemd/system/faxmail-firewall.service','/etc/faxmail-next/dependency-lock.json']:
        result.pop(p,None)
    return result

def write_settings(site,secrets,fw,people):
    h.mkdir(h.ADMIN)
    for name,data in [('site',site),('secrets',secrets),('firewall',fw),('users',people)]:h.write_json(h.ADMIN/(name+'.json'),data)
    h.write_json(h.ADMIN/'candidate.json',{'site':site,'secrets':secrets,'firewall':fw,'users':people})
    candidates=h.mkdir(h.ADMIN/'gates')
    generated=generate(site,secrets)
    for gate in h.GATES:h.atomic(candidates/gate.name,generated[str(gate)])

def admin_access(site):
    import pwd
    try:account=pwd.getpwnam(site['admin']['user'])
    except KeyError:raise Failure(2,'指定された管理ユーザーが存在しません。事前に公開鍵SSH接続を用意してください。') from None
    keyfile=Path(account.pw_dir)/'.ssh/authorized_keys'
    require(keyfile.is_file() and not keyfile.is_symlink(),'管理ユーザーの既存公開鍵を確認できません。')
    registered=keyfile.read_text().splitlines()
    require(any(x.strip() and not x.startswith('#') for x in registered),'管理公開鍵が空です。')
    requested=site['admin'].get('authorized_public_keys',[])
    # Existing working keys are never replaced by a batch installer.
    require(all(any(' '.join(k.split()[:2]) in line for line in registered) for k in requested),'指定公開鍵は事前に登録・接続確認してください。既存管理鍵は保持します。')

def preflight(site):
    """Read-only host checks; no apt update/install or external connections."""
    results=[]
    def check(label,action):
        try:action();results.append((label,True,'確認できました'))
        except Failure as e:results.append((label,False,str(e)))
        except Exception as e:results.append((label,False,type(e).__name__+'。環境を確認してください。'))
    check('配布ファイル',bundle_check)
    try:profile=h.platform()
    except Failure as e:return results+[('OS',False,str(e))]
    check('OS/CPU',lambda:require(site['platform']['version_id']==profile['version'] and site['platform']['architecture']==profile['arch'],'保存したOS/CPUと実機が違います。'))
    check('空き容量',lambda:require(shutil.disk_usage('/').free>=profile['min_free_gib']*1024**3,'空き容量'+str(profile['min_free_gib'])+'GiB以上が必要です。'))
    def memory():
        m=re.search(r'^MemTotal:\s*(\d+)',Path('/proc/meminfo').read_text(),re.M)
        require(m and int(m[1])>=profile['min_memory_mib']*1024,'メモリーが不足しています。')
    check('メモリー',memory);check('管理ユーザーのSSH公開鍵',lambda:admin_access(site))
    def packages():
        h.package_plan(dict(profile['packages']))
    check('APT依存関係（変更なしの予行検査）',packages)
    return results

def install(site,secrets,fw,people,experimental=False,repair=False):
    from . import diagnostics as d
    d.begin([site,secrets,fw,people])
    try:return _install(site,secrets,fw,people,experimental,repair)
    except BaseException as error:
        d.record(error)
        raise

def _install(site,secrets,fw,people,experimental=False,repair=False):
    from .diagnostics import stage
    bundle_check();profile=h.platform()
    require(site['platform']['version_id']==profile['version'] and site['platform']['architecture']==profile['arch'],'設定OS/CPUと実機が一致しません。',3)
    require(profile['release_tested'] or experimental,'この配布版は実機受入前です。計画確認後、検証環境では --accept-unvalidated-platform を明示してください。',3)
    require(shutil.disk_usage('/').free>=profile['min_free_gib']*1024**3,'導入・ビルド用の空き容量が不足しています。',3)
    mem=re.search(r'^MemTotal:\s*(\d+)',Path('/proc/meminfo').read_text(),re.M)
    require(mem and int(mem[1])>=profile['min_memory_mib']*1024,'メモリー容量が不足しています。',3)
    admin_access(site)
    previous=h.state();known=previous['status']!='NOT_INSTALLED'
    baseline_done=previous.get('baseline_done',False)
    if (h.ADMIN/'site.json').exists():
        old=h.read_json(h.ADMIN/'site.json')
        if old['mail']['fax_address']!=site['mail']['fax_address'] or old['mail']['imap']!=site['mail']['imap']:baseline_done=False
    require(known or not any(Path(p).exists() for p in ['/opt/faxmail-next','/etc/faxmail-next','/var/lib/fax-receive-live']),'管理対象外のFAX環境があります。新規初期化せず停止しました。')
    if known:
        h.ensure_idle()
        if not repair:h.verify_managed()
        if not repair and (h.ADMIN/'site.json').exists() and all(h.read_json(h.ADMIN/(name+'.json'))==v for name,v in [('site',site),('secrets',secrets),('firewall',fw),('users',people)]) and previous.get('release')=='1.0.0-rc20' and previous['status'] in ('STAGED','ACTIVE'):
            require(diagnose()==0,'既存配置の診断が不合格です。',4)
            print('同一設定です。再配置・DB初期化・rebaselineは行いません。');return 0
    h.set_state('INSTALLING',release='1.0.0-rc20',platform=profile['version'],architecture=profile['arch'])
    try:
        stage('既存FAXサービスの停止')
        if known:h.stop_processing();h.fence()
        build_needed=not known or repair or not (h.APP/'asterisk-modules/res_fax_spandsp.so').exists() or not (h.APP/'asterisk-modules/res_fax_ssrc.so').exists()
        stage('APT依存関係の確認・パッケージ導入')
        if build_needed:h.install_packages(profile)
        stage('サービスアカウント・インストーラーの配置')
        h.prepare_accounts();h.install_bundle()
        result=managed_payload(site,secrets)
        configpaths=[h.ADMIN/(name+'.json') for name in ('site','secrets','firewall','users','candidate')]
        paths=[Path(p) for p in result]+configpaths+[h.APP/'asterisk-modules/res_fax_spandsp.so',h.APP/'asterisk-modules/res_fax_ssrc.so',h.APP/'asterisk-a3-source/res_fax.c',h.APP/'asterisk-a3-source/res_fax_spandsp.c',h.APP/'asterisk-a3-source/provenance.json',Path('/etc/faxmail-next/dependency-lock.json')]
        with h.transaction(paths):
            stage('FAX本体・SIP・メール設定の配置')
            metadata={row['path']:row for row in h.read_json(BUNDLE/'payload-manifest.json')}
            for path,body in result.items():
                row=metadata.get(path,{'mode':'0600','owner':'root','group':'root'})
                h.atomic(path,body,int(row['mode'],8),row['owner'],row['group'])
            write_settings(site,secrets,fw,people)
            if build_needed:
                stage('Python実行環境の構築');build.python_environment(profile)
                stage('A3対応Asteriskモジュールの構築');build.a3_module(profile)
            stage('FAXデータベース・共有制御の準備')
            h.initialize();h.fence()
            stage('systemdサービス定義の検証')
            h.run(['systemctl','daemon-reload'])
            units=[p for p in result if p.startswith('/etc/systemd/system/') and p.endswith(('.service','.timer'))]
            h.run(['systemd-analyze','verify',*units])
            build.isolated_tests()
            stage('管理ファイルの整合性記録')
            source={}
            for folder in ['faxmail','scripts']:
                for p in (h.APP/folder).glob('*.py'):source[str(p.relative_to(h.APP))]=digest(p.read_bytes())
            h.write_json('/etc/faxmail-next/source-manifest.json',source,mode=0o644)
            h.record_managed(list(result)+['/etc/faxmail-next/dependency-lock.json','/etc/faxmail-next/source-manifest.json',str(h.APP/'asterisk-a3-source/provenance.json'),str(h.APP/'asterisk-modules/res_fax_spandsp.so'),str(h.APP/'asterisk-modules/res_fax_ssrc.so'),str(h.APP/'asterisk-a3-source/res_fax.c')])
        h.set_state('STAGED',release='1.0.0-rc20',platform=profile['version'],architecture=profile['arch'],baseline_done=baseline_done)
        print('STAGED: 構築済み・未接続。SSH/FWの試行・確定後に本番切替できます。')
        return 0
    except BaseException as error:
        for name,action in [('サービス停止',h.stop_processing),('本番ゲートの無効化',h.fence)]:
            try:action()
            except Exception as cleanup:error.cleanup_errors=getattr(error,'cleanup_errors',[])+[name+': '+type(cleanup).__name__]
        raise

def diagnose():
    status=h.state();checks=[]
    def add(name,ok):checks.append(ok);print(name+': '+('PASS' if ok else 'FAIL'))
    try:h.verify_managed();add('管理ファイルhash・権限',True)
    except Failure:add('管理ファイルhash・権限',False)
    add('導入状態',status['status'] in ('STAGED','ACTIVE'))
    add('空き容量',shutil.disk_usage('/').free>=2*1024**3)
    add('標準Asterisk停止',not h.active('asterisk.service'))
    if status['status']=='STAGED':
        add('未接続状態',not any(h.active(x) for x in h.SERVICES+h.TIMERS) and not any(g.exists() for g in h.GATES))
    if status['status']=='ACTIVE':
        add('本番サービス',all(h.active(x) for x in h.SERVICES+['faxmail-broker.timer']))
        add('FWとSSH待受',firewall.check()==0)
    report=h.read_json(h.STATE/'verification.json') if (h.STATE/'verification.json').exists() else {}
    for key in ('offline','a3','namespace'):add('保存された隔離試験:'+key,report.get(key)=='PASS')
    print('SIP/IMAP/SMTP実接続・FAX実通信: SKIP（通常診断では実行しません）')
    return 0 if all(checks) else 4

def start_production_services(units):
    try:
        h.run(['systemctl','enable','--now',*units])
        failed=[unit for unit in units if not h.active(unit)]
        require(not failed,'本番サービスが稼働していません: '+', '.join(failed),4)
    except Failure as error:
        detail=getattr(error,'details','')
        failed=[name for name in re.findall(r'Job for ([A-Za-z0-9_.@-]+) failed',detail) if name in units]
        if not failed:failed=[unit for unit in units if not h.active(unit)]
        if failed:
            error.args=('本番サービスの起動に失敗しました: '+', '.join(failed)+'。詳細ログにサービスの実行結果を記録します。',)
            for unit in dict.fromkeys(failed):
                try:detail+='\n'+unit+' journal:\n'+h.run(['journalctl','-u',unit,'-n','20','--no-pager'],False,timeout=20).stdout
                except Exception:detail+='\nサービスログを取得できませんでした。'
            error.details=detail
        raise


ENGINE_CHECKS={'registered':'SIP登録','idle':'通話待機','channels_known':'通話状態の取得','modules':'FAXモジュール','ntp':'時刻同期','firewall':'ファイアウォール'}


def engine_pending(engine):
    return [label for key,label in ENGINE_CHECKS.items() if engine.get(key) is not True]


def require_engine_ready(engine):
    pending=engine_pending(engine)
    if pending:
        error=Failure(4,'本番開始の条件未達: '+ '、'.join(pending)+'。SIP登録が未完了の場合は /var/lib/fax-receive-live/log/fax-notices を確認してください。')
        error.details=json.dumps({key:engine.get(key) for key in ENGINE_CHECKS},ensure_ascii=False)
        raise error


def activation(source_quiesced=False):
    require(source_quiesced,'旧サーバーの同一SIP/メール処理を停止確認して --source-quiesced を指定してください。')
    require(h.state()['status']=='STAGED','STAGED状態で本番切替してください。')
    h.ensure_idle();require(diagnose()==0,'配置診断が不合格です。',4)
    require(firewall.check()==0,'SSH/FWの試行・新規接続確認・確定が必要です。',4)
    site=h.read_json(h.ADMIN/'site.json');auth=site['mail']['authentication']
    from . import diagnostics as d
    d.collect(site);d.collect(h.read_json(h.ADMIN/'secrets.json'))
    if auth['mechanism']=='provider_dmarc_arc':require(auth['trust_boundary_verified'] and auth['placement_verified'] and auth['trusted_authserv_ids'] and auth['trusted_arc_domains'],'メール認証境界が未確認です。')
    h.set_state('ACTIVATING')
    try:
        d.stage('本番FAXエンジンの起動')
        h.run(['systemctl','start','faxmail-maintenance.service','fax-receive-live.service'])
        d.stage('SIP登録・時刻同期・FAXエンジンの準備確認')
        ready=False;previous_pending=None
        for _ in range(12):
            h.run(['systemctl','start','faxmail-broker.service'])
            engine=h.read_json('/var/lib/fax-engine-state/engine-state.json')
            pending=engine_pending(engine)
            if pending!=previous_pending:
                print('本番準備: '+('すべてOK' if not pending else '確認待ち: '+'、'.join(pending)),flush=True);previous_pending=pending
            if not pending:ready=True;break
            time.sleep(5)
        require_engine_ready(engine)
        d.stage('メール処理の開始位置と本番ゲートの準備')
        # Establish the mailbox baseline only on the first activation.
        if not h.state().get('baseline_done'):
            h.run(['runuser','-u','faxmail','--','/usr/local/bin/faxmail-next','rebaseline'])
            h.set_state('ACTIVATING',baseline_done=True)
        h.atomic(h.GATES[0],(h.ADMIN/'gates'/h.GATES[0].name).read_bytes(),0o644)
        if site['mail']['receive_recipients']:h.atomic(h.GATES[1],(h.ADMIN/'gates'/h.GATES[1].name).read_bytes(),0o640,'root','faxmail')
        h.run(['runuser','-u','faxmail','--','/usr/local/bin/faxmail-next','preflight','--redacted'])
        h.run(['runuser','-u','faxmail','--','/usr/local/bin/faxmail-next','resume'])
        units=h.SERVICES+['faxmail-broker.timer','faxmail-cleanup.timer','faxmail-maintenance.timer']
        if site['mail']['receive_recipients']:units+=['faxmail-receive-mail.timer']
        d.stage('本番サービスの開始')
        start_production_services(units)
        h.set_state('ACTIVE')
        print('ACTIVE: 本番処理を開始しました。最初のFAX依頼はこの後に送ってください。実回線の成功保証ではありません。')
    except BaseException as error:
        cleanup_failed=False
        for name,action in [('サービス停止',h.stop_processing),('本番ゲート無効化',h.fence)]:
            try:action()
            except Exception as cleanup:
                cleanup_failed=True
                error.cleanup_errors=getattr(error,'cleanup_errors',[])+[name+': '+type(cleanup).__name__]
        try:h.set_state('FAILED' if cleanup_failed else 'STAGED')
        except Exception as cleanup:error.cleanup_errors=getattr(error,'cleanup_errors',[])+['状態保存: '+type(cleanup).__name__]
        raise
    return 0

def activate_managed(source_quiesced=False):
    from . import diagnostics as d
    d.begin([]);d.stage('本番開始前の状態・SSH/FW確認')
    try:return _activate_managed(source_quiesced)
    except BaseException as error:
        d.record(error)
        raise


def _activate_managed(source_quiesced=False):
    # firewall-boot obtains the same management lock in its own process.
    # Start that service outside the activation lock, then recheck all gates.
    require(source_quiesced,'旧サーバーの停止確認が必要です。')
    with h.locked():
        require(h.state()['status']=='STAGED','STAGED状態で本番開始してください。')
        h.ensure_idle();require(firewall.check()==0,'先にSSH/FWを確定してください。',4)
    h.run(['systemctl','restart','faxmail-firewall.service'])
    with h.locked():return activation(source_quiesced)

def uninstall_plan():
    require((h.STATE/'managed.json').exists(),'このインストーラーで導入した本体がありません。')
    allowed={x['path'] for x in h.read_json(BUNDLE/'payload-manifest.json')}
    allowed|={str(h.APP/'asterisk-modules/res_fax_spandsp.so'),str(h.APP/'asterisk-modules/res_fax_ssrc.so'),str(h.APP/'asterisk-a3-source/res_fax.c'),str(h.APP/'asterisk-a3-source/provenance.json')}
    selected=[]
    for name in h.read_json(h.STATE/'managed.json'):
        # Retain all business data, settings, SSH/firewall and OS packages.
        p=Path(name)
        if name not in allowed:continue
        if p.is_relative_to(h.APP) or name=='/usr/local/bin/faxmail-next' or (p.is_relative_to(Path('/etc/systemd/system')) and p.name!='faxmail-firewall.service'):
            selected.append(h.safe(p))
    require(selected,'削除対象の管理ファイルがありません。')
    return sorted(selected)

def uninstall():
    h.ensure_idle();h.verify_managed();paths=uninstall_plan()
    h.stop_processing();h.fence()
    record=h.read_json(h.STATE/'managed.json')
    # Record removed files for recovery and only unlink exact manifest entries.
    folder=h.mkdir(h.STATE/'uninstall'/str(uuid.uuid4()))
    h.write_json(folder/'before.json',h.snapshot(paths))
    h.set_state('UNINSTALLING')
    for p in paths:
        h.safe(p)
        if p.exists():require(p.is_file(),'通常ファイル以外は削除できません。');p.unlink()
        record.pop(str(p),None)
    h.write_json(h.STATE/'managed.json',record)
    h.run(['systemctl','daemon-reload'])
    h.set_state('UNINSTALLED')
    print('本体とFAX用unitを除去しました。データ・設定・管理ツール・SSH/FW・OSパッケージは保持しています。')
    return 0

def backup():
    h.ensure_idle();h.verify_managed()
    paths=[Path(p) for p in h.read_json(h.STATE/'managed.json')]
    paths += [h.ADMIN/(n+'.json') for n in ('site','secrets','users','firewall')]
    paths += [h.APP/'asterisk-a3-source/res_fax.c',h.APP/'asterisk-a3-source/res_fax_spandsp.c',firewall.SSH,firewall.SOCKET]
    # Snapshot includes settings/code/units but never business DB or dedupe keys.
    target=h.mkdir(Path('/var/lib/faxmail-backups')/str(uuid.uuid4()))
    data={'schema':1,'release':'1.0.0-rc20','created':time.time(),'machine_id':Path('/etc/machine-id').read_text().strip(),'platform':h.state().get('platform'),'files':h.snapshot(paths)}
    h.write_json(target/'settings.json',data);h.atomic(target/'created',str(data['created']).encode())
    h.atomic(target/'settings.sha256',digest((target/'settings.json').read_bytes()).encode())
    print('秘密を含むroot限定バックアップ: '+str(target));return 0

def restore(directory):
    h.ensure_idle();source=h.safe(Path(directory).absolute())
    require(source.parent==Path('/var/lib/faxmail-backups') and re.fullmatch('[0-9a-f-]{36}',source.name),'バックアップの場所が不正です。')
    data=h.read_secret(source/'settings.json')
    require(digest((source/'settings.json').read_bytes())==h.safe(source/'settings.sha256').read_text(),'設定バックアップのハッシュ不一致です。',4)
    require(data.get('schema')==1 and data.get('release')=='1.0.0-rc20' and 0<=time.time()-data['created']<168*3600,'バックアップ版または期限が不適合です。')
    require(data['machine_id']==Path('/etc/machine-id').read_text().strip() and data['platform']==h.platform()['version'],'異なるホスト・OSの設定復元は対象外です。')
    allowed=set(h.read_json(h.STATE/'managed.json'))|{str(h.ADMIN/(n+'.json')) for n in ('site','secrets','users','firewall')}|{str(h.APP/'asterisk-a3-source/res_fax.c'),str(h.APP/'asterisk-a3-source/res_fax_spandsp.c'),str(firewall.SSH),str(firewall.SOCKET)}
    require(set(data['files'])<=allowed,'許可されていないバックアップパスです。')
    def decoded(name):return json.loads(base64.b64decode(data['files'][str(h.ADMIN/(name+'.json'))]['body'],validate=True))
    site,secrets,fw,people=inputs(decoded('site'),decoded('secrets'),decoded('firewall'),decoded('users'),public=True)
    print('設定・コードを復元しSTAGEDへ戻します。DB・鍵は保持します。SSH/FWは別途試行します。')
    h.stop_processing();h.fence()
    files={p:item for p,item in data['files'].items() if p not in (str(firewall.SSH),str(firewall.SOCKET))}
    with h.transaction([Path(p) for p in files]):
        h.restore_files(files);write_settings(site,secrets,fw,people);h.run(['systemctl','daemon-reload']);build.isolated_tests();h.record_managed([p for p in h.read_json(h.STATE/'managed.json') if Path(p).exists()])
    h.set_state('STAGED');print('設定復元完了。FW候補は保存済みです。fax-admin firewallで再確認してください。');return 0

def connection(kind,recipient=None,send=False):
    require(kind in ('imap','smtp'),'接続試験の種類が不正です。')
    site=h.read_json(h.ADMIN/'site.json')
    if send:
        from .model import address
        recipient=address(recipient);require(kind=='smtp','SMTP実送信のみ対応します。')
    # Credentials stay in the runtime file. Pass the command on stdin, never secrets.
    code="import sys,json;sys.path.insert(0,'/opt/faxmail-next');from faxmail.mailio import imap_connect,smtp_connect;c=json.load(open('/etc/faxmail-next/site-mail.json'));"
    if kind=='imap':code+="s=imap_connect(c);assert s.select('INBOX',readonly=True)[0]=='OK';s.logout();print('IMAP_TLS_AUTH_READONLY_PASS')"
    elif not send:code+="s=smtp_connect(c);s.close();print('SMTP_TLS_AUTH_PASS')"
    else:
        code+="from email.message import EmailMessage;m=EmailMessage();m['From']=c['mail']['fax_address'];m['To']="+repr(recipient)+";m['Subject']='FAX server connection test';m.set_content('FAX server SMTP test. No FAX call.');s=smtp_connect(c);s.sendmail(c['mail']['fax_address'],["+repr(recipient)+"],m.as_bytes());s.close();print('SMTP_ACCEPTED_NOT_DELIVERY_CONFIRMED')"
    r=h.run([h.APP/'venv/bin/python','-B','-'],input=code,timeout=90)
    print(r.stdout.strip());return 0
