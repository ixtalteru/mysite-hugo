"""Own-table firewall transaction, new SSH session confirmation and boot rollback."""
import ipaddress,json,os,re,time,uuid
from pathlib import Path
from . import host as h
from .model import require,Failure,firewall as validate,dump

TRIAL=h.STATE/'firewall-trial.json'
COMMITTED=h.STATE/'firewall-committed.json'
SSH=Path('/etc/ssh/sshd_config.d/00-fax-installer.conf')
SOCKET=Path('/etc/systemd/system/ssh.socket.d/99-fax-installer.conf')
NFT=h.STATE/'firewall.nft'
BOOT='/etc/systemd/system/faxmail-firewall.service'

def rules(fw,extra=None):
    rows=['table inet faxmail_guard {','chain input { type filter hook input priority 10; policy drop;', 'iifname "lo" accept','ct state invalid drop','ct state established,related accept','ip protocol icmp icmp type { destination-unreachable, time-exceeded, parameter-problem, echo-request, echo-reply } accept','meta l4proto ipv6-icmp accept']
    for item in [fw]+([extra] if extra else []):
        for cidr in item['allowed_source_cidrs']:
            family='ip6' if ipaddress.ip_network(cidr).version==6 else 'ip'
            rows.append(f'{family} saddr {cidr} tcp dport {item["ssh_port"]} ct state new accept')
    return '\n'.join(rows+['}','chain forward { type filter hook forward priority 10; policy drop; }','chain output { type filter hook output priority 10; policy accept; }','}'])+'\n'

def table():return h.run(['nft','-s','list','table','inet','faxmail_guard'],False)
def apply_rules(text):
    body=('delete table inet faxmail_guard\n' if table().returncode==0 else '')+text
    h.run(['nft','-c','-f','-'],input=body)
    h.run(['nft','-f','-'],input=body)

def normalized(value):
    if isinstance(value,dict):return {k:normalized(v) for k,v in value.items() if k not in ('handle','metainfo')}
    if isinstance(value,list):return [normalized(v) for v in value if not (isinstance(v,dict) and 'metainfo' in v)]
    return value

def actual_table():return normalized(json.loads(h.run(['nft','-j','-s','list','table','inet','faxmail_guard']).stdout))

def ssh_session():
    parts=os.environ.get('SSH_CONNECTION','').split()
    require(len(parts)==4,'実SSHセッションから実行してください。sudoでSSH_CONNECTIONを維持してください。')
    try:source=ipaddress.ip_address(parts[0]);local=ipaddress.ip_address(parts[2]);port=int(parts[3])
    except ValueError:raise Failure(2,'SSH接続情報が不正です。') from None
    require(not source.is_loopback and not local.is_loopback,'localhost接続では確認できません。')
    pid=os.getpid();found=None
    for _ in range(24):
        status=Path(f'/proc/{pid}/status')
        if not status.exists():break
        text=status.read_text();name=re.search(r'^Name:\s*(.*)$',text,re.M)[1]
        if name.startswith('sshd'):
            stamp=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[19]
            found=f'{pid}:{stamp}';break
        pid=int(re.search(r'^PPid:\s*(\d+)',text,re.M)[1])
        if pid<=1:break
    require(found is not None,'SSHプロセスの親子関係を確認できません。')
    # Match the real established TCP endpoints, not only environment variables.
    sockets=h.run(['ss','-Htn','state','established']).stdout
    require(any(parts[2]+':'+parts[3] in line and parts[0]+':'+parts[1] in line for line in sockets.replace('[','').replace(']','').splitlines()),'実SSHソケットと接続情報が一致しません。')
    return {'source':str(source),'local':str(local),'port':port,'session':found}

def listeners():
    lines=h.run(['ss','-Hltn']).stdout.splitlines();ports=set()
    for line in lines:
        fields=line.split()
        if len(fields)>=4:
            try:ports.add(int(fields[3].rsplit(':',1)[1]))
            except ValueError:pass
    return ports

def effective_ports():
    if h.active('ssh.socket'):
        output=h.run(['systemctl','show','ssh.socket','-p','Listen','--value']).stdout
        return set(int(v) for v in re.findall(r':(\d+)\s+\(Stream\)',output))
    return set(int(line.split()[1]) for line in h.run(['sshd','-T']).stdout.splitlines() if line.startswith('port '))

def dual_stack_listening(ports):
    # Check each address family separately: an IPv6-only socket must never
    # satisfy the IPv4 check merely because its port number matches.
    for family,wildcards in [('-4',{'0.0.0.0','*'}),('-6',{'[::]','::','*'})]:
        found=set()
        for line in h.run(['ss',family,'-Hltn']).stdout.splitlines():
            fields=line.split()
            if len(fields)<4:continue
            address,separator,port=fields[3].rpartition(':')
            if separator and address in wildcards and port.isdigit():found.add(int(port))
        if not set(ports)<=found:return False
    return True

def socket_config(ports):
    return ('[Socket]\nListenStream=\nBindIPv6Only=ipv6-only\n'+''.join(
        f'ListenStream=0.0.0.0:{p}\nListenStream=[::]:{p}\n' for p in sorted(ports))).encode()

def ssh_config(ports):
    return ('# Managed by fax-admin\n'+''.join('Port '+str(p)+'\n' for p in sorted(ports))+'PubkeyAuthentication yes\nPasswordAuthentication no\nKbdInteractiveAuthentication no\nPermitRootLogin no\n').encode()

def write_ssh(ports,socket):
    h.atomic(SSH,ssh_config(ports),0o600)
    h.run(['sshd','-t'])
    if socket:
        h.atomic(SOCKET,socket_config(ports),0o644)
    h.run(['systemctl','daemon-reload'])
    if socket:
        # Accept=no holds the old listener in ssh.service; killing the main sshd
        # must not kill session children. Verify the distro unit's KillMode.
        mode=h.run(['systemctl','show','ssh.service','-p','KillMode','--value']).stdout.strip()
        accept=h.run(['systemctl','show','ssh.socket','-p','Accept','--value']).stdout.strip()
        if accept=='no':
            require(mode=='process','SSH unitのKillModeがprocessでないため停止しました。')
            h.run(['systemctl','stop','ssh.service'])
        h.run(['systemctl','restart','ssh.socket'])
        if accept=='no':h.run(['systemctl','start','ssh.service'])
    else:h.run(['systemctl','reload','ssh.service'])
    require(effective_ports()==set(ports) and set(ports)<=listeners(),'SSH実待受が候補と一致しません。',5)
    require(dual_stack_listening(ports),'SSHのIPv4・IPv6両方の待受を確認できません。',5)
    config=h.run(['sshd','-T']).stdout
    require('passwordauthentication no' in config and 'kbdinteractiveauthentication no' in config and 'pubkeyauthentication yes' in config,'公開鍵専用SSH設定を確認できません。',5)

def conflict_check():
    config=Path('/etc/ufw/ufw.conf')
    require(not config.exists() or not re.search(r'^ENABLED=yes$',config.read_text(),re.M),'UFWが有効です。併用構成の自動変更は行いません。')
    data=json.loads(h.run(['nft','-j','list','ruleset']).stdout)
    hooks=set()
    for entry in data['nftables']:
        c=entry.get('chain',{})
        if c.get('hook') in ('input','forward') and c.get('table')!='faxmail_guard':
            require(c.get('policy')=='accept','他のFWテーブルに着信/転送遮断があります。')
            hooks.add((c.get('family'),c.get('table'),c.get('name')))
    for entry in data['nftables']:
        r=entry.get('rule',{})
        require((r.get('family'),r.get('table'),r.get('chain')) not in hooks,'既存FWルールとの競合を解消してから試行してください。')

def trial(fw,public=False):
    fw=validate(fw,public);h.ensure_idle();session=ssh_session();conflict_check()
    current=effective_ports();require(current=={session['port']},'複数SSH待受または接続経路不一致を検出しました。')
    require(fw['ssh_port']==session['port'] or fw['ssh_port'] not in listeners(),'指定ポートは他サービスで使用中です。')
    socket=h.active('ssh.socket')
    if socket and h.run(['systemctl','show','ssh.socket','-p','Accept','--value']).stdout.strip()=='no':
        require(h.run(['systemctl','show','ssh.service','-p','KillMode','--value']).stdout.strip()=='process','SSH KillModeにより安全な変更ができません。')
    # Existing public key access must already work; never install untested keys.
    old=table();token=str(uuid.uuid4());unit='fax-firewall-rollback'
    before=h.snapshot([SSH,SOCKET,NFT,COMMITTED,Path(BOOT)])
    data={'id':token,'created':time.time(),'expires':time.time()+300,'origin':session,'candidate':fw,'socket':socket,'old_table':old.stdout if old.returncode==0 else None,'files':before,'boot_enabled':h.run(['systemctl','is-enabled','--quiet','faxmail-firewall.service'],False).returncode==0}
    h.write_json(TRIAL,data)
    boot='[Unit]\nDescription=FAX firewall and interrupted trial recovery\nDefaultDependencies=no\nAfter=local-fs.target\nBefore=network-pre.target ssh.socket ssh.service\nWants=network-pre.target\n[Service]\nType=oneshot\nExecStart=/usr/local/bin/fax-admin firewall-boot\nRemainAfterExit=yes\n[Install]\nWantedBy=multi-user.target\n'
    try:
        h.atomic(BOOT,boot.encode(),0o644);h.run(['systemctl','daemon-reload']);h.run(['systemctl','enable','faxmail-firewall.service'])
        h.run(['systemd-run','--quiet','--unit='+unit,'--on-active=300s','--timer-property=AccuracySec=1s','/usr/local/bin/fax-admin','firewall-rollback','--trial',token])
        extra={'ssh_port':session['port'],'allowed_source_cidrs':[session['source']+('/128' if ':' in session['source'] else '/32')]}
        apply_rules(rules(fw,extra));write_ssh({session['port'],fw['ssh_port']},socket)
    except BaseException:
        rollback(token);raise
    print('SSH設定を試行中。5分以内に新しい公開鍵SSH接続から確定してください。')
    print('sudo fax-admin firewall-confirm --trial '+token)
    print('接続先ポート: '+str(fw['ssh_port'])+' / 期限: '+time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(data['expires'])))
    return 6

def confirm(token):
    require(TRIAL.exists(),'確認待ちの試行がありません。')
    data=h.read_json(TRIAL);session=ssh_session();fw=data['candidate']
    require(data['id']==token and time.time()<data['expires'],'試行ID不一致または期限切れです。')
    require(session['session']!=data['origin']['session'] and session['port']==fw['ssh_port'],'指定新ポートへの新規SSHセッションで確認してください。')
    require(any(ipaddress.ip_address(session['source']) in ipaddress.ip_network(n) for n in fw['allowed_source_cidrs']),'接続元が許可範囲外です。')
    try:
        write_ssh({fw['ssh_port']},data['socket']);text=rules(fw);apply_rules(text)
        h.atomic(NFT,text.encode());h.write_json(COMMITTED,{'config':fw,'table':actual_table()})
        h.write_json(h.ADMIN/'firewall.json',fw)
        require(check()==0,'FW最終検査が不合格です。',4)
        TRIAL.unlink();h.run(['systemctl','stop','fax-firewall-rollback.timer'],False)
        print('SSH・ファイアウォール設定を確定しました。')
    except BaseException:
        rollback(token);raise
    return 0

def rollback(token=None,boot=False):
    if not TRIAL.exists():return 0
    data=h.read_json(TRIAL);require(token is None or token==data['id'],'試行ID不一致です。')
    h.restore_files(data['files'])
    if data['old_table'] is None:
        if table().returncode==0:h.run(['nft','delete','table','inet','faxmail_guard'])
    else:apply_rules(data['old_table'])
    h.run(['systemctl','daemon-reload'])
    if not boot:
        if data['socket']:
            accept=h.run(['systemctl','show','ssh.socket','-p','Accept','--value']).stdout.strip()
            if accept=='no':h.run(['systemctl','stop','ssh.service'])
            h.run(['systemctl','restart','ssh.socket'])
            if accept=='no':h.run(['systemctl','start','ssh.service'])
        else:h.run(['systemctl','reload','ssh.service'])
    if not data['boot_enabled']:h.run(['systemctl','disable','faxmail-firewall.service'],False)
    TRIAL.unlink();h.run(['systemctl','stop','fax-firewall-rollback.timer'],False)
    print('元のSSH・FW設定へ復旧しました。');return 0

def check():
    if not COMMITTED.exists():return 4
    try:
        data=h.read_json(COMMITTED)
        return 0 if actual_table()==data['table'] and effective_ports()=={data['config']['ssh_port']} and dual_stack_listening({data['config']['ssh_port']}) else 4
    except Failure:return 4

def boot():
    if TRIAL.exists():return rollback(boot=True)
    require(NFT.exists(),'確定済みFW設定がありません。',4)
    apply_rules(NFT.read_text());return 0
