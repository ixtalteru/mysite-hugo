"""Installer-only offline runner; never print exception values or source lines."""
import re,sys,traceback
from pathlib import Path
sys.path.insert(0,'/opt/faxmail-next')


def report_error(error):
    print('OFFLINE_EXCEPTION: '+type(error).__name__,flush=True)
    name=getattr(error,'name',None)
    if isinstance(error,ModuleNotFoundError) and isinstance(name,str) and re.fullmatch(r'[A-Za-z0-9_.]+',name):
        print('OFFLINE_MISSING_MODULE: '+name,flush=True)
    for entry in traceback.extract_tb(error.__traceback__):
        print('OFFLINE_LOCATION: '+Path(entry.filename).name+':'+str(entry.lineno)+' '+entry.name,flush=True)


def main():
    try:
        from faxmail.selftest import run
        return run()
    except Exception as error:
        report_error(error)
        return 1


if __name__=='__main__':sys.exit(main())
