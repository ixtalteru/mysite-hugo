"""Executed only inside PrivateNetwork=yes as asterisk. No SIP modules loaded."""
import io,os,subprocess,sys,time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/opt/faxmail-next')

def main():
    from faxmail.convert import convert,receive_pdf
    from pypdf import PdfWriter,PdfReader
    from pypdf.generic import DecodedStreamObject,NameObject
    from PIL import Image
    root=Path(sys.argv[1]);assert root.parent==Path('/var/lib/fax-installer-tests') and not root.is_symlink()
    for name in ['etc','data','run','spool','log','media']:(root/name).mkdir()
    paths={'astetcdir':root/'etc','astmoddir':Path('/opt/faxmail-next/asterisk-modules'),'astvarlibdir':root/'data','astdbdir':root/'data','astkeydir':root/'data','astdatadir':Path('/usr/share/asterisk'),'astagidir':root/'data','astspooldir':root/'spool','astrundir':root/'run','astlogdir':root/'log'}
    conf=root/'etc/asterisk.conf';conf.write_text('[directories]\n'+''.join(f'{k} => {v}\n' for k,v in paths.items())+'[options]\nverbose=3\ndebug=0\n')
    mods=['res_timing_timerfd','res_fax_ssrc','res_fax_spandsp','pbx_config','app_verbose','func_timeout','codec_ulaw','codec_alaw','codec_resample','bridge_simple','res_clioriginate']
    (root/'etc/modules.conf').write_text('[modules]\nautoload=no\n'+''.join('load='+m+'.so\n' for m in mods))
    for name,text in {'logger':'[general]\n[logfiles]\nloopback=notice,warning,error,verbose\n','cdr':'[general]\nenable=no\n','cel':'[general]\nenable=no\n','http':'[general]\nenabled=no\n','manager':'[general]\nenabled=no\n','res_fax':'[general]\nminrate=2400\nmaxrate=9600\necm=yes\nmodems=v29,v27\n'}.items():(root/'etc'/(name+'.conf')).write_text(text)
    writer=PdfWriter()
    for width,height in [(595.276,841.89),(841.89,1190.551),(595.276,841.89)]:
        page=writer.add_blank_page(width,height);stream=DecodedStreamObject();stream.set_data(b'0 g 40 40 100 60 re f 40 220 200 20 re f');page[NameObject('/Contents')]=writer._add_object(stream)
    data=io.BytesIO();writer.write(data)
    print('A3_TEST_PHASE: PDF_TO_TIFF',flush=True)
    assert convert(SimpleNamespace(html=False,body='',attachments=[('application/pdf',data.getvalue())]),root/'media')[0]==3
    plan='[loop]\n'
    for extension,app,path in [('rx','ReceiveFAX',root/'media/received.tif'),('tx','SendFAX',root/'media/document.tif')]:
        plan+=f'exten => {extension},1,Answer()\n same => n,Set(TIMEOUT(absolute)=180)\n same => n,{app}({path},F)\n same => n,Verbose(0,A3TEST {extension} ${{FAXSTATUS}} ${{FAXPAGES}} RATE=${{FAXBITRATE}})\n same => n,Wait(2)\n same => n,Hangup()\n'
    (root/'etc/extensions.conf').write_text(plan)
    print('A3_TEST_PHASE: ASTERISK_START',flush=True)
    console=(root/'log/console.log').open('w')
    process=subprocess.Popen(['/usr/sbin/asterisk','-f','-g','-n','-C',str(conf)],stdout=console,stderr=subprocess.STDOUT)
    def cli(command):return subprocess.run(['/usr/sbin/asterisk','-C',str(conf),'-rx',command],capture_output=True,text=True,timeout=5)
    try:
        ready=False
        for _ in range(50):
            if '1 modules loaded' in cli('module show like res_fax_spandsp').stdout:ready=True;break
            time.sleep(.2)
        assert ready, 'ASTERISK_MODULE_NOT_READY'
        print('A3_TEST_PHASE: FAX_EXCHANGE',flush=True)
        assert cli('channel originate Local/rx@loop/n extension tx@loop').returncode==0
        log=root/'log/loopback'
        for _ in range(190):
            text=log.read_text() if log.exists() else ''
            if 'A3TEST tx ' in text and 'A3TEST rx ' in text:break
            time.sleep(1)
        assert all('A3TEST '+label+' SUCCESS 3' in text for label in ('rx','tx'))
        assert all('A3TEST '+label+' SUCCESS 3 RATE=9600' in text for label in ('rx','tx')), 'FAX_RATE_CAP_NOT_VERIFIED'
        with Image.open(root/'media/received.tif') as image:
            assert image.n_frames==3
            for i,width in enumerate([1728,2432,1728]):image.seek(i);assert image.width==width
        print('A3_TEST_PHASE: TIFF_TO_PDF',flush=True)
        assert receive_pdf(root/'media/received.tif',root/'media/received.pdf')==3
        for page,width in zip(PdfReader(root/'media/received.pdf').pages,[595.276,841.89,595.276]):assert abs(float(page.mediabox.width)-width)<.1
        print('A3_LOOPBACK_PASS')
    finally:
        process.terminate()
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:process.kill();process.wait()
        console.close()

if __name__=='__main__':main()
