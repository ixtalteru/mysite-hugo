"""Linux host primitives. Privileged operations are only entered explicitly."""
import base64
import contextlib
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from .model import BUNDLE, Failure, require, dump, digest, platform_profile

ADMIN=Path('/etc/faxmail-next/installer')
STATE=Path('/var/lib/faxmail-installer')
APP=Path('/opt/faxmail-next')
INSTALLED=Path('/opt/fax-server-installer')
GATES=[Path('/etc/faxmail-next/acceptance-approved.json'),Path('/etc/faxmail-next/receive-mail-approved.json')]
SERVICES=['fax-receive-live.service','faxmail-next.service','faxmail-dispatch.service']
TIMERS=['faxmail-broker.timer','faxmail-cleanup.timer','faxmail-maintenance.timer','faxmail-receive-mail.timer']
ONES=['faxmail-broker.service','faxmail-cleanup.service','faxmail-maintenance.service','faxmail-receive-mail.service']

def run(args, check=True, timeout=120, input=None, cwd=None):
    env=dict(os.environ, PATH='/usr/sbin:/usr/bin:/sbin:/bin', LC_ALL='C.UTF-8', LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', DEBIAN_FRONTEND='noninteractive', APT_LISTCHANGES_FRONTEND='none')
    try:r=subprocess.run([str(x) for x in args],input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout,cwd=cwd,env=env)
    except (OSError,subprocess.TimeoutExpired) as cause:
        error=Failure(5,Path(str(args[0])).name+' の起動に失敗しました。' if isinstance(cause,OSError) else Path(str(args[0])).name+' が制限時間 '+str(timeout)+'秒を超えました。')
        error.command=Path(str(args[0])).name
        if isinstance(cause,subprocess.TimeoutExpired):
            def decoded(value):return value.decode('utf-8',errors='replace') if isinstance(value,bytes) else (value or '')
            error.details=decoded(cause.stdout)+'\n'+decoded(cause.stderr)
        raise error from None
    if check and r.returncode:
        error=Failure(5,Path(str(args[0])).name+' が終了コード '+str(r.returncode)+' で失敗しました。詳細ログを確認してください。')
        error.command=Path(str(args[0])).name;error.returncode=r.returncode
        error.details=r.stdout+'\n'+r.stderr
        raise error
    return r

def root_required():require(os.name=='posix' and os.geteuid()==0,'Ubuntu上でsudoを使用して実行してください。')
def safe(path):
    path=Path(path)
    require(path.is_absolute() and '..' not in path.parts,'絶対パスが必要です。')
    for part in [path,*path.parents]:require(not part.is_symlink(),'シンボリックリンクを含む書き込み先を拒否しました。')
    return path

def account(owner,group):
    import pwd,grp
    return pwd.getpwnam(owner).pw_uid,grp.getgrnam(group).gr_gid

def mkdir(path,mode=0o700,owner='root',group='root'):
    p=safe(path);p.mkdir(parents=True,exist_ok=True);p.chmod(mode);os.chown(p,*account(owner,group));return p

def atomic(path,body,mode=0o600,owner='root',group='root'):
    p=safe(path);safe(p.parent);p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():require(p.is_file(),'通常ファイル以外への書き込みを拒否しました。')
    fd,name=tempfile.mkstemp(prefix='.fax-installer-',dir=p.parent)
    try:
        os.fchmod(fd,mode);os.fchown(fd,*account(owner,group))
        with os.fdopen(fd,'wb') as f:f.write(body);f.flush();os.fsync(f.fileno())
        os.replace(name,p)
        fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        if os.path.exists(name):os.unlink(name)

def write_json(path,obj,**kw):atomic(path,dump(obj),**kw)
def read_json(path):
    try:return json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):raise Failure(2,'JSONファイルを読み取れません。') from None

def read_secret(path):
    p=safe(Path(path).absolute());s=p.stat()
    require(s.st_uid==0 and stat.S_IMODE(s.st_mode)==0o600,'秘密入力はroot所有0600の通常ファイルで指定してください。')
    return read_json(p)

@contextlib.contextmanager
def locked():
    import fcntl
    root_required();mkdir(STATE)
    p=safe(STATE/'operation.lock')
    with p.open('a') as f:
        try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise Failure(2,'別の管理処理が実行中です。') from None
        yield

def state():
    return read_json(STATE/'state.json') if (STATE/'state.json').exists() else {'status':'NOT_INSTALLED'}
def set_state(status,**kw):
    data=dict(state(),status=status,updated=time.time(),**kw)
    if status in ('STAGED','ACTIVE') and 'reason' not in kw:
        for k in ('reason','failed_stage','error_log'):data.pop(k,None)
    write_json(STATE/'state.json',data)

def platform():
    require(Path('/etc/os-release').exists(),'Ubuntu上で実行してください。',3)
    values={}
    for line in Path('/etc/os-release').read_text().splitlines():
        k,sep,v=line.partition('=')
        if sep:values[k]=v.strip('"')
    version=values.get('VERSION_ID','')
    require(values.get('ID')=='ubuntu' and version in ('22.04','24.04','26.04'),'対象外OSです。',3)
    architecture=run(['dpkg','--print-architecture']).stdout.strip()
    return platform_profile(version,architecture)

def active(unit):return run(['systemctl','is-active','--quiet',unit],False).returncode==0

def ensure_idle():
    require(not (STATE/'firewall-trial.json').exists(),'FW確認待ちのため他の変更はできません。')
    if active('fax-receive-live.service'):
        r=run(['asterisk','-C','/var/lib/fax-receive-live/etc/asterisk.conf','-rx','core show channels count'])
        require('0 active channels' in r.stdout,'通話中または通話状態不明です。')
    require(not list(Path('/var/lib/fax-receive-live/spool/outgoing').glob('*.call')),'発信待機があります。')
    db=Path('/var/lib/faxmail-next/jobs.sqlite')
    if db.exists():
        import sqlite3
        with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as c:
            n=c.execute("SELECT count(*) FROM jobs WHERE state IN ('VALIDATING','READY','DISPATCH_RESERVED','SENDING','UNKNOWN') OR notification IN ('PENDING','RETRY_WAIT','SENDING')").fetchone()[0]
            n+=c.execute("SELECT count(*) FROM received_mail WHERE state IN ('PENDING','RETRY_WAIT','SENDING')").fetchone()[0]
        require(n==0,'保留ジョブまたは結果不明ジョブがあります。先に運用確認してください。')

def stop_processing():
    if Path('/var/lib/faxmail-control/control.lock').exists() and (APP/'venv/bin/python').exists() and (APP/'faxmail/control.py').exists():
        # Fence new dispatch atomically before checking for in-flight work.
        service_user('from faxmail.control import pause;pause()')
        if active('fax-receive-live.service'):
            r=run(['asterisk','-C','/var/lib/fax-receive-live/etc/asterisk.conf','-rx','core show channels count'])
            require('0 active channels' in r.stdout,'新しい通話が始まりました。発信をpauseし、通話は切断せず停止します。')
        require(not list(Path('/var/lib/fax-receive-live/spool/outgoing').glob('*.call')),'発信キューが残っています。通話を切断せず停止します。')
    # Stop triggers first, then wait for each oneshot to finish/stop.
    for unit in TIMERS+ONES+['faxmail-next.service','faxmail-dispatch.service','fax-receive-live.service']:
        run(['systemctl','stop',unit],False)
    for unit in SERVICES+TIMERS+ONES:require(not active(unit),'サービス停止を確認できません。',5)

def fence():
    for gate in GATES:
        safe(gate)
        if gate.exists():gate.unlink()
    for unit in SERVICES+TIMERS:run(['systemctl','disable',unit],False)

def snapshot(paths):
    files={}
    for path in paths:
        p=safe(path)
        if p.exists():
            require(p.is_file(),'バックアップ対象が通常ファイルではありません。')
            s=p.stat();files[str(p)]={'body':base64.b64encode(p.read_bytes()).decode(),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid}
        else:files[str(p)]=None
    return files

def restore_files(files):
    import pwd,grp
    for path,item in files.items():
        p=safe(path)
        if item is None:
            if p.exists():p.unlink()
        else:atomic(p,base64.b64decode(item['body'],validate=True),item['mode'],pwd.getpwuid(item['uid']).pw_name,grp.getgrgid(item['gid']).gr_name)

@contextlib.contextmanager
def transaction(paths):
    saved=snapshot(paths);folder=mkdir(STATE/'transactions'/str(uuid.uuid4()))
    write_json(folder/'before.json',saved);atomic(folder/'created',str(time.time()).encode())
    try:yield
    except BaseException as error:
        try:
            restore_files(saved);run(['systemctl','daemon-reload'],False)
            set_state('FAILED',reason='構成を復旧しました。業務状態は巻き戻していません。')
        except Exception as cleanup:
            error.cleanup_errors=getattr(error,'cleanup_errors',[])+['構成復旧: '+type(cleanup).__name__]
        raise

def source_integrity():
    manifest=read_json(BUNDLE/'SHA256SUMS.json')
    for relative,expected in manifest.items():
        p=BUNDLE/relative
        require(not p.is_symlink() and p.is_file() and digest(p.read_bytes())==expected,'配布物の完全性検査に失敗しました。',4)

def verify_managed():
    if not (STATE/'managed.json').exists():return
    for path,item in read_json(STATE/'managed.json').items():
        p=safe(path)
        require(p.is_file() and digest(p.read_bytes())==item['sha256'],'管理ファイルに手編集・欠損があります: '+path,4)
        require(stat.S_IMODE(p.stat().st_mode)==int(item['mode'],8),'管理ファイルの権限が一致しません。',4)
        require((p.stat().st_uid,p.stat().st_gid)==account(item['owner'],item['group']),'管理ファイルの所有者・グループが一致しません。',4)

def record_managed(paths):
    import pwd,grp
    result={}
    for path in paths:
        p=safe(path);s=p.stat()
        result[str(p)]={'sha256':digest(p.read_bytes()),'mode':format(stat.S_IMODE(s.st_mode),'04o'),'owner':pwd.getpwuid(s.st_uid).pw_name,'group':grp.getgrgid(s.st_gid).gr_name}
    write_json(STATE/'managed.json',result)

def service_user(command):return run(['runuser','-u','faxmail','--',APP/'venv/bin/python','-B','-c',command],cwd=APP)

def prepare_accounts():
    import pwd,grp
    for group in ['faxmail','faxdispatch','faxmedia']:
        try:require(grp.getgrnam(group).gr_gid!=0,'サービスグループにGID 0は使用できません。')
        except KeyError:run(['groupadd','--system',group])
    for user in ['faxmail','faxdispatch']:
        try:
            entry=pwd.getpwnam(user);require(entry.pw_uid!=0 and entry.pw_gid==grp.getgrnam(user).gr_gid and entry.pw_shell in ('/usr/sbin/nologin','/bin/false'),'既存サービスユーザーの属性が不適合です。')
        except KeyError:run(['useradd','--system','--gid',user,'--no-create-home','--home-dir','/nonexistent','--shell','/usr/sbin/nologin',user])
    for user,groups in [('faxmail','faxmedia,faxdispatch'),('faxdispatch','faxmedia,asterisk'),('asterisk','faxmedia')]:run(['usermod','-a','-G',groups,user])
    for row in read_json(BUNDLE/'directories.json'):mkdir(row['path'],int(row['mode'],8),row['owner'],row['group'])
    mkdir(ADMIN);mkdir(STATE)

def apt_transport_options():
    return ['-o','Acquire::http::Timeout=15','-o','Acquire::https::Timeout=15',
            '-o','Acquire::Retries=2']


def refresh_package_indexes():
    from .diagnostics import stage
    stage('APT: 署名付きパッケージ索引の更新')
    try:run(['apt-get',*apt_transport_options(),'-o','APT::Update::Error-Mode=any','update'],timeout=600)
    except Failure as error:
        error.args=('APT索引の更新に失敗しました。古い索引での導入は行いません。'+str(error),)
        raise


def package_plan(packages):
    from .diagnostics import stage
    stage('APT: 更新候補・取得元・依存関係の検査')
    r=run(['/usr/bin/python3','-B',BUNDLE/'faxsetup/apt_resolve.py'],False,
          timeout=180,input=json.dumps(packages))
    require(r.returncode==0,'APT候補の検証に失敗しました: '+r.stderr.strip(),3)
    result=json.loads(r.stdout)
    packages.clear();packages.update(result['packages'])
    return result


def download_packages(packages):
    from .diagnostics import stage
    for attempt in range(2):
        stage('APT: 必要なパッケージの事前ダウンロード')
        try:
            run(['apt-get',*apt_transport_options(),'-y','--download-only','--no-remove','--no-install-recommends','install']+[k+'='+v for k,v in packages.items()],timeout=1800)
            return
        except Failure as error:
            missing=bool(re.search(r'\b404\s+Not Found\b',getattr(error,'details',''),re.I))
            if missing and attempt==0:
                print('HTTP 404を検出したため、索引を更新して依存関係を再確認し、一度だけ再取得します。',flush=True)
                refresh_package_indexes();package_plan(packages)
                continue
            error.args=(('APT取得先に必要なパッケージが存在しません（HTTP 404）。索引更新後も取得できません。' if missing else 'APTパッケージの事前ダウンロードに失敗しました。')+' パッケージ導入には進みません。詳細ログを確認してください。',)
            raise


def install_packages(profile):
    from .diagnostics import stage
    packages=dict(profile['packages'])
    refresh_package_indexes()
    package_plan(packages)
    require(not active('asterisk.service'),'既存Asteriskが稼働しています。専用ホストへの導入のみ対応します。')
    download_packages(packages)
    write_json(STATE/'apt-selected-packages.json',{'time':time.time(),'packages':packages,'policy':'Ubuntu trusted base/updates/security; Asterisk family fixed; no removals or downgrades'})
    policy=Path('/usr/sbin/policy-rc.d');saved=snapshot([policy])
    try:
        atomic(policy,b'#!/bin/sh\nexit 101\n',0o755)
        stage('APT: ダウンロード済みパッケージの導入')
        run(['apt-get','-y','--no-download','--no-remove','--no-install-recommends','-o','Dpkg::Options::=--force-confold','install']+[k+'='+v for k,v in packages.items()],timeout=1800)
        atomic(STATE/'installed-packages.tsv',run(['dpkg-query','-W','-f=${binary:Package}\t${Version}\n']).stdout.encode())
    finally:restore_files(saved)
    run(['systemctl','disable','--now','asterisk.service'])
    require(not active('asterisk.service'),'標準Asteriskの停止確認に失敗しました。',5)


def install_bundle():
    mkdir(INSTALLED,0o755)
    for relative in read_json(BUNDLE/'SHA256SUMS.json'):
        source=BUNDLE/relative;target=INSTALLED/relative
        if source.resolve()==target.resolve():continue
        mkdir(target.parent,0o755)
        atomic(target,source.read_bytes(),0o755 if relative in ('install.sh','fax-admin') else 0o644)
    atomic(INSTALLED/'SHA256SUMS.json',(BUNDLE/'SHA256SUMS.json').read_bytes(),0o644)
    atomic('/usr/local/bin/fax-admin',b'#!/bin/sh\nexec /usr/bin/python3 -B /opt/fax-server-installer/faxsetup/cli.py "$@"\n',0o755)

def initialize():
    key=Path('/var/lib/faxmail-next/dedupe.key');db=key.with_name('jobs.sqlite')
    require(key.exists()==db.exists(),'鍵とDBの片方だけが存在します。自動初期化を拒否しました。')
    if not key.exists():atomic(key,os.urandom(32),0o600,'faxmail','faxmail')
    lock=Path('/var/lib/faxmail-control/control.lock')
    if not lock.exists():atomic(lock,b'',0o660,'faxmail','faxdispatch')
    service_user("from pathlib import Path;from faxmail.store import Store;from faxmail.control import pause;p=Path('/var/lib/faxmail-next');s=Store(p/'jobs.sqlite',(p/'dedupe.key').read_bytes());s.db.close();pause()")
    for p in key.parent.glob('jobs.sqlite*'):p.chmod(0o600)
