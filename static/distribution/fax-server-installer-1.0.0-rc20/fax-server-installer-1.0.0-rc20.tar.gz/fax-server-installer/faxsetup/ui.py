"""Resumable five-section console; edits only save candidates until applied."""
import copy,getpass,json,re,sys,uuid
from pathlib import Path
from . import host as h,deploy,firewall
from .model import Failure,require,inputs,address,addresses,host,integer,clean,users,users_from_site,site_config,secrets_config,digest,dump

def ask(label,default='',secret=False):
    suffix=' [入力済み・Enterで保持]' if secret and default else (' ['+str(default)+']' if default!='' else '')
    value=(getpass.getpass if secret else input)(label+suffix+': ')
    if value==':戻る':raise Failure(130,'入力を戻りました。保存済みの項目は残っています。')
    return default if value=='' else value

def yes(label,default=False):
    while True:
        v=ask(label+' (y/n)','y' if default else 'n').lower()
        if v in ('y','n'):return v=='y'
        print('y または n を入力してください。')

def choose(title,options):
    print('\n── '+title+' ──')
    for k,label in options:print(k+'. '+label)
    print('0. 戻る / 終了')
    allowed={'0'}|{k for k,_ in options}
    while True:
        value=ask('番号','0')
        if value in allowed:return value
        print('表示された番号を選んでください。')

def applied():
    from .wizard import sample
    if (h.ADMIN/'site.json').exists():return [h.read_json(h.ADMIN/(n+'.json')) for n in ('site','secrets','firewall','users')]
    profile=h.platform();s=sample(profile['version'],profile['arch']);secret={}
    if (h.ADMIN/'draft.json').exists():
        s=h.read_json(h.ADMIN/'draft.json')['site']
        print('旧版の入力途中データを読み込みました。旧版が保存していないパスワードは再入力してください。')
    return [s,secret,{'firewall_schema':1,'ssh_port':22,'allowed_source_cidrs':[s['admin']['ssh_cidr']]},users_from_site(s)]

def load():
    p=h.ADMIN/'candidate.json'
    if p.exists():
        d=h.read_secret(p);return [d[k] for k in ('site','secrets','firewall','users')]
    return applied()

def save(values):
    with h.locked():
        state=h.state()['status']
        if state=='NOT_INSTALLED':
            require(not any(Path(p).exists() for p in ['/opt/faxmail-next','/etc/faxmail-next','/var/lib/fax-receive-live']),'管理対象外のFAX環境があります。新規設定で上書きできません。')
            h.mkdir(h.ADMIN);h.set_state('CONFIGURING',platform=values[0]['platform']['version_id'])
        h.write_json(h.ADMIN/'candidate.json',dict(zip(('site','secrets','firewall','users'),values)))

def text(value):require(clean(value),'空欄や制御文字は使用できません。');return value
def ident(value):require(isinstance(value,str) and re.fullmatch(r'[A-Za-z0-9_.+\-]{1,80}',value),'半角英数字と _ . + - を使用してください。');return value
def number(value):require(re.fullmatch(r'\+?[0-9]{1,32}',value),'半角数字（先頭の+は可）で入力してください。');return value
def port(value):
    try:v=int(value)
    except ValueError:raise Failure(2,'ポート番号は整数で入力してください。') from None
    require(integer(v,1,65535),'ポート番号は1～65535です。');return v
def domain(value):
    require('@' not in value,'メールアドレスではありません。サーバー名を入力してください（例: mx.google.com）。')
    return host(value)
def domains(value):
    result=[domain(x.strip()) for x in value.split(',') if x.strip()]
    require(result,'サーバー名またはドメインを1つ以上入力してください。');return result
def cidrs(value):return firewall.validate({'firewall_schema':1,'ssh_port':22,'allowed_source_cidrs':[x.strip() for x in value.split(',') if x.strip()]},public=True)['allowed_source_cidrs']
def sip_secret(value):secrets_config({'sip_password':value,'imap_password':'valid','smtp_password':'valid'});return value

def field(values,mapping,key,label,validator=text,secret=False,default=None,after=None):
    while True:
        current=mapping.get(key,'') if default is None else default
        if isinstance(current,list):current=','.join(current)
        personal=key in ('auth_username','user_id','phone_number','fax_address','username','email','user','contact_user')
        if personal:
            stored=mapping.get(key,'')
            if stored:print('この項目は登録済みです。変更しない場合はEnterを押してください。現在値は表示しません。')
            raw=ask(label,'',False)
            if raw in ('',':保持') and stored:raw=stored
            elif raw==':保持':
                if not stored:print('まだ登録されていません。この項目の値を入力してください。');continue
                raw=stored
        else:raw=ask(label,current,secret)
        try:value=validator(raw)
        except Failure as e:print('入力を確認してください: '+str(e));continue
        old=copy.deepcopy(values)
        changed=mapping.get(key)!=value
        mapping[key]=value
        if after and changed:after()
        try:save(values)
        except BaseException:
            values[:]=old
            raise
        print('保存しました。');return value

def basic(values):
    s,secret,fw,people=values
    def admin(v):require(re.fullmatch(r'[a-z_][a-z0-9_-]{0,31}',v) and v!='root','既存の一般管理ユーザー名を入力してください。');return v
    field(values,s['admin'],'user','既存の管理ユーザー',admin)
    default=s['admin']['ssh_cidr']
    if default=='192.0.2.0/24':
        import os
        connection=os.environ.get('SSH_CONNECTION','').split()
        if connection:default=connection[0]+('/128' if ':' in connection[0] else '/32')
    def single_cidr(v):
        result=cidrs(v);require(len(result)==1,'管理端末の範囲は1つ指定してください。複数範囲はメニュー4で登録できます。');return result[0]
    field(values,s['admin'],'ssh_cidr','管理端末のIPまたはネットワーク（例: 192.168.0.0/24）',single_cidr,default=default)
    fw['allowed_source_cidrs']=[s['admin']['ssh_cidr']];save(values)

def sip(values):
    s=values[0]['sip'];secret=values[1]
    print('ユーザー名・パスワードで登録するSIP回線に対応。音声FAX(G.711)、ECM有効、T.38なし。')
    print('他社回線は事業者の仕様確認と実通信試験が必要です。TLS・IP認証専用回線は未対応です。')
    while True:
        c=choose('2. SIP情報入力',[('1','MY050のサーバー設定を使用'),('2','他社SIPサーバー / IP・ポート・通信方式'),('3','SIP認証ユーザー名'),('4','SIPユーザーID'),('5','FAX電話番号 / 内線番号'),('6','SIPパスワード'),('7','詳細: SIPドメイン・着信識別子')])
        if c=='0':return
        if c=='1':s.update(host='softphone.spc.brastel.ne.jp',port=5060,transport='udp',domain='softphone.spc.brastel.ne.jp',contact_user='fax-once');save(values);print('MY050のサーバー設定を保存しました。認証情報は3～6で入力します。')
        elif c=='2':
            old_host=s['host']
            def update_domain():
                if s.get('domain')==old_host:s['domain']=s['host']
            field(values,s,'host','登録先SIPサーバー名またはIPv4',domain,after=update_domain)
            field(values,s,'port','SIPポート',port)
            field(values,s,'transport','通信方式 udp / tcp',lambda v:v if v in ('udp','tcp') else (_ for _ in ()).throw(Failure(2,'udp または tcp を入力してください。')),default=s.get('transport','udp'))
            # Do not carry MY050's domain into a different provider.
            if s.get('domain')=='softphone.spc.brastel.ne.jp' and s['host']!=s['domain']:s['domain']=s['host'];save(values)
        elif c=='3':field(values,s,'auth_username','SIP認証ユーザー名',ident)
        elif c=='4':field(values,s,'user_id','SIPユーザーID（事業者指定。通常は認証ユーザー名と同じ）',ident,default=s['user_id'] or s['auth_username'])
        elif c=='5':field(values,s,'phone_number','FAX番号 / 内線番号',number)
        elif c=='6':field(values,secret,'sip_password','SIPパスワード',sip_secret,True)
        elif c=='7':
            field(values,s,'domain','SIPドメイン（事業者指定がなければ登録先と同じ）',domain,default=s.get('domain') or s['host'])
            field(values,s,'contact_user','着信識別子（通常は fax-once のまま）',ident,default=s.get('contact_user','fax-once'))

def sync_people(values):
    for flag,key in [('send','allowed_senders'),('receive','receive_recipients')]:values[0]['mail'][key]=[p['email'] for p in values[3]['users'] if p['enabled'] and p[flag]]

def show_people(rows):
    print('\n── 登録済み利用者一覧 ──')
    if not rows:print('登録されている利用者はいません。')
    for i,p in enumerate(rows,1):print(f"{i}. {p['email']} / 有効={'はい' if p['enabled'] else 'いいえ'} / FAX送信の依頼={'許可' if p['send'] else '不可'} / 受信PDFのお届け={'あり' if p['receive'] else 'なし'}")

def people(values):
    while True:
        rows=values[3]['users']
        show_people(rows)
        c=choose('利用者メールアドレス',[('1','メールアドレスを追加'),('2','既存利用者の権限・アドレスを変更'),('3','利用者を削除')])
        if c=='0':return
        if c=='1':
            while True:
                try:
                    email=address(ask('追加するメールアドレス'));require(email not in [p['email'] for p in rows],'すでに登録されています。');break
                except Failure as e:print(e)
            p={'id':str(uuid.uuid4()),'email':email,'display_name':'','enabled':True,'send':False,'receive':False};rows.append(p);sync_people(values);save(values)
        else:
            show_people(rows)
            if not rows:print('利用者がいません。1で追加してください。');continue
            try:n=int(ask('対象の利用者番号'));require(1<=n<=len(rows),'一覧の番号を入力してください。')
            except (ValueError,Failure):print('利用者番号が不正です。');continue
            p=rows[n-1]
            if c=='3':
                if yes('この利用者を削除しますか'):rows.remove(p);sync_people(values);save(values)
                continue
            def unique(v):
                v=address(v);require(not any(x is not p and x['email']==v for x in rows),'すでに登録されています。');return v
            field(values,p,'email','メールアドレス（Enterで変更なし）',unique,after=lambda:sync_people(values))
        print('送信許可: このアドレスからメールでFAX送信を依頼できます。')
        print('受信転送: 外線で受けたFAXのPDFをこのアドレスへ送ります。')
        for key,label in [('enabled','この利用者を有効にする'),('send','メールによるFAX送信依頼を許可する'),('receive','受信FAXのPDFをこのアドレスへ転送する')]:
            p[key]=yes(label,p[key]);sync_people(values);save(values)

def clear_verified(m):
    m['authentication']['trust_boundary_verified']=False;m['authentication']['placement_verified']=False

def mail(values):
    m=values[0]['mail'];secret=values[1]
    while True:
        c=choose('3. FAXサーバー用メール設定',[('1','FAX専用メールアドレス'),('2','Gmailを使う（サーバー名を自動設定）'),('3','受信IMAPの設定・パスワード'),('4','送信SMTPの設定・パスワード'),('5','送信許可者・受信FAX転送先'),('6','迷惑メール・なりすまし対策'),('7','処理済みメールをごみ箱へ移動')])
        if c=='0':return
        if c=='1':field(values,m,'fax_address','FAX専用メールアドレス',address,after=lambda:clear_verified(m))
        elif c=='2':
            for name,server,p in [('imap','imap.gmail.com',993),('smtp','smtp.gmail.com',587)]:m[name].update(host=server,port=p)
            m['authentication'].update(mechanism='provider_dmarc_arc',trusted_authserv_ids=['mx.google.com'],trusted_arc_domains=['google.com'],authentication_results_index=0)
            clear_verified(m);save(values);print('Gmail設定を保存しました。3と4でメール用パスワードを入力してください。')
        elif c in ('3','4'):
            name='imap' if c=='3' else 'smtp';cfg=m[name]
            print('メール用パスワードを入力します。Gmailではアカウントのアプリパスワードを使用します。')
            field(values,cfg,'host',name.upper()+'サーバー名',domain,after=lambda:clear_verified(m))
            field(values,cfg,'port',name.upper()+'ポート',port,after=lambda:clear_verified(m))
            field(values,cfg,'username',name.upper()+'ログイン名',text,default=cfg['username'] or m['fax_address'],after=lambda:clear_verified(m))
            field(values,secret,name+'_password',name.upper()+'パスワード',text,True)
        elif c=='5':people(values)
        elif c=='6':auth_menu(values)
        elif c=='7':m['trash_completed_requests']=yes('処理が完了した依頼メールをごみ箱へ移動する',m['trash_completed_requests']);save(values)

def auth_menu(values):
    a=values[0]['mail']['authentication']
    c=choose('なりすまし対策',[('1','Gmailの推奨設定を使用'),('2','差出人ドメインのDKIM署名で検証（他社メール向け）'),('3','詳細設定（メール管理者向け）')])
    if c=='0':return
    if c=='1':a.update(mechanism='provider_dmarc_arc',trusted_authserv_ids=['mx.google.com'],trusted_arc_domains=['google.com'],authentication_results_index=0);clear_verified(values[0]['mail']);save(values);print('推奨設定を保存しました。6. 接続検証で受信箱の署名を確認できます。')
    elif c=='2':a['mechanism']='aligned_dkim';clear_verified(values[0]['mail']);save(values);print('有効な差出人ドメインの署名がないメールは拒否します。')
    else:
        print('以下は利用者のメールアドレスを登録する欄ではありません。利用者はメール設定の5で登録します。')
        a['mechanism']='provider_dmarc_arc';clear_verified(values[0]['mail']);save(values)
        field(values,a,'trusted_authserv_ids','認証結果を発行するサーバー名（例: mx.google.com）',domains)
        field(values,a,'trusted_arc_domains','受信メールに署名するドメイン（例: google.com）',domains)
        def index(v):
            try:n=int(v)
            except ValueError:raise Failure(2,'0～20の整数を入力してください。') from None
            require(integer(n,0,20),'0～20で入力してください。');return n
        field(values,a,'authentication_results_index','認証結果ヘッダーの位置（通常0。動作検証で確認）',index)

def fw_edit(values):
    fw=values[2]
    field(values,fw,'ssh_port','SSHポート',port)
    field(values,fw,'allowed_source_cidrs','SSH接続を許可するIP/CIDR（複数はカンマ区切り）',cidrs)
    values[0]['admin']['ssh_cidr']=fw['allowed_source_cidrs'][0];save(values)

def missing(values):
    s,secret,fw,p=values;out=[]
    for k in ['auth_username','user_id','phone_number']:
        if not s['sip'].get(k):out.append('2. SIP情報: '+k)
    for k in ['sip_password','imap_password','smtp_password']:
        if not secret.get(k):out.append(('2. SIP情報' if k=='sip_password' else '3. メール設定')+': パスワード未入力 ('+k.split('_')[0]+')')
    if not s['mail']['fax_address']:out.append('3. メール設定: FAX専用メールアドレス')
    for n in ('imap','smtp'):
        if not s['mail'][n]['username']:out.append('3. メール設定: '+n.upper()+'ログイン名')
    if out:return out
    try:inputs(*values,public=True)
    except Failure as e:out.append(str(e))
    return out

def show_status():
    s=h.state()
    print('\nFAXサーバー管理 1.0.0-rc20 / 状態: '+s['status'])
    if s['status']=='FAILED':
        print('失敗した工程: '+s.get('failed_stage','旧版では記録されていません'))
        print('失敗理由: '+s.get('reason','旧版では詳しい理由が保存されていません。新版で再実行すると工程と理由を記録します。'))
        if s.get('error_log'):print('詳細ログ（root限定）: '+s['error_log'])
    elif s.get('reason') and s.get('last_failure'):
        print('前回の操作失敗: '+s['reason'])
        if s.get('failed_stage'):print('失敗した工程: '+s['failed_stage'])
        if s.get('error_log'):print('詳細ログ（root限定）: '+s['error_log'])

def input_report(values):
    errors=missing(values)
    print('\n── 入力設定の確認結果 ──')
    if errors:
        print('入力設定: 要修正')
        for error in errors:print('・'+error)
    else:print('入力設定: OK（必須項目と入力形式の確認が完了しました）')
    print('この確認だけではインストール成功は判定できません。OS・APT依存関係・ビルド・隔離試験は別の検査です。')
    if not errors:
        print('導入前の環境検査を実行します。パッケージや設定は変更しません。',flush=True)
        checks=deploy.preflight(values[0])
        for label,ok,detail in checks:print(('OK: ' if ok else 'NG: ')+label+' — '+detail)
        if any(not ok for _,ok,_ in checks):errors.append('導入前の環境検査で不適合があります。上のNGを確認してください。')
        print('A3ビルド・隔離試験・外部サーバー接続は、この導入前検査の対象外です。')
    print('以下は保存された導入状態です。上の入力・環境検査の合否とは別です。')
    show_status()
    ask('確認結果を読み終えたらEnterで戻る')
    return 2 if errors else 0

def apply(values,repair=False):
    errors=missing(values)
    if errors:print('未設定・修正が必要な項目:\n'+'\n'.join('・'+x for x in errors));return 2
    public=any(x in ('0.0.0.0/0','::/0') for x in values[2]['allowed_source_cidrs'])
    if public and not yes('SSHを全世界に公開する設定です。続けますか'):return 130
    values=inputs(*values,public=public)
    print('保存済みの設定で導入・適用します。完了状態はSTAGEDです。稼働中ならFAX処理を停止して検査します。')
    print('OS: Ubuntu '+values[0]['platform']['version_id']+' / CPU: '+values[0]['platform']['architecture'])
    print('メールでFAX送信を依頼できるアドレス数: '+str(len(values[0]['mail']['allowed_senders'])))
    print('受信FAXのPDFを届けるアドレス数: '+str(len(values[0]['mail']['receive_recipients'])))
    print('上記は登録アドレスの数です。FAXの枚数や送受信の実績ではありません。')
    if not yes('設定を適用しますか'):return 130
    if not yes('実機受入前のRC版を検証環境で使用しますか'):return 130
    with h.locked():return deploy.install(*values,experimental=True,repair=repair)

def install_menu(values):
    while True:
        c=choose('5. 本体インストール・更新',[('1','設定内容の不足を確認'),('2','手順1～4で保存した設定を使ってインストール'),('3','修復・更新'),('4','アンインストール（データ・設定・SSH/FWは保持）'),('5','設定バックアップ'),('6','設定バックアップを復元')])
        if c=='0':return
        if c in ('2','3'):
            if apply(values,repair=c=='3')==0:print('次は手順6「接続検証・FW適用・本番開始」です。')
        elif c=='1':input_report(values)
        elif c=='4':
            plan=deploy.uninstall_plan();print('削除する管理ファイル:\n'+'\n'.join(str(p) for p in plan))
            print('FAXサービスを停止し本体・unitを除去します。FAX画像、DB、鍵、設定、APTパッケージ、SSH/FW、管理ツールは保持します。')
            if ask('実行する場合は UNINSTALL と入力')=='UNINSTALL':
                with h.locked():deploy.uninstall()
        elif c=='5':
            with h.locked():deploy.backup()
        elif c=='6':
            path=ask('同じホストの設定バックアップディレクトリ')
            if yes('設定を復元してSTAGEDへ戻しますか'):
                with h.locked():deploy.restore(path)
                return

def fw_prepare(values):
    print('手順4では設定を保存するだけです。本体のインストールは不要です。')
    print('通信制限の実適用は、本体導入後の手順6で行います。')
    while True:
        c=choose('4. ファイアウォール設定を保存',[('1','SSHポート・許可IPを入力して保存'),('2','保存した内容を表示')])
        if c=='0':return
        if c=='1':fw_edit(values);print('保存しました。次は手順5で本体をインストールしてください。')
        else:
            print('SSHポート: '+str(values[2]['ssh_port']))
            print('SSH接続を許可する範囲: '+', '.join(values[2]['allowed_source_cidrs']))
            print('これは保存した候補です。現在の通信制限にはまだ適用していません。')

def fw_menu(values):
    while True:
        c=choose('導入後のファイアウォール管理',[('1','SSHポート・許可IPを保存'),('2','保存したルールを表示'),('3','試行適用（新規SSH接続で確定が必要）'),('4','新しいSSH接続から確定'),('5','試行を取り消す'),('6','現在の設定を検査')])
        if c=='0':return
        if c=='1':fw_edit(values)
        elif c=='2':print(firewall.rules(firewall.validate(values[2],public=True)))
        elif c=='3':
            require(h.state()['status'] in ('STAGED','ACTIVE'),'本体が未導入です。手順5で本体をインストールしてください。手順4の保存済み設定は残っています。')
            public=any(x in ('0.0.0.0/0','::/0') for x in values[2]['allowed_source_cidrs'])
            if public and not yes('SSHの全世界への公開を許可しますか'):continue
            if yes('5分以内に新規SSH接続で確認する試行を開始しますか'):
                with h.locked():firewall.trial(values[2],public)
        elif c=='4':
            token=ask('試行ID（試行時に表示された値）')
            with h.locked():firewall.confirm(token)
        elif c=='5':
            with h.locked():firewall.rollback()
        elif c=='6':print('PASS' if firewall.check()==0 else '未確定 / 実設定不一致')

def verify_menu(values):
    from . import checks
    while True:
        c=choose('6. 接続検証',[('1','入力済み設定の確認'),('2','導入済みサーバーの診断'),('3','保存したIMAP設定の接続検証（読み取り専用）'),('4','保存したSMTP設定の認証検証（送信なし）'),('5','受信箱のなりすまし対策を自動検証'),('6','本番開始（SIP登録・FAX受信・メール受付）'),('7','本番処理を停止してSTAGEDへ戻す')])
        if c=='0':return
        if c=='1':input_report(values)
        elif c=='2':deploy.diagnose()
        elif c in ('3','4'):
            if yes('保存したメールサーバーへ認証接続しますか'):checks.mail_connection(values,'imap' if c=='3' else 'smtp')
        elif c=='5':
            if yes('受信箱を読み取り専用で確認しますか。本文・アドレスは表示しません'):
                clear_verified(values[0]['mail']);save(values)
                checks.verify_boundary(values);save(values)
        elif c=='6':
            require(not missing(values),'先に未設定項目を修正してください。')
            finish_setup(values)
        elif c=='7':
            if yes('FAXサービスを停止しますか'):
                with h.locked():h.ensure_idle();h.stop_processing();h.fence();h.set_state('STAGED')

def finish_setup(values):
    from . import checks
    state=h.state()['status']
    require(state in ('STAGED','ACTIVE'),'手順5の本体インストールが未完了です。手順4の設定保存にはインストールは不要です。')
    if state=='ACTIVE' and values==applied():
        require(deploy.diagnose()==0,'本番診断が不合格です。詳細診断を確認してください。',4)
        print('セットアップ完了: 本番稼働中です。');return 0
    if firewall.TRIAL.exists():
        print('FWの試行確認待ちです。新しいSSH接続で手順6の「試行を確定」を選んでください。');return 6
    print('手順6は、接続検証 → 検証結果の反映 → FW適用 → 本番開始の順に進みます。')
    if not yes('保存したIMAP・SMTP設定で接続を検証しますか（メールは送信しません）'):return 130
    checks.mail_connection(values,'imap');checks.mail_connection(values,'smtp')
    auth=values[0]['mail']['authentication']
    if auth['mechanism']=='provider_dmarc_arc' and not (auth['trust_boundary_verified'] and auth['placement_verified']):
        clear_verified(values[0]['mail']);save(values)
        checks.verify_boundary(values);save(values)
    if values!=applied():
        print('検証した設定をここで本体へ反映します。前のメニューに戻る必要はありません。')
        result=apply(values)
        if result!=0:return result
    committed=firewall.check()==0
    if committed:committed=h.read_json(firewall.COMMITTED)['config']==values[2]
    if not committed:
        public=any(x in ('0.0.0.0/0','::/0') for x in values[2]['allowed_source_cidrs'])
        if public and not yes('SSHを全世界へ公開する設定を許可しますか'):return 130
        if not yes('FWを試行適用しますか。5分以内に別のSSH接続から確定が必要です'):return 130
        with h.locked():firewall.trial(values[2],public)
        print('別のSSH接続でこのインストーラーを開き、手順6 → 2で確定してください。確定後、その場で本番開始へ進めます。');return 6
    print('旧FAXサーバーを停止してください。初回は現在の受信箱より後に届くFAX依頼から処理します。')
    if not yes('旧サーバー停止と通話完了を確認し、本番を開始しますか'):return 130
    return deploy.activate_managed(True)

def sender_change(values,action):
    candidate=copy.deepcopy(values)
    action(candidate[3]['users'])
    sync_people(candidate)
    save(candidate)
    values[:]=candidate
    print('保存しました。「5. 保存した設定を反映」で反映してください。')


def sender_add(values,kind='send'):
    require(kind in ('send','receive'),'アドレスの用途が不正です。')
    label='送信許可' if kind=='send' else '受信PDF転送先'
    other='receive' if kind=='send' else 'send'
    email=address(ask(label+'のメールアドレス'))
    existing=next((p for p in values[3]['users'] if p['email']==email),None)
    if existing and existing['enabled'] and existing[kind]:
        print('すでに'+label+'として登録されています。');return
    def add(rows):
        person=next((p for p in rows if p['email']==email),None)
        if person is None:
            person={'id':str(uuid.uuid4()),'email':email,'display_name':'','enabled':True,'send':False,'receive':False}
            rows.append(person)
        elif not person['enabled']:
            # Restore only the requested permission, not a disabled other role.
            person[other]=False
        person['enabled']=True;person[kind]=True
    sender_change(values,add)


def sender_delete(values,kind='send'):
    require(kind in ('send','receive'),'アドレスの用途が不正です。')
    label='送信許可' if kind=='send' else '受信PDF転送先'
    other='受信PDF転送' if kind=='send' else '送信許可'
    rows=[p for p in values[3]['users'] if p['enabled'] and p[kind]]
    print(label+'から削除するアドレスを選んでください。'+other+'の設定は保持します。')
    if not rows:print(label+'アドレスは登録されていません。');return
    for i,p in enumerate(rows,1):print(str(i)+'. '+p['email'])
    print('0. 取り消す')
    try:index=int(ask('対象の番号','0'))
    except ValueError:raise Failure(2,'表示された番号を入力してください。') from None
    if index==0:return
    require(1<=index<=len(rows),'表示された番号を入力してください。')
    selected=rows[index-1]
    if not yes(selected['email']+' の'+label+'設定を削除しますか'):return
    def remove(people):
        next(p for p in people if p['id']==selected['id'])[kind]=False
    sender_change(values,remove)


def sender_menu(values):
    while True:
        current=applied()[0]['mail']
        for key,label,empty in [('allowed_senders','送信許可','メールによるFAX送信依頼は許可しません'),('receive_recipients','受信PDF転送先','受信PDFのメール転送は行いません')]:
            print('\n── '+label+'メールアドレス（保存済み） ──')
            addresses=values[0]['mail'][key]
            for i,email in enumerate(addresses,1):print(str(i)+'. '+email)
            if not addresses:print('登録なし（'+empty+'）')
            added=sorted(set(addresses)-set(current[key]));removed=sorted(set(current[key])-set(addresses))
            print('未反映の追加: '+(', '.join(added) if added else 'なし'))
            print('未反映の削除: '+(', '.join(removed) if removed else 'なし'))
        c=choose('6-5. 送受信メールアドレスの管理',[('1','送信許可メールアドレスを追加'),('2','送信許可メールアドレスを削除'),('3','受信PDFの転送先メールアドレスを追加'),('4','受信PDFの転送先メールアドレスを削除'),('5','保存した設定を反映')])
        if c=='0':return
        try:
            if c=='1':sender_add(values)
            elif c=='2':sender_delete(values)
            elif c=='3':sender_add(values,'receive')
            elif c=='4':sender_delete(values,'receive')
            else:
                print('保存済みの設定をまとめて反映します。他の項目に未反映の変更があれば、それも対象です。')
                print('稼働中はFAX処理を一時停止して内部検査します。画面に従い本番開始まで完了してください。')
                result=finish_setup(values)
                if result==0:print('設定反映が完了しました。')
                else:print('設定反映は未完了です。保存した設定は残っています。')
        except Failure as error:print('確認: '+str(error))


def final_menu(values):
    while True:
        c=choose('6. 接続検証・FW適用・本番開始',[('1','順番に進める / 中断した手順を再開'),('2','新しいSSH接続からFW試行を確定して続ける'),('3','詳細な動作検証'),('4','導入後のFW管理'),('5','送受信メールアドレスの追加・削除・設定反映')])
        if c=='0':return
        if c=='1':finish_setup(values)
        elif c=='2':
            token=ask('試行時に表示された試行ID')
            with h.locked():firewall.confirm(token)
            finish_setup(values)
        elif c=='3':verify_menu(values)
        elif c=='4':fw_menu(values)
        elif c=='5':sender_menu(values)

def configure(section='install'):
    h.root_required();values=load()
    {'install':install_menu,'sip':sip,'mail':mail,'users':people}[section](values)
    return 0

def menu():
    h.root_required();require(sys.stdin.isatty(),'対話端末が必要です。')
    h.platform()  # Unsupported hosts must fail once, before the retrying menu loop.
    print('入力は項目ごとに保存します。個人情報の値は表示せず、登録済み項目はEnterで保持できます。')
    print('一般設定はEnterで保持、:戻るで入力を中断。パスワードはroot専用0600で保存します。')
    while True:
        try:
            values=load()
            show_status()
            print('初回は1 → 2 → 3 → 4 → 5 → 6の順に進んでください。1～4は保存のみ、5で導入、6で検証・接続開始です。')
            c=choose('セットアップ手順',[('1','管理ユーザー・管理端末を設定'),('2','SIP情報を設定'),('3','メール・利用者を設定'),('4','ファイアウォール設定を保存（まだ適用しない）'),('5','本体インストール・更新'),('6','接続検証・FW適用・本番開始')])
            if c=='0':return 0
            {'1':basic,'2':sip,'3':mail,'4':fw_prepare,'5':install_menu,'6':final_menu}[c](values)
        except Failure as e:print('確認: '+str(e))
        except Exception as e:
            from .diagnostics import reason
            print('確認: '+reason(e))
            show_status()
        except KeyboardInterrupt:print('\n中断しました。保存した項目は次回も使えます。')
        except EOFError:return 130
