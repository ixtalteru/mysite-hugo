"""Explicit read-only mail authentication checks for saved candidates."""
import copy,imaplib,json,re,smtplib,ssl,sys
from email import policy
from email.parser import BytesParser
from . import host as h
from .model import require,Failure

def mail_connection(values,kind):
    c=values[0]['mail'][kind];password=values[1].get(kind+'_password')
    require(c['host'] and c['username'] and password,'先にメールサーバー・ログイン名・パスワードを保存してください。')
    client=None
    try:
        if kind=='imap':
            client=imaplib.IMAP4_SSL(c['host'],c['port'],ssl_context=ssl.create_default_context(),timeout=30)
            client.login(c['username'],password);require(client.select('INBOX',readonly=True)[0]=='OK','受信箱を読み取り専用で開けません。')
            print('IMAP接続: PASS（読み取り専用）')
        else:
            client=smtplib.SMTP(c['host'],c['port'],timeout=30);client.ehlo();client.starttls(context=ssl.create_default_context());client.ehlo();client.login(c['username'],password)
            print('SMTP認証: PASS（メール送信なし）')
    except Failure:raise
    except Exception:raise Failure(4,'メール接続・認証が失敗しました。サーバー名・パスワード・TLS設定を確認してください。') from None
    finally:
        if client:
            try:client.logout() if kind=='imap' else client.quit()
            except Exception:pass

def verify_boundary(values):
    require((h.APP/'faxmail/provider_auth.py').exists(),'先に手順5で本体をインストールしてください。外部接続は本番開始前に検証できます。')
    sys.path.insert(0,str(h.APP)) if str(h.APP) not in sys.path else None
    try:from faxmail.provider_auth import verify
    except ImportError:raise Failure(4,'メール署名検証の依存ライブラリを利用できません。修復・更新を実行してください。') from None
    a=values[0]['mail']['authentication'];require(a['mechanism']=='provider_dmarc_arc','この検証は受信メール提供者の署名を使う方式向けです。')
    c=values[0]['mail']['imap'];password=values[1].get('imap_password');require(password,'IMAPパスワードが未入力です。')
    client=None
    try:
        client=imaplib.IMAP4_SSL(c['host'],c['port'],ssl_context=ssl.create_default_context(),timeout=30);client.login(c['username'],password)
        require(client.select('INBOX',readonly=True)[0]=='OK','受信箱を開けません。')
        typ,data=client.uid('search',None,'ALL');require(typ=='OK','受信箱を検索できません。')
        for uid in data[0].split()[-20:][::-1]:
            typ,meta=client.uid('fetch',uid,'(RFC822.SIZE)')
            sizes=re.findall(rb'RFC822.SIZE (\d+)',b' '.join(x for x in meta if isinstance(x,bytes)))
            if not sizes or int(sizes[0])>5*1024*1024:continue
            typ,parts=client.uid('fetch',uid,'(BODY.PEEK[])');require(typ=='OK','メールを読み取れません。')
            raw=next(x[1] for x in parts if isinstance(x,tuple));m=BytesParser(policy=policy.default).parsebytes(raw)
            for i,header in enumerate(m.get_all('Authentication-Results',[])[:21]):
                if str(header).split(';',1)[0].strip() not in a['trusted_authserv_ids']:continue
                candidate=copy.deepcopy(a);candidate['authentication_results_index']=i
                try:verify(raw,candidate)
                except Exception:continue
                a.update(authentication_results_index=i,trust_boundary_verified=True,placement_verified=True)
                print('受信メール提供者の署名と認証結果: PASS。検証済み設定を保存します。手順6で続けて本体へ反映できます。');return
        raise Failure(4,'直近20件（各5MiB以下）に検証できるメールがありません。設定は未検証のままです。')
    except Failure:raise
    except Exception:raise Failure(4,'署名の検証に失敗しました。メール接続・DNS・提供者設定を確認してください。') from None
    finally:
        if client:
            try:client.logout()
            except Exception:pass
