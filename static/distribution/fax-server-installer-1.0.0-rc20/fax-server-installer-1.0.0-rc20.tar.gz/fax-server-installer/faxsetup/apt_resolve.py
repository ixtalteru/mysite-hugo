"""Read-only APT resolver, executed with Ubuntu's system Python (python3-apt)."""
import json,re,subprocess,sys
from pathlib import Path

def fixed(name):
    base=name.split(':')[0]
    # Independently packaged sound data does not share the Asterisk binary ABI.
    if base.startswith('asterisk-core-sounds-'):return False
    return base=='asterisk' or base.startswith('asterisk-')

def validate_version(name, version, installed, origins, codename, source, fixed_version=None, compare=None):
    if fixed_version is not None and version!=fixed_version:
        raise ValueError('Asterisk固定版が不一致: '+name)
    if source=='asterisk' and not fixed(name):
        raise ValueError('未登録のAsterisk関連パッケージ: '+name)
    repositories=[o for o in origins if o.get('archive')!='now']
    allowed={codename,codename+'-updates',codename+'-security'}
    if not repositories or any(not o.get('trusted') or o.get('origin')!='Ubuntu' or o.get('archive') not in allowed for o in repositories):
        raise ValueError('対象Ubuntuの信頼済み公式取得元ではありません: '+name)
    if installed and compare(version,installed)<0:
        raise ValueError('ダウングレードを拒否しました: '+name+' '+installed+' -> '+version)

def main():
    try:import apt,apt_pkg
    except ImportError:raise ValueError('Ubuntu標準のpython3-aptが必要です。先に公式APTからpython3-aptを導入してください。')
    requested=json.load(sys.stdin)
    codename=re.search(r'^VERSION_CODENAME=(\S+)',Path('/etc/os-release').read_text(),re.M).group(1).strip('"')
    cache=apt.Cache(); selected={};evidence={}
    def check(name,version):
        p=cache[name];v=p.versions[version]
        origins=[{'origin':o.origin,'archive':o.archive,'trusted':o.trusted,'site':o.site} for o in v.origins]
        if fixed(name) and name not in requested:raise ValueError('未固定のAsterisk関連依存を拒否しました: '+name)
        validate_version(name,version,p.installed.version if p.installed else None,origins,codename,v.source_name,requested.get(name) if fixed(name) else None,apt_pkg.version_compare)
        if p._pkg.selected_state==apt_pkg.SELSTATE_HOLD and (not p.installed or p.installed.version!=version):
            raise ValueError('holdされたパッケージの変更を拒否しました: '+name)
        evidence[name]={'version':version,'origins':origins,'source':v.source_name}
    for name,version in requested.items():
        if name not in cache:raise ValueError('APTにパッケージがありません: '+name)
        p=cache[name]
        if not fixed(name):
            if p.candidate is None:raise ValueError('APT候補がありません: '+name)
            version=p.candidate.version
        if version not in p.versions:raise ValueError('固定版を取得できません: '+name+'='+version)
        check(name,version);selected[name]=version
    env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LC_ALL':'C.UTF-8'}
    def simulate():
        r=subprocess.run(['apt-get','-s','--no-remove','--no-install-recommends','install']+[k+'='+v for k,v in selected.items()],capture_output=True,text=True,env=env,timeout=120)
        if r.returncode or re.search(r'^Remv ',r.stdout,re.M):raise ValueError('依存関係の解決に失敗、または削除対象があります: '+r.stderr.strip())
        changes={}
        for line in r.stdout.splitlines():
            if not line.startswith('Inst '):continue
            m=re.match(r'^Inst (\S+)(?: \[[^\]]+\])? \((\S+)',line)
            if not m:raise ValueError('APT予行結果を解釈できません: '+line)
            changes[m[1]]=m[2]
        return changes
    changes=simulate()
    for name,version in changes.items():check(name,version);selected[name]=version
    # Freeze the full dependency transaction, not just top-level requests.
    again=simulate()
    if again!=changes:raise ValueError('依存関係の固定後に計画が変わりました。再検査が必要です。')
    print(json.dumps({'packages':selected,'evidence':evidence,'changes':changes},ensure_ascii=False))

if __name__=='__main__':
    try:main()
    except Exception as e:
        print(str(e),file=sys.stderr);sys.exit(3)
