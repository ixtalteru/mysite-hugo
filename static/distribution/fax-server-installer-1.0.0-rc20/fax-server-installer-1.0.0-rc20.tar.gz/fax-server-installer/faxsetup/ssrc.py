"""FAX-only SSRC transition handling. Compiled against each host's Asterisk headers."""
import re
from .model import require,digest
from . import host as h
ADDITION = '\t\t\t/* FAX_SSRC_RESET_V1: the RTP engine queues SRCCHANGE before\n\t\t\t * the first voice frame from the new SSRC. Do not compare its\n\t\t\t * sequence number against the previous stream. Preserve DSP state. */\n\t\t\tif (frame->frametype == AST_FRAME_CONTROL &&\n\t\t\t    frame->subclass.integer == AST_CONTROL_SRCCHANGE &&\n\t\t\t    expected_frametype == AST_FRAME_VOICE) {\n\t\t\t\tstruct ast_trans_pvt *step;\n\t\t\t\tast_channel_lock(chan);\n\t\t\t\tfor (step = ast_channel_readtrans(chan); step; step = step->next) {\n\t\t\t\t\tstep->f.seqno = 0x10000;\n\t\t\t\t}\n\t\t\t\tast_channel_unlock(chan);\n\t\t\t\tast_log(LOG_NOTICE, "FAX_SSRC_RESET_V1: reset receive sequence baseline\\n");\n\t\t\t}\n'

def patch_source(text):
    require('FAX_SSRC_RESET_V1' not in text,'SSRCパッチの二重適用を拒否しました。',3)
    start=text.index('static int generic_fax_exec(')
    end=text.index('static int receivefax_t38_init(',start)
    section=text[start:end]
    matches=re.findall(r'if \(\(frame->frametype == AST_FRAME_CONTROL\) &&\s*\(frame->subclass.integer == AST_CONTROL_T38_PARAMETERS\)',section)
    require(len(matches)==1 and '#include "asterisk/translate.h"' in text,'SSRC修正のソース構造が不適合です。',3)
    return text[:start]+section.replace(matches[0],ADDITION+matches[0],1)+text[end:]

def compile_module(source,stage):
    src=source/'res/res_fax.c';before=src.read_bytes()
    patched=patch_source(before.decode());outsrc=stage/'res_fax-ssrc.c'
    outsrc.write_text(patched)
    output=stage/'res_fax_ssrc.so'
    h.run(['gcc','-shared','-fPIC','-O2','-DAST_MODULE="res_fax_ssrc"','-DAST_MODULE_SELF_SYM=__internal_res_fax_ssrc_self','-I/usr/include','-o',output,outsrc],timeout=300)
    require('not found' not in h.run(['ldd',output]).stdout,'SSRCモジュールの依存ライブラリが不足しています。',3)
    return output,outsrc,{'fix':'FAX_SSRC_RESET_V1','original_sha256':digest(before),'patched_sha256':digest(outsrc.read_bytes()),'module_sha256':digest(output.read_bytes())}
