"""Pure validation and deterministic generation. No network or host mutations."""
import copy
import hashlib
import ipaddress
import json
import re
import uuid
from pathlib import Path

BUNDLE = Path(__file__).resolve().parents[1]
VERSIONS = ('22.04', '24.04', '26.04')

class Failure(Exception):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)

def require(ok, message, code=2):
    if not ok:
        raise Failure(code, message)

def keys(value, required, optional=()):
    require(isinstance(value, dict), 'JSONオブジェクトが必要です。')
    require(set(required) <= value.keys() <= set(required) | set(optional),
            'JSONの必須項目不足、または未定義項目があります。')

def integer(value, lower, upper):
    return type(value) is int and lower <= value <= upper

def clean(value, limit=254):
    return isinstance(value, str) and 0 < len(value) <= limit and not any(ord(c) < 32 or ord(c) == 127 for c in value)

def address(value):
    require(clean(value) and re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?", value), 'メールアドレスの形式が不正です。')
    local, domain = value.rsplit('@', 1)
    require('..' not in local and '..' not in domain and not local.startswith('.') and not local.endswith('.'), 'メールアドレスの形式が不正です。')
    return local + '@' + domain.lower()

def addresses(values):
    require(isinstance(values, list), 'メールアドレスは配列で指定してください。')
    result = [address(x) for x in values]
    require(len(result) == len(set(result)), 'メールアドレスが重複しています。')
    return result

def platform_profile(version,architecture):
    require(version in VERSIONS and architecture in ('amd64','arm64'),'対象外のOS/CPUです。Ubuntu 22.04/24.04/26.04のamd64・arm64に対応しています。',3)
    suffix='-arm64' if architecture=='arm64' else ''
    path=BUNDLE/'platform'/('ubuntu-'+version[:2]+suffix+'.json')
    require(path.is_file(),'このOS/CPU用の依存関係プロファイルがありません。',3)
    profile=json.loads(path.read_text())
    require(profile['version']==version and profile['arch']==architecture,'依存関係プロファイルのOS/CPUが一致しません。',3)
    return profile


def host(value):
    require(clean(value) and re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?', value), 'ホスト名が不正です。')
    return value.lower()

def firewall(value, public=False):
    keys(value, ('firewall_schema','ssh_port','allowed_source_cidrs'))
    require(type(value['firewall_schema']) is int and value['firewall_schema'] == 1, 'FW schema不一致。')
    require(integer(value['ssh_port'], 1, 65535), 'SSHポートは1～65535です。')
    require(isinstance(value['allowed_source_cidrs'], list) and value['allowed_source_cidrs'], 'SSH許可範囲が必要です。')
    result=[]
    for item in value['allowed_source_cidrs']:
        require(isinstance(item,str) and clean(item),'IP/CIDRは文字列で指定してください。')
        try:
            network=ipaddress.ip_network(item, strict=True)
        except (TypeError, ValueError):
            raise Failure(2, 'IP/CIDRが不正、またはCIDRにホスト部分があります。範囲を明示してください。')
        require(network.prefixlen != 0 or public, '全範囲公開には --allow-public-ssh が必要です。')
        if str(network) not in result: result.append(str(network))
    return dict(value, allowed_source_cidrs=result)

def users(value):
    keys(value, ('users_schema','users'))
    require(type(value['users_schema']) is int and value['users_schema'] == 1 and isinstance(value['users'],list), '利用者schema不一致。')
    ids=set(); mails=set(); out=[]
    for original in value['users']:
        row=copy.deepcopy(original)
        keys(row, ('id','email','display_name','enabled','send','receive'))
        try: valid=str(uuid.UUID(row['id'])) == row['id']
        except (ValueError,TypeError,AttributeError): valid=False
        require(valid and row['id'] not in ids, '利用者IDが不正・重複しています。')
        row['email']=address(row['email'])
        require(row['email'] not in mails, '利用者メールが重複しています。')
        require(isinstance(row['display_name'],str) and len(row['display_name']) <= 100 and not any(ord(c)<32 for c in row['display_name']), '表示名が不正です。')
        require(all(type(row[k]) is bool for k in ('enabled','send','receive')), '利用者権限はbooleanです。')
        ids.add(row['id']);mails.add(row['email']);out.append(row)
    return {'users_schema':1,'users':out}

def users_from_site(site):
    send=site['mail']['allowed_senders']; receive=site['mail']['receive_recipients']
    return {'users_schema':1,'users':[{'id':str(uuid.uuid5(uuid.NAMESPACE_URL,'fax-user:'+a)), 'email':a,'display_name':'','enabled':True,'send':a in send,'receive':a in receive} for a in dict.fromkeys(send+receive)]}

def site_config(value):
    s=copy.deepcopy(value)
    keys(s, ('installer_schema','platform','timezone','admin','mail','sip'))
    require(type(s['installer_schema']) is int and s['installer_schema']==1, 'installer_schemaは1です。')
    keys(s['platform'], ('id','version_id','architecture'))
    require(s['platform']['id']=='ubuntu' and s['platform']['version_id'] in VERSIONS and s['platform']['architecture'] in ('amd64','arm64'),'Ubuntu 22.04/24.04/26.04のamd64・arm64に対応しています。',3)
    require(s['timezone']=='Asia/Tokyo', '初版のタイムゾーンはAsia/Tokyoです。')
    keys(s['admin'], ('ssh_cidr','user'), ('authorized_public_keys',))
    require(isinstance(s['admin']['user'],str) and re.fullmatch('[a-z_][a-z0-9_-]{0,31}',s['admin']['user']) and s['admin']['user']!='root','管理ユーザー名が不正です。')
    firewall({'firewall_schema':1,'ssh_port':22,'allowed_source_cidrs':[s['admin']['ssh_cidr']]}, public=True)
    require(isinstance(s['admin'].get('authorized_public_keys',[]),list),'管理公開鍵は配列で指定してください。')
    for k in s['admin'].get('authorized_public_keys',[]):
        require(clean(k,8192) and re.fullmatch(r'(ssh-ed25519|ssh-rsa|ecdsa-sha2-nistp256) [A-Za-z0-9+/=]+(?: [^\r\n]+)?',k), '管理公開鍵の形式が不正です。')
    keys(s['sip'], ('auth_username','user_id','phone_number','host','port'), ('transport','domain','contact_user'))
    for k in ('auth_username','user_id'):
        require(isinstance(s['sip'][k],str) and re.fullmatch(r'[A-Za-z0-9_.+-]{1,80}',s['sip'][k]), 'SIP IDの形式が不正です。')
    require(isinstance(s['sip']['phone_number'],str) and re.fullmatch(r'\+?[0-9]{1,32}',s['sip']['phone_number']), 'FAX番号は半角数字、先頭の+のみ使用できます。')
    host(s['sip']['host']);require(integer(s['sip']['port'],1,65535),'SIPポートは1～65535です。')
    require(s['sip'].get('transport','udp') in ('udp','tcp'),'SIP通信方式はUDPまたはTCPです。TLS・T.38専用回線は未対応です。')
    if s['sip'].get('domain'):host(s['sip']['domain'])
    require(isinstance(s['sip'].get('contact_user','fax-once'),str) and re.fullmatch(r'[A-Za-z0-9_.+\-]{1,80}',s['sip'].get('contact_user','fax-once')),'SIP着信識別子が不正です。')
    m=s['mail'];keys(m,('fax_address','allowed_senders','receive_recipients','imap','smtp','authentication','trash_completed_requests'))
    m['fax_address']=address(m['fax_address'])
    for name in ('allowed_senders','receive_recipients'):m[name]=addresses(m[name])
    require(type(m['trash_completed_requests']) is bool,'ごみ箱移動設定はbooleanです。')
    for name in ('imap','smtp'):
        c=m[name]; keys(c,('host','port','security','auth_type','username', 'folder' if name=='imap' else 'max_message_bytes'))
        c['host']=host(c['host']);require(integer(c['port'],1,65535), 'メールポートが不正です。')
        require(c['auth_type']=='password' and clean(c['username']), 'メール認証はパスワード方式です。')
        require(c['security']==('implicit_tls' if name=='imap' else 'starttls'),'初版はIMAP implicit_tls / SMTP starttlsです。')
    require(m['imap']['folder']=='INBOX','監視フォルダはINBOXです。')
    require(integer(m['smtp']['max_message_bytes'],1,26214400),'SMTPサイズ上限が不正です。')
    a=m['authentication'];keys(a,('mechanism','trust_boundary_verified','placement_verified','trusted_authserv_ids','authentication_results_index','trusted_arc_domains'))
    require(a['mechanism'] in ('provider_dmarc_arc','aligned_dkim'),'未対応のメール認証方式です。')
    require(all(type(a[k]) is bool for k in ('trust_boundary_verified','placement_verified')), '認証確認状態はbooleanです。')
    require(integer(a['authentication_results_index'],0,20),'認証ヘッダー位置が不正です。')
    for k in ('trusted_authserv_ids','trusted_arc_domains'):
        require(isinstance(a[k],list),'認証ドメインは配列です。')
        for v in a[k]:host(v)
    return s

def secrets_config(value):
    keys(value,('imap_password','smtp_password','sip_password'))
    require(all(clean(v,1024) and '{{' not in v and not v.startswith('<') for v in value.values()), '秘密値が未設定・プレースホルダー・不正形式です。')
    require(re.fullmatch(r'[A-Za-z0-9!#$%&*+./:=?@^_~\-]{1,256}',value['sip_password']), 'SIP秘密値に設定書式で扱えない文字があります。')
    return dict(value)

def inputs(site, secret, fw=None, people=None, public=False):
    site=site_config(site);secret=secrets_config(secret)
    people=users(people or users_from_site(site))
    for flag,key in [('send','allowed_senders'),('receive','receive_recipients')]:
        derived=[p['email'] for p in people['users'] if p['enabled'] and p[flag]]
        require(derived==site['mail'][key], 'users.jsonとsite.jsonの利用者配列が一致しません。')
    fw=firewall(fw or {'firewall_schema':1,'ssh_port':22,'allowed_source_cidrs':[site['admin']['ssh_cidr']]},public)
    return site,secret,fw,people

def dump(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def digest(data):return hashlib.sha256(data).hexdigest()

def generate(site, secrets):
    result={}
    for item in json.loads((BUNDLE/'payload-manifest.json').read_text()):
        body=(BUNDLE/item['payload']).read_bytes()
        require(digest(body)==item['sha256'],'配布ソースのハッシュが一致しません。',4)
        result[item['path']]=body
    def read(path):return json.loads(result[path])
    base='/etc/faxmail-next/'
    mail=read(base+'site-mail.json');mail['mail']=copy.deepcopy(site['mail'])
    for name in ('imap','smtp'):mail['mail'][name]['password']=secrets[name+'_password']
    mail['permissions']['test_destination_numbers']=[]
    result[base+'site-mail.json']=dump(mail)
    fax=read(base+'site-fax.json');fax['permissions']['test_destination_numbers']=[];result[base+'site-fax.json']=dump(fax)
    validation=copy.deepcopy(mail);validation['mail']={k:mail['mail'][k] for k in ['fax_address','allowed_senders','authentication']};result[base+'validation.json']=dump(validation)
    receive=read(base+'receive-mail-approved.json');receive['recipients']=site['mail']['receive_recipients'];result[base+'receive-mail-approved.json']=dump(receive)
    p='/var/lib/fax-receive-live/etc/pjsip.conf'
    lines=[];section='';s=site['sip']; number=s['phone_number']
    changes={('auth','username'):s['auth_username'],('auth','password'):secrets['sip_password'],('once-registration','server_uri'):f"sip:{s['host']}:{s['port']}",('once-registration','client_uri'):f"sip:{s['user_id']}@{s['host']}",('provider-aor','contact'):f"sip:{s['host']}:{s['port']}",('provider','from_user'):s['user_id'],('provider','from_domain'):s['host'],('provider','callerid'):f'FAX <{number}>',('provider-identify','match'):s['host']}
    domain=s.get('domain') or s['host'];suffix=';transport=tcp' if s.get('transport')=='tcp' else ''
    changes.update({('transport','protocol'):s.get('transport','udp'),('once-registration','server_uri'):f"sip:{s['host']}:{s['port']}"+suffix,('once-registration','client_uri'):f"sip:{s['user_id']}@{domain}"+suffix,('provider-aor','contact'):f"sip:{s['host']}:{s['port']}"+suffix,('provider','from_domain'):domain,('once-registration','contact_user'):s.get('contact_user','fax-once')})
    for line in result[p].decode().splitlines():
        if line.startswith('['):section=line.strip('[]')
        key=line.split('=',1)[0]
        # Ubuntu22/Asterisk18 rejects this later-version registration option.
        if site['platform']['version_id']=='22.04' and section=='once-registration' and key=='max_random_initial_delay':continue
        lines.append(key+'='+changes[(section,key)] if (section,key) in changes else line)
    result[p]=('\n'.join(lines)+'\n').encode()
    p='/var/lib/fax-receive-live/etc/extensions.conf'
    text=result[p].decode().replace('exten => 05000000000,','exten => '+number+',').replace('CALLERID(num)=05000000000','CALLERID(num)='+number)
    text=text.replace('exten => fax-once,','exten => '+s.get('contact_user','fax-once')+',')
    result[p]=text.encode()
    p=base+'callerid.conf';result[p]=result[p].decode().replace('<05000000000>','<'+number+'>').encode()
    result[base+'retention-manifest.json']=b'[]\n'
    for path,body in result.items():require(b'{{SECRET_' not in body,'秘密プレースホルダーが残存しています。',4)
    return result
